---
title: 'My Columbia: Surviving NY Winters'
author: Arthur Delmhorst
tags:
- Low Library
- Winter
- Weather
- Library
- Study spots
- Politics
- Activism
- Good trouble
layout: memory
schools:
  CC: 1960
primary_year: 1960
---
# Surviving NY Winters

The hardest part of Columbia winters was rowing on the Harlem River.

Although the crew rowed in indoor tanks in the basement of Low Library during the coldest months, we would be back out on the river in late February or early March. Winter was still here. We would occasionally have to shovel deep snow off the docks and then, in just sweat shirts and sweat pants, go out for a workout. No gloves! The Harlem River, polluted as it was, would still freeze on our oarlocks!

The eight oarsmen at least were able to build up some body heat from the exercise, but the poor coxswain just sat in the stern and steered. No activity to warm him. I remember one almost being overcome with cold. I was certain he was going to collapse and fall overboard. It was touch and go for a while.
