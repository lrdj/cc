---
title: 'My Columbia: The Big Hedge'
author: Stephen Goldman
layout: memory
schools:
  CC: 1966
primary_year: 1966
tags:
- Academics
---
# The Big Hedge

In my freshman CC course, there was a classmate who was fond of giving lengthy answers that were somewhat amorphous and tended to cover all bets so that, in some way, his answer -- or some part of it -- was always correct.  One day the professor called on him but insisted that he give no exposition at all, just answer the question, yes or no.  "Yes," he said, slowly and grudgingly.  "I'm sorry," replied the professor.  "That's incorrect.  The correct answer is no." At that, the shoveler replied, "Well, yes...in a negative way."
