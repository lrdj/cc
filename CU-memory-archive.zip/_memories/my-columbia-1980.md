---
title: 'My Columbia: 1980'
author: May  Kesler
tags:
- St. Paul's Chapel
- Spirituality
- Religion
- Music
- Relationships
layout: memory
schools:
  PPT: 1982
primary_year: 1982
---
# 1980

My brother Ted also went to Columbia, and though he is an education major, he really loves music. He was the producer of the coffee house at St. Paul's Chapel. I went there with boyfriends, family, and friends to hear and see the inspired candlelight performances of the yet to be discovered. Suzanne Vega was two feet in front of me one evening, and I've never forgotten that.  I shed sweet tears at being able to hear every part of the lyrics and see the emotions on the performer's faces with a startling depth of understanding. For my world when I was at Columbia had been horribly shattered, and was yet struggling to be renewed.
