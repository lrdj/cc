---
title: 'My Columbia: Seeing Snow for the First Time'
author: Alan A. Kusunoki
layout: memory
schools:
  SEAS: 1971
primary_year: 1971
tags:
- Winter
- Weather
- Academics
---
# Seeing Snow for the First Time

I was a freshman from Hawaii, and had never before left the islands. The cooler temperatures of Fall 1966 were certainly a new experience for me. But I will never forget sitting in one of my engineering classes and noticing for the first time, snow falling. Having never seen snow before, I wondered what it was at first; I thought that it resembled small tufts of cotton floating down past the window.  When I realized what it was, I jumped up and yelled, "Snow!" Everyone laughed. Someone said, "Yes, Pineapple, it's snow."
