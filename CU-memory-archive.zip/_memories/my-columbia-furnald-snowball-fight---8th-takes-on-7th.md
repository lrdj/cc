---
title: 'My Columbia: Furnald Snowball Fight - 8th takes on 7th'
author: Robert Muirhead
tags:
- Barnard
- Dorm life
- Campus
- Winter
- Weather
- Academics
- Politics
- Activism
- Good trouble
layout: memory
schools:
  CC: 1978
primary_year: 1978
---
# Furnald Snowball Fight - 8th takes on 7th

If I'm not mistaken, it was one of the President's holidays in February of my senior year.

I was the 8th floor residence counselor with a room right across from the TV room.  Trying to grind out a paper for Prof. Harris's Tax Policy class, I heard the escalating voices of some of my residents.  Not needing the distraction, I emerged from my room looking to lay down the law.  Turned out some of the guys had been looking out the (open) lounge window and knocked some snow onto some of Floor 7's finest who were similarly poised out their window just below.  Some good-natured bantering was going on, but I called a halt to the proceedings, fearing escalation.  Not two minutes later, the counselor from 7, a delightful young Barnard woman, appeared in our lounge doorway suggesting there would be hell to pay over "my" charge's doings.   Then, with a grin, she popped me with a large snowball hidden behind her back.  Of course, the war was on!

Quickly exhausting our ready supply of snow from the window sills, things looked bleak as the demons from the 7th floor pummeled us with a box full of snowballs brought up for that very purpose.  Worse, they commandeered the elevator, and guarded the stairs so none could get by to open a supply route.  In a moment of serendipity, I recalled still having the key to the service elevator, made available to me for what reason I could not now tell you.  A large contingent made their way down to the snow field in front of the dorm, loaded themselves to the hilts and made a charge befitting the Royal Fusiliers, bolting from the service lift screaming at the top of our lungs.  By the time truce was called, both floors looked more like ski runs than Ivy League housing.
