---
title: 'My Columbia: Dorm Life'
author: E. Michael Geiger
tags:
- John Jay
- Barnard
- Dorm life
- Campus
- Library
- Study spots
- Politics
- Activism
- Good trouble
layout: memory
schools:
  CC: 1958
primary_year: 1958
---
# Dorm Life

It was a warm, beautiful, late-spring day, and we were studying for finals. As I looked out of my Livingston Hall 2nd floor window, a pretty co-ed walking by caught my eye. I yelled a hello to her. Then someone at another window shouted something. Then someone on the campus shouted something back. Soon there were students at many windows in Livingston and John Jay shouting to the mob of students that had gathered on the campus and were shouting back. I yelled "panty raid" and hundreds (it seemed) of us rushed to the Barnard dorms. I got in the gate, but the police were there almost immediately and blocked the entrance. When asked what I was doing there I said that I had a date. Fortunately, the Barnard gal that "was my date" backed me up and all ended well...except...no panties.
