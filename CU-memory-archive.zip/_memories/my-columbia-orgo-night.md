---
title: 'My Columbia: Orgo Night'
author: Jessy Randall
layout: memory
schools:
  CC: 1992
primary_year: 1992
tags:
- Library
- Study spots
---
# Orgo Night

When I was a freshman at Columbia, I worked late hours at the reserve desk. I happened to be on duty the night before the Organic Chemistry final. I now know that there was (is?) a tradition for the marching band to play in the library at midnight on that night, but I didn't know it then. The library was very crowded, and grew strangely more and more crowded as midnight approached. When the band arrived, I was quite surprised, as you can imagine! They played "Wipe Out" and a few other songs. I kept waiting for somebody to kick them out of the building, but of course that didn't happen. I'm now a librarian myself, at Colorado College, where we have a few odd library traditions of our own.
