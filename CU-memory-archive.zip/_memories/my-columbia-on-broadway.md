---
title: 'My Columbia: On Broadway'
author: Erin Sarah Kade
layout: memory
schools:
  GS: 2003
primary_year: 2003
tags:
- Dorm life
- Campus
- Academics
- Arts
- Culture
- Relationships
---
# On Broadway

My most "artsy experience" was in the summer before my senior year, when I ended up taking a class called "The New York Theater Experience."  I was hoping that it would be an easy way to see free Broadway shows and the like, but apparently Columbia did not have the budget for that.

We ended up spending most of our audience time in small theaters in the village, seeing productions that had the actors practically in our laps.  At one particularly memorable show, the actors were sitting at what looked like a town hall meeting of sorts, acting out whatever scenario the scene was about, when---BAM!!  The lights went off, and when they came back on, everyone was completely naked and doing spontaneous, interpretive dances around the room and rolling around on the floor.

Quite the New York experience and definitely more interesting than a Broadway show!!
