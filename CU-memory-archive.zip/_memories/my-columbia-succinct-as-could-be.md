---
title: 'My Columbia: Succinct as Could Be'
author: alan frommer
layout: memory
schools:
  SEAS: 1958
primary_year: 1958
tags:
- Academics
- Lectures
- Arts
- Culture
---
# Succinct as Could Be

During freshman week we attended several lectures.  The one that stayed with me and which I passed on to my children (Michele '86C, Benjamin '91C) is that of the late Harry Coleman.

He said to us, "This is your last chance to get a superior liberal arts education.  Make the most of it!"
