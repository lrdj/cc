---
title: 'My Columbia: A Rose Is a Rose Is a Rose'
author: Arnold Wasserman
tags:
- Barnard
- Academics
layout: memory
schools:
  CC: 1947
primary_year: 1947
---
# A Rose Is a Rose Is a Rose

In regards to my social life while at Columbia: With the name Wasserman, I was the talk (if not the laugh) of my class because I dated a Barnard student named "Siff"!

I don't think that would be understood or considered funny today, but it was typical of the humor of the 40's!
