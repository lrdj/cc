---
title: 'My Columbia: Hartley Hall 1958'
author: Michael Kubishen
tags:
- Hartley
- Dorm life
- Campus
layout: memory
schools:
  CC: 1960
primary_year: 1960
---
# Hartley Hall 1958

This is the beautiful room of Andy Kubishen and Frank Zmorzenski. It was only like this for the picture (to show our parents). We were roommates for sophomore and junior years. There were a few problems with frequent debris fields that developed and hidden alarm clocks, so we had to divide the room. Frank got everything above the light switch and I had everything below. There was a brief discussion, but I was bigger. Worked like a charm until we got single rooms senior year - then we couldn't stay out of each other's room.

Frank and I see each other frequently. After 30 years in the Navy we ended up about five miles from each other.
