---
title: 'My Columbia: Beauty Spot'
author: Saul Ricklin
layout: memory
schools:
  SEAS: 1940
primary_year: 1940
tags:
- Campus
---
# Beauty Spot

You asked for a favorite beauty spot on the campus. They are all gone! On my last visit, the beauty spots of my Columbia days are now covered with buildings.
