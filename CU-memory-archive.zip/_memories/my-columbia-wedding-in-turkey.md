---
title: 'My Columbia: Wedding in Turkey'
author: May  Yamada-Lifton
layout: memory
schools:
  BUS: 2002
primary_year: 2002
tags: []
---
# Wedding in Turkey

My husband Daniel Lifton and I, May Yamada-Lifton, went with a series of Business School grads in 2002 to a wedding in Turkey of another CBS grad, Ralf Elhadef. It was a Sephardic Jewish wedding on the Bosphorus--it was thrilling to see Asia and the West at one time!
