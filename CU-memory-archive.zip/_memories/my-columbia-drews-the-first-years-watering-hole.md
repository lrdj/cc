---
title: 'My Columbia: Drew''s: The First-Year''s Watering Hole'
author: Robert  Carey
layout: memory
schools:
  CC: 1992
primary_year: 1992
tags:
- Sports
- Athletics
- Food
- Dining
---
# Drew's: The First-Year's Watering Hole

I was so sorry to learn that Drew's, at the SW corner of 106th and Broadway, had become a food market some years back. After all, if it were not for the establishment's completely uninterested bouncers, I would not have been able to enjoy hangovers until at least junior year.

Those guys took one look at the license I presented them for proof of age--I was the youngest looking 23-year-old in New York at that time (and sported a mustache at the time of the photo, apparently)--rolled their eyes, and waved me inside.

I will be forever grateful to them.
