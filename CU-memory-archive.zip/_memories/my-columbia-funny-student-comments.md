---
title: 'My Columbia: Funny Student Comments'
author: Aidan Wakely-Mulroney
tags:
- Contemporary Civilization
- Academics
layout: memory
schools:
  CC: 2005
primary_year: 2005
---
# Funny Student Comments

In my Contemporary Civilization class, a student interrupted the professor's train of thought:

Professor: So, reading Rousseau, we have to ask ourselves, what is the state of freedom like?

Student: New Hampshire?
