---
title: 'My Columbia: 1979'
author: Riccardo Heald
layout: memory
schools:
  SEAS: 1983
primary_year: 1983
tags:
- Dorm life
- Campus
---
# 1979

I was a freshmen the fall of 1979 in Carmen Hall. During that time the upperclassmen would yell up to us: "Four more years!" I didn't quite get what they meant at first, but I soon understood.
