---
title: 'My Columbia: The great flood of ''92'
author: Vincent Liggio
tags:
- John Jay
layout: memory
schools:
  SEAS: 1992
primary_year: 1992
---
# The great flood of '92

Who would have thought that living on the 12th floor of John Jay would require flood insurance? One day a standpipe broke on the 14th floor, and a foot of water flooded the 14th and 12th floors of the building. No one expected to have to bring their scuba gear to college!
