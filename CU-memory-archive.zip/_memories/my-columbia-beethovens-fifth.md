---
title: 'My Columbia: Beethoven''s Fifth'
author: Nancy Park
tags:
- John Jay
- Dorm life
- Campus
- Music
layout: memory
schools:
  CC: 1997
primary_year: 1997
---
# Beethoven's Fifth

I lived in a John Jay single my first year, on the fifth floor. My room was in the middle of the hallway, and on one end was Ben Middleman's. Ben had great and varied musical tastes he enjoyed sharing with the whole floor. Usually he would leave his door open and blast music from his advanced stereo system onto the whole floor.  When he was in a mood, he played Beethoven's Fifth. The floor in my room would vibrate with it, and I would throw my door open too to take it in.
