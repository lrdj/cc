---
title: 'My Columbia: Favorite Teacher'
author: Gauri Khurana
layout: memory
schools:
  CC: 2000
primary_year: 2000
tags: []
---
# Favorite Teacher

My favorite teacher while I was an undergrad at Columbia is Carol Dweck, because I used her course materials (for her course in personality development psychology) when I later became a teacher after graduation!
