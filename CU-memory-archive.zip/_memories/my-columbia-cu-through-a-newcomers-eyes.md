---
title: 'My Columbia: CU through a Newcomer''s Eyes'
author: Jacie Buitenkant
tags:
- Butler Library
- Library
- Study spots
layout: memory
schools:
  CC: 1998
primary_year: 1998
---
# CU through a Newcomer's Eyes

For most people, the image of giant steel gates evoke terrifying feelings of confinement. When I first walked through the gates of Columbia University, I was overpowered with a completely different emotion. For the first time in my life, I felt truly liberated. I immediately sensed that within the gated confines of Morningside Heights, I could reach my ultimate potential. Here my imagination could finally run free, and my success would be boundless.

I also remember the first time that I entered Butler Library and saw the names of all of the Masters hanging proudly on the wall. "Come join us" they seemed to silently beckon. The awe I felt has been unparallel to any other experience in my life. I was honored to be in the midst of such genius. I recall hesitating for a minute to reread the names, as if to let the profound effect of their greatness sink in. It was at that moment that I realized that Columbia was now a part of me, and with it I had the power and knowledge to achieve anything.
