---
title: 'My Columbia: Lunch Date'
author: David Gilbert
tags:
- Hamilton Hall
- Dorm life
- Campus
- Relationships
layout: memory
schools:
  LAW: 1998
primary_year: 1998
---
# Lunch Date

The day I'd like to relive is the day I had lunch with my wife on the top floor of Hamilton Hall.  I was in my third year of law school.  We were newlyweds, having married at the end of my second year--during exams, in fact.  She was working in the Dean's Office (CC).  At that time, there was an empty office on the top floor of the building--a closet perhaps--with a window that looked out on Kent Hall.  We had lunch there together--sandwiches from Hamilton Deli, as I recall.  It was very private and romantic.
