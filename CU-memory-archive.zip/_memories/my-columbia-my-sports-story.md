---
title: 'My Columbia: My Sports Story'
author: Dan Binder
tags:
- Homecoming
- Sports
- Athletics
primary_year: 2006
layout: memory
---
# My Sports Story

The best Columbia sports moment I ever saw was Lion football beating Princeton at the Tigers' homecoming in 2003.  It was the Lions' first victory at Princeton since the Truman administration, I think.  Last second, long shot TD pass.  Whoo hooray--the bus ride home was fun.
