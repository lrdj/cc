---
title: 'My Columbia: My Favorite Place at CU'
author: Jennifer Sabella
layout: memory
schools:
  CC: 2006
primary_year: 2006
tags:
- Campus
---
# My Favorite Place at CU

To me, Columbia is most beautiful at 7:30 in the morning. During my time at Columbia, I spent many a weekday morning up at 7 to get to some Manhattan internship by 8:15 am. It was during my morning walk to the subway that I found Columbia to be at its best. The campus was quiet, save for a only a few souls walking to or from the subway. Sometimes the grass was soggy from the evening before and the air smelled of morning dew.  My favorite spot on this lonely traverse was along the bridge crossing from the law school across 116th Street between Amsterdam and Broadway.  Beautiful.  I would have a solid five minutes to myself, to meditate and contemplate the day ahead. I would look down and see the hustle and bustle along Amsterdam as cars made their way through morning traffic. Standing in the middle of the bridge and looking north or south, all I could see was road stretching from the top of Manhattan, wherever it began, to the bottom, wherever it ended. And I would find comfort in being on my own quiet cement island raised above it all, for just a moment, before I joined the hustle and bustle below.
