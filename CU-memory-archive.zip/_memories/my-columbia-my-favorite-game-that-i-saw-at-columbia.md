---
title: 'My Columbia: My Favorite Game That I Saw at Columbia'
author: Arthur L. Thomas
layout: memory
schools:
  CC: 1950
primary_year: 1950
tags:
- Sports
- Athletics
- Arts
- Culture
---
# My Favorite Game That I Saw at Columbia

In the late 1940s, Columbia played Army in football at Baker Field. Army had a formidable team and was expected to make quick work of Columbia. Army also had two teams, I believe, an offensive team and a defensive team. This was the beginning of the era of two groups playing football for a college. Columbia had, it seems, only one team with a few reserves, if I remember correctly. Gene Rossides played quarterback. Bill Swiacki played an end. At the half Army may have led by 20-14. The cadets pulled out their white handkerchiefs and waved them. Late in the game Gene Rossides threw a pass to Bill Swiacki that set the stage for Columbia to win 21-20. Bill Swiacki made an incredible catch labelled the "shoestring" catch. There was electricity in the air that day. The Columbia win was a tremendous tribute to the human spirit.

Edited to include:  The game was played at Baker Field on October 25, 1947. Columbia snapped Army's unbeaten streak of 32 games. At half-time the score was 20-7 and stayed there until the fourth quarter. There were many highlights and incredible plays. Lou Kusserow, for example, made two running touchdowns I believe for Columbia during the game and in the fourth quarter after the score was 21-20, Lou Kusserow, playing defense, also intercepted a critical Army pass that enabled Columbia to control the game at the end.

It was at that time that colleges were beginning to have a first team for offense, a first team for defense, and reserves for both. Columbia had only one first team that played both offense and defense with a few reserves. They were formidable men!

Arthur L. Thomas CC50
