---
title: 'My Columbia: My Favorite Place'
author: Ann Ingram
layout: memory
schools:
  NRS: 1980
primary_year: 1980
tags:
- Dorm life
- Campus
- Academics
- Relationships
---
# My Favorite Place

When I was at Columbia,  I was on the Health Science Campus at 168th St.  which is not known for it's "beauty."  At that time, the School of Nursing was located in Maxwell Hall, and we had our residence, some of our classes, and our social events in this building.  Our room keys were "skeleton" keys, and if you lost one, the entire lock needed to be changed out.  This building was  quaint, with leaded glass, wooden floors, lovely wooden frames and plaster molding.  Surrounding it was a small patch of gardens and grass, a true rarety in that neighborhood.  Maxwell Hall stood proudly among the giant new buildings of the Columbia Presbyterian Hospital community...but I digress.

My very favorite place in this lovely building was on the roof.  It was where I went to get a breath of fresh air in a crowded city and where I could look and see the Twin Towers to the south and up the Hudson towards the Tappan Zee to the North.  Although, I now live in Montana and take fresh air and "the big sky" almost for granted, I have fond memories of time well spent with friends on the roof of Maxwell Hall.
