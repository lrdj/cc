---
title: 'My Columbia: Fluffy Little Clouds . . .'
author: Cary Hall
tags:
- Furnald Hall
- Dorm life
- Campus
- Academics
- Arts
- Culture
layout: memory
schools:
  CC: 1992
primary_year: 1992
---
# Fluffy Little Clouds . . .

So I'm living in Furnald Hall during my sophomore through senior years (which was a feat in itself, since everyone seemed to want the large rooms in Furnald!) between 1989-1992, and typically had a lunch break in between classes during the week.  My usual routine was to grab a slab of lasagna (either meat or vegetable) from FBH -- can't believe it's gone! -- and head back to the dorm to kill time 'till the next class.  Inevitably I'd steer into the common kitchen/hang-out room and see what was on the tube -- you know, the room that's next to the co-ed bathrooms/showers? :-)

Sometimes another floor denizen or two was there, and sometimes not.  It got to be, however, that not much was on TV around noon, and somehow it was always tuned to PBS . . . in particular, the Bob Ross painting show.  You know the guy:  soft-spoken white guy with an afro that paints some nature scene within the span of 30 minutes that's always just AWESOME?  And talks the entire time about what he's doing and envisioning as he does it?  And, yes, I too immediately thought that Dr. Kevorkian had been beaten to the punch in inventing a suicide machine, but something about this show was just *mesmerizing* to anyone who happened to be walking past in the hall.  As much as his canvas still looked like gobbledygook with only five minutes left in the show, he always pulled it off.

Those "lunches" were inevitably spent with most everyone from the floor at one point of another.  Words were hardly spoken during that half-hour while we all sat spellbound by this freaky little guy with a palette and a few tubes of paint.  Jock, engineer, punk -- we were all fascinated by the Bob Ross common denominator . . . and I'm still not sure why.  But man, that guy could paint some pretty pictures.  :-)  Does this explain why I consistently couldn't seem to break that B+ mark?  And does this even count as a "dish on dorm life"?
