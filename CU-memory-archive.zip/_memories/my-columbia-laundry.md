---
title: 'My Columbia: Laundry'
author: Ronald Fried
tags:
- John Jay
- Library
- Study spots
- Arts
- Culture
layout: memory
schools:
  CC: 1977
primary_year: 1977
---
# Laundry

Here's a glamorous and exciting memory.  When I think of relaxing on Saturday night at Columbia, I remember doing my laundry and then watching "The Mary Tyler Moore Show" on the TV in John Jay.  (It was the only TV show I let myself watch in those days.)  Then I'd head over to Burgess Carpenter Library and read one of the eight million books I was supposed to gulp down each semester at Columbia.  By now you're likely asking yourself if this is another "Million Little Pieces"-like hoax.  Could this amazing anecdote actually be true?  Yup, that's what I did on most Saturday nights at Columbia.
