---
title: 'My Columbia: Playoff'
author: Peter Elliott
layout: memory
schools:
  CC: 1970
primary_year: 1970
tags: []
---
# Playoff

The 67-68 Ivy League basketball regular season ended in a tie at 12-2 between Columbia and Princeton.  A playoff was scheduled at a "neutral" court--St. Johns.  Columbia fans packed the place and started cheering at least a half hour before tip-off.

Dave Newmark was injured--which was the only reason Princeton beat us down there on the previous weekend.  But he lined up at center and the first play was run to him.  He scored easily, which seemed to demoralize Princeton.  He didn't need to do much the rest of the game, as Jimmy and Heyward took over.  I don't remember the score, but I don't think it was too close.
