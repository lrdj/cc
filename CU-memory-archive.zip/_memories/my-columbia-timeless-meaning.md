---
title: 'My Columbia: Timeless Meaning'
author: Rich Koesel
tags:
- Core Curriculum
- Religion
- Spirituality
- Academics
- Library
- Study spots
- Arts
- Culture
- Relationships
- Personal growth
- Reflection
layout: memory
schools:
  CC: 1993
primary_year: 1993
---
# Timeless Meaning

The rigors of the Core Curriculum saw to it that I read what seemed like an infinite number of pages of the collective wisdom of Western Civilization.  Unfortunately, I have a far greater appreciation for that now than I did at the time.  But it wasn't one of the Classics that meant the most to me.  It was a little book called "The Tao of Pooh" by Benjamin Hoff.  This was part of the assigned reading for Introduction to the Study of Eastern Religions.  The idea of teaching the mysteries of Taoism by using Pooh and his friends as examples is sheer genius.  I've actually re-read the book a few times since and enjoy it more every time!
