---
title: 'My Columbia: Wien Hall, Tacos, and a Toilet: One Year in the 11th-floor Janitor''s
  Closet'
author: Hilary Weckstein
tags:
- Wien Hall
- Dorm life
- Campus
- Politics
- Activism
- Good trouble
- Personal growth
- Reflection
layout: memory
schools:
  CC: 2002
primary_year: 2002
---
# Wien Hall, Tacos, and a Toilet: One Year in the 11th-floor Janitor's Closet

86 square feet. There is really no way to understand the true meaning of the size without spending a year in my sophmore-year dorm room. During the housing lottery, I went to explore my room only to find that the door had been painted shut - from the inside. This probably was meant to serve as my first warning. Let's just call it strike one.

On the day I moved in, the room was unfurnished and uncarpeted (yet freshly painted) and my long-awaited and well-deserved private "bathroom" was a toilet in the corner of the room. Strrrrike two. The doorway was too small to move in a full-sized desk, but I made due with a mini-desk against one wall, situated parallel from the bed. The edge of the desk and the edge of the bed were approximately 12 inches apart.

But let's not forget the toilet. The room's one saving grace was that I went the entire year without any embarassing stories requiring the use of  "bodily functions" and "Jake Gyllenhaal" in the same sentence. All this, and I could still parade around the hall in my towel (sigh - memories of my 19-year-old figure). Strike two and a half?

The last straw: being from DC, I had never seen those little red ticks that leave a stain when smushed. A few days before finals, however, I awoke to a room COVERED in the little bastards. My treasured toilet turned almost solid red as i watched the little bastards parade across my posters (sophmore year - probably pictures of naked celebrities and advertisements for 40s). One of the more traumatic episodes of my college years, the day represents the first of many times that I mistakenly believed I was losing my mind. This time really was a mistake; the mysterious bugs were real. I threw in some poison and spent the rest of the semester on a girlfriend's floor. Strike three.
