---
title: 'My Columbia: Late Nites and Early Mornings'
author: Nathan Payne
layout: memory
schools:
  GSAPP: 2004
primary_year: 2004
tags:
- Winter
- Weather
---
# Late Nites and Early Mornings

In the architecture program, everybody has to stay up late to meet impossible deadlines. The result of that is a bond among fellow students that makes the studio atmosphere so unique. You spend every night together and then make it through to breakfast the next morning. We used to take our breakfast at Tom's--a grilled cheese sandwich with bacon. It was so greasy, but it was always the breakfast of choice that we would wait up all night for. The only real question was: who would be brave enough to suffer the cold walk and bring back 12 hot cheese-and-bacon sandwiches for everybody?
