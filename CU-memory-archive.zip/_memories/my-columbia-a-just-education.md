---
title: 'My Columbia: A Just Education'
author: Asher Rubin
tags:
- Barnard
- Dorm life
- Campus
layout: memory
schools:
  CC: 1958
primary_year: 1958
---
# A Just Education

When I was a freshman I led a panty raid on Barnard. We had at least 100 guys storming the Barnard dorm in search of underwear. (What trophy could be more valuable?) In the pandemonium I hit one room and snared some underwear which I hid under my jacket. As I emerged I was confronted by a burly cop who snarled, "And what do you think you're doing?" I replied, "Sir, I'm just trying to get an education."

Editor's Note: Asher Rubin, author and hero of this tale, now serves as the Deputy Attorney General of California.
