---
title: 'My Columbia: The Prettiest Part of Campus'
author: Elizabeth Valeri
layout: memory
schools:
  GSAS: 2005
  GS: 2002
primary_year: 2005
tags:
- Campus
- Winter
- Weather
- Library
- Study spots
---
# The Prettiest Part of Campus

Columbia has a beautiful campus.  In particular, the view from the windows of the East Asian Library looking out at night onto the lighted trees in winter is breathtaking.
