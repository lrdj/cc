---
title: 'My Columbia: Meeting My Wife'
author: wallace mahoney
layout: memory
schools:
  BUS: 1959
primary_year: 1959
tags:
- Relationships
---
# Meeting My Wife

I met my wife-to-be at a Newman Club mixer in 1957, two weeks after I got out of the Army.  In those days, the Newman Club was nominally Catholic; but their beer blasts were legendary and were open to all. She seemed quite friendly; but somehow she escaped before I could get her phone number -- and it took all my powers of persuasion to get the number from someone in the Newman Club office the next week.  I was getting my MBA from the Business School, and she was getting her MA in Early Childhood from TC.  One thing led to another -- I remember her dad said "Anything west of the Hudson is camping out" when I had to take a job in Cincinnati -- but we've had four kids and been married (with quite a few ups and downs) ever since.
