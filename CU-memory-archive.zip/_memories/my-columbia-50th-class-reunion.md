---
title: 'My Columbia: 50th Class Reunion'
author: Stan Edelman
tags:
- Columbia College
- Reunion
- Academics
- Library
- Study spots
layout: memory
schools:
  CC: 1999
primary_year: 1999
---
# 50th Class Reunion

On May 18-19, 1999, the Class of 1949 celebrated our 50th graduation ceremony. On May 18, 1999, I was nominated to give out the 1999 graduation pins to all the seniors of the graduating class of 1999 on the dais.

On May 19, 1999, at a luncheon in Low Memorial Library, I was awarded the Gold Medal from the Alumni Association of Columbia University.

Both of these events are etched in my memory. I guess I will always be a "Columbia graduate,"  having attended the College, the Columbia College of P&S, and serving my internship at Columbia-Presbyterian Hospital.

These are memories one never forgets.

With Love and Respect,

Stan Edelman, M. D.
