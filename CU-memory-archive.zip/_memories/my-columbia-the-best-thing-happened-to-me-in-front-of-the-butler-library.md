---
title: 'My Columbia: The Best Thing Happened to Me in FRONT of the Butler Library'
author: Malena Jackson
tags:
- Butler Library
- Campus
- Academics
- Lectures
- Library
- Study spots
- Personal growth
- Reflection
layout: memory
schools:
  JRN: 2005
primary_year: 2005
---
# The Best Thing Happened to Me in FRONT of the Butler Library

It was an early spring-like Saturday morning in the fall of '04.  I was brand new to June Cross's news reporting seminar.  I had always heard stories of how you should avoid being late to her class, and I wanted to follow this clear instruction to ensure my success as a journalism student.

My commute to the 9 a.m. until 4 p.m. course was an hour and a half, and I was usually on the road by 7 a.m. This morning was unlike no other, traffic was backed-up for miles.  I didn't have a second of traffic jam to spare; five minutes could make me 15 minutes late.

That morning I didn't arrive on campus until 9:45 a.m., and I was frazzled!  At that point, I decided to take a detour and headed to the Butler Library to figure out what to do.  Instead of going inside, I took a seat on the bench in front of the library and began to cry, silently, in disappointment.

My disappointment led to my decision to drop the course, because there was no way I could pass now.  As I sat there with my head hanging low, I looked up, and it was Kathy Palagonia, admissions assistant at the J-school.  We exchanged a kind hello, and she sensed my dismay.

I explained the situation and broke the news that I was planning to drop the class since I didn't make it on time that morning.  Kathy then explained to me that dropping June's class would hinder my graduating on time and make me ineligible to complete a television master's project.

Who knew?

It was at that moment, I knew this was divine intervention.  So I wiped away my tears, went into the library to grab a cup of joe, took a deep breath and made my way to the journalism school.

To make a long story even longer, my being late wasn't a big deal, I never let it happen again: my Saturday commute began at 6:30 a.m. instead of 7, I passed June's class and accomplished all the other good stuff that comes along with persistence and hard work.

That Saturday morning on the bench in front of the Butler Library helped shape my career as a student at the prestigious Graduate School of Journalism.

Thanks, Kathy Palagonia and to whoever is responsible for putting that bench there :-)
