---
title: 'My Columbia: Dr. Charles Frankel -- Five Years Later'
author: Thomas Nisbet
layout: memory
schools:
  CC: 1953
  GSAPP: 1955
primary_year: 1955
tags:
- Academics
- Lectures
---
# Dr. Charles Frankel -- Five Years Later

Dr. Frankel exposed this freshman to Contemporary Civilizations; each lecture, "lights" would go on!

He wrote the basic history of contemporary thought. I recall inquiring on the first day of class what faculty he was in, since instructors came from all faculties. "Philosophy, Mr. Nisbet." Later I found he was second to Irwin Edmund, head of the Philosophy Department.

The June of 1955, I was going to graduation, walking up Amsterdam Avenue and glancing at a newspaper.  I saw Dr. Frankel coming toward me.  "Good morning, Dr. Frankel."

He replied, "Good morning, Nisbet. How are things in architecture?" I mentioned that I was going to graduation that morning.

It had been five years!
