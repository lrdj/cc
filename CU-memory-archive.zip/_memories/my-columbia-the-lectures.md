---
title: 'My Columbia: The Lectures'
author: Malena Jackson
tags:
- Alma Mater
- Campus
- Academics
- Lectures
layout: memory
schools:
  JRN: 2005
primary_year: 2005
---
# The Lectures

Not a day goes by that I don't think about my beloved Columbia University.

I was drawn to share my anecdote when I read the question, "What's your favorite part of campus?"

I started thinking.

As a graduate of the school of journalism, Columbia taught me how to think, objectively.

Professors Martin, Cross and Cutbirth taught me that the phrase, "I don't know" is unacceptable.  "Think!"

That's exactly what I've been doing since I first entered through Columbia's gates.

I entitled this anecdote "The Lectures" because it's when I was in the midst of these that I used to pinch myself and think, "I can't believe that I am here."

I am forever grateful to my alma mater for equipping me to stand out and take notice in this ever-changing world.
