---
title: 'My Columbia: My Hang Time at CU'
author: James Comerford
layout: memory
schools:
  SEAS: 1983
primary_year: 1983
tags:
- Arts
- Culture
---
# My Hang Time at CU

Hang time at Columbia was the best. The swim center was a real favorite of mine--both the old pool and new. We used to have green towel chips...I wonder if they are still in use? Pickup B-Ball games in the old gym were always fun, along with intramural vollyball in the new gym. The libraries were a great place for me to hang out. I used to know all the copy machines in all the libraries. Mathematics had a great machine (hidden under a staircase) for a nickel a copy. One year I had to xerox chapters of a Diff EQ book on an as-needed basis because I couldn't afford the book. If only I could be a starving student again--because somehow you only remember the good times and never the bad. I wonder if I could still navigate my way from Broadway to Amsterdam completely inside Teachers College.
