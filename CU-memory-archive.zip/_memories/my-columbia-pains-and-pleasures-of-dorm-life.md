---
title: 'My Columbia: Pains and Pleasures of Dorm Life'
author: Thurka Sangaramoorthy
layout: memory
schools:
  BC: 1998
  SPH: 2002
primary_year: 2002
tags:
- Dorm life
- Campus
- Relationships
---
# Pains and Pleasures of Dorm Life

It was painfully obvious from the first day that I met my first-year roommate that we were different. She had a shaved head, had piercings and tatoos all over, and drank out of a baby bottle. Yes, a baby bottle with a nipple. I, on the other hand, had long wavy hair, the standard single ear piercing, and had never really held a baby bottle. I was excited though to get to know her and to get beyond what seemed like superficial differences. As the weeks went by, things became very difficult as I realized that superficial differences sometimes unfortunately represented deeper divides. Not only was she emotionally unstable, but her uncleanliness was out of hand, and I finally drew the line at finding shaved hair and unwashed nipples all over our tiny little room as well as violent emotional outbursts. It was hard enough being new to the city, not knowing anyone, and starting college; I simply could not take such stress in my residential life. I began to have regular discussions with my RA and through some miraculous event, she found someone who was having similar issues with her roommate. This woman and I met and really hit it off, and we decided to move in together. I am happy to report that she (new roomie) and I are still great friends and often reminisce about those awful first days of college which eventually led to the beginnings of our more than decade-old friendship.
