---
title: 'My Columbia: Artsy Experience'
author: Franklin Mirer
layout: memory
schools:
  CC: 1966
primary_year: 1966
tags:
- Arts
- Culture
---
# Artsy Experience

So, I was trudging through the MoMA looking for the assigned works of art for Art Humanities, preparing for the final.  As best I remember, the only bench in the whole museum was in front of Guernica, which was also on the list.  To fill out my break time, I tried to compose something "insightful" about the painting in front of me, for maybe 15 minutes.

Guess which painting was assigned for the essay on the final?  If it hadn't been Guernica, I wouldn't be writing this story.

PS:  I got a pretty good grade for a chemist and engineering school transfer.
