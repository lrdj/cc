---
title: 'My Columbia: Columbia Spirituality: Buddhism'
author: Jefferson Svengsouk
layout: memory
schools:
  CC: 1990
primary_year: 1990
tags:
- Spirituality
- Religion
- Buddhism
- Academics
- Library
- Study spots
---
# Columbia Spirituality: Buddhism

As a Theravada Buddhist by family tradition, I arrived at Columbia with a cultural exposure to layperson Buddhist practice, as well as a superficial understanding acquired through the excuse of getting out of bible study class at my Episcopalian high school.

My understanding of the deeper and more metaphysical concepts of Buddhism and their application to the real world grew one hundred fold through two classes: Introduction to Eastern Religions and Buddhist Ethics.

Columbia is incredibly blessed to have Uma Thurman's dad, Robert Thurman, on faculty. The teaching I received in his Buddhist Ethics class has shaped and inspired my practice of Buddhism to this day.
