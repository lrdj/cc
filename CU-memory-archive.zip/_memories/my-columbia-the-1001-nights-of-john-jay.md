---
title: 'My Columbia: The 1001 Nights of John Jay'
author: Xiao Miao
tags:
- John Jay
- Food
- Dining
layout: memory
schools:
  CC: 2004
primary_year: 2004
---
# The 1001 Nights of John Jay

1am on a weeknight will find most working people either asleep, preparing to go to sleep, or wanting to go to sleep.  For the people of John Jay 7 it was different: 1am or thereabouts was when we collectively rocked down to JJÃ¢â¬â¢s Place for some horrifically greasy but curiously irresistible food (it had become an institution).  After ingesting the nasty stuff, we would hike back upstairs to resume our circus show.  Night after night, we unwittingly turned a narrow corridor - which seemed to have been designed for a life of lonesomeness or quietude - into a North African bazaar or something like it, full of smells, sights, and sounds.  On any given night: a shriek here, a patterned array of fire on the floor there; a topless (male) diver riding on a scooter to the left (JJ7 people: we all know who this is), and a guy with a camcorder filming an angry RA on the right.  The sounds made it almost impossible to sleep, but no one wanted to anyway.  Tales of life on JJ7 required no exaggeration for embellishment.  It was weird.  It was memorable.  It was great.
