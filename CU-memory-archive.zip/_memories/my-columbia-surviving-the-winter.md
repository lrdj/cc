---
title: 'My Columbia: Surviving the Winter'
author: Craig Blackmon
tags:
- John Jay
- Dorm life
- Campus
- Winter
- Weather
layout: memory
schools:
  CC: 1988
  TC: 1992
primary_year: 1992
---
# Surviving the Winter

Growing up in California, my father was a fresh air fanatic.  He insisted that you should always sleep with a window slightly ajar for some fresh air.  That worked fine in California, but it created some problems in NYC.  As instructed by my (presumably) wise father, I cracked my window in my modest John Jay dorm room immediately upon moving in.  In approximately mid-November, I developed a persistent, hacking cough.  About a month later, one of my floor-mates, a native New Yorker, saw that my window was open and said, "What's your problem?  Are you trying to kill yourself?  It's FREEZING outside!"  I put two and two together, closed the window, and went on to survive my first winter on the East Coast.
