---
title: 'My Columbia: Suite Accident'
author: Robert Blohm
layout: memory
schools:
  GSAS: 1997
primary_year: 1997
tags:
- Dorm life
- Campus
---
# Suite Accident

In my final year of residence, I was entitled to live in the suites located on 113th street. The hallway of my suite was too narrow for a closet door to open completely and be placed back against the wall. The closet door was part opened when I once rushed down the hallway late one evening, squarely hit the corner of the door between my eyes, and bled from the resulting cut. On the phone, Columbia Health Service instructed me to go to Beth Israel Hospital's emergency room, where I had never gone before (across from Gracie Mansion). It was the best emergency room experience I ever had. It was virtually empty of patients and fully staffed. So I walked right through, and they treated me very well. Compare it to waiting among gun-shot-wounded patients at St. Luke's.
