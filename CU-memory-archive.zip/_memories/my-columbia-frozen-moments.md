---
title: 'My Columbia: Frozen Moments'
author: Christopher  Hagan
layout: memory
schools:
  GS: 2002
primary_year: 2002
tags:
- Academics
---
# Frozen Moments

All our states of elevations

They lead to our creations

They're a festival of life

In which we show appreciation

But if we live for elevations

That come from our creations

Our lives move back on the road to disintegration

Because they're not the whole thing

They're only a part

And right from the start

Let's not have blown it

Because they're only frozen moments

They're only frozen moments

They're only frozen moments

They're isolated love

That's captured like a dove

Protected, treasured, safe

And highly spoken of

But if we get caught in a cage

We'll have to break out with a rage

And that's no way to live

In this day and age

Because they're not the whole thing

They're only a part

And right from the start

Let's not have blown it

Because the're only frozen moments

They're only frozen moments

They're only frozen moments

They're visions locked in space

Designed to help the human race

Moving the masses ever forward

And not keeping them in place

But if they are to do their job

And not become the god

We must let go... so

The future is not robbed

Because they're not the whole thing

They're only a part

And right from the start

Let's not have blown it

Because they're only frozen moments

They're only frozen moments

They're only frozen moments

Now...Now .. wait a moment

They're only frozen moments.

Christopher Hagan

The School of General Studies

Class of 2002
