---
title: 'My Columbia: Co-ed Bathrooms'
author: Karla Morales
layout: memory
schools:
  CC: 1994
primary_year: 1994
tags:
- Dorm life
- Campus
---
# Co-ed Bathrooms

I remember moving into Furnald dorm for my junior year and realizing for the first time that not only was the floor co-ed, but the bathrooms were, too.

I noticed that in the stall next to me the unusually large feet were turned in the opposite direction, towards the toilet.  After my initial worry that I had entered the wrong bathroom, I did a "duh" and finished my business.
