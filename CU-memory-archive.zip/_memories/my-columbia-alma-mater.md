---
title: 'My Columbia: Alma Mater'
author: Jeffrey Newman
tags:
- Alma Mater
layout: memory
schools:
  GS: 1998
primary_year: 1998
---
# Alma Mater

I was always a big fan of the '60s experience at Columbia University. The great minds that met there, the thought process that started with Ginsberg and bloomed into the generation of love and peace. The most enduring image of the entire 1960s to me is Tom Hayden, fist raised, seated in Alma Mater's lap. When I sat at her feet for the first time, a copy of the Strawberry Statment in my hand, 20 some odd years later, I felt the connection to the past, albeit recent, that is such a part of the Columbia Experience. That was my "happy" zone many times in my four years at Columbia.
