---
title: 'My Columbia: Busta Rhymes Concert'
author: Sarah Hsiao HuYoung
tags:
- Bacchanal
- Butler Library
- Alma Mater
- Winter
- Weather
- Library
- Study spots
- Music
layout: memory
schools:
  CC: 2002
primary_year: 2002
---
# Busta Rhymes Concert

I was only a senior in high school, visiting my future alma mater.  It was pouring, but the steps were packed with black umbrellas and plastic ponchos.  And there was Busta Rhymes jamming in front of us.  It was Bacchanal, Spring of 1998.  Students were in good spirits, despite the cold weather, because they were getting a free concert.  Butler library served as the backdrop.  A hip-hop concert, in the middle of one of the most elite colleges in the country?  I was sold.
