---
title: 'My Columbia: Hang Time'
author: RIch Koesel
tags:
- Core Curriculum
- Academics
- Library
- Study spots
layout: memory
schools:
  CC: 1993
primary_year: 1993
---
# Hang Time

One of my favorite places to hang/study was the Hungarian bakery a couple of doors down from V&T's Pizza.  I eventually found the right balance of caffeine and sugar to keep me sharp while working through the Core Curriculum...
