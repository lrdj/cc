---
title: 'My Columbia: Biafra Refugee'
author: Chuba Udokwu
layout: memory
schools:
  SEAS: 1978
primary_year: 1978
tags: []
---
# Biafra Refugee

I came to Columbia School of Engineering in September 1972. At that time I was relatively new to the country and New York City. I came from Biafra (just after it was defeated by Nigeria). My early experiences at Columbia were very educational both from a social stand point and of course academically. Living in New York City was the best launch for any person in this society. But Columbia provided for me a quality education, and an excellent launch into my career. My journey through this society has been very interesting; sometimes challenging. However my solid grounding from Columbia has carried me through.

I now live in Massachusetts after many years of living in the New York City area. However, my roots in this country are between Broadway and Amsterdam, somewhere around 116th St.
