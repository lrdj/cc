---
title: 'My Columbia: Look Up'
author: Peter Mondello
layout: memory
schools:
  GS: 1978
primary_year: 1978
tags:
- Campus
- Winter
- Weather
- Spirituality
- Religion
- Academics
- Lectures
- Library
- Study spots
- Arts
- Culture
- Abroad
- Travel
- Relationships
- Personal growth
- Reflection
---
# Look Up

My spiritual experience at Columbia was, in a word: awful. Before becoming a student at Columbia I was baptized and confirmed in the Episcopal Church. I grew up in Huntington, Long Island, New York. This was a great place when I was a young kid. I spent many wonderful days running around in the huge potato farms and sunny green meadows, barefoot and chasing after butterflies with my friends, our trusty dogs always at our sides, Wham-o slingshots stuffed in our back pockets. We were sort of upper middle class and many of my friends were of Irish, English and Jewish ethnic backgrounds. I loved my friends and my childhood was very carefree and happy.

My dad had his own advertising art business in New York City that he enjoyed and was very successful at. Coming out of the Depression, he became quite materialistic, and we never lacked for material things. Somehow we were Episcopalian rather than Catholic, which was a little unusual for a New York Italian family. My dad was not very religious, but he made sure that my older brother, Joe, and I were baptized as infants and that we went as far as Confirmation in Saint John's Episcopal Church. I did not realize it at the time, but I actually think I was saved (born again) during those Confirmation classes when I was about age 12. I knew there was something really special about Christ and God and the church, but I was not at all sure what or why. I remember Cannon Rogers the priest wearing his black suit with the white clerical collar and chain-smoking one cigarette after another as he taught our all boys Confirmation class in the church rectory. I got my official Episcopal Prayer Book and read the prayers with special reverence, but that was about it. After Confirmation, where we boys went forward one Sunday morning and kissed the Bishop's ring after he anointed our heads with some oil, we were set free with no further religious duties. I had some sense that there was a living God out there somewhere, and I especially liked the Easter resurrection symbolism with all the cherry blossom flowers and palm branches. Palm branches in New York seemed very exotic to me, and we twisted them to make little green crosses that we gave to Sunday school students after services around Lent.

For years I carried God around with me sort of like my old Wham-o slingshot. He was always there if I needed Him, but mostly believed I was to take care of things by my own efforts. I considered Him my emergency kit, safely tucked away in the trunk if needed. At College I found the Bible was generally regarded with disapproval. I remember one professor telling me that his girl friend would sit on it "for inspiration" while she played the piano. Science classes clearly placed reason and the theory of evolution as superior to faith in Scripture. During my stay at Columbia I read Jacques MonodÃ¢â¬â¢s book "Chance and Necessity," and it really threw me for a loop. After reading it, life seemed to me nothing but an accident of chance, void of authentic meaning and purpose. Sadly, though Columbia is literally surrounded by spiritual institutions such as Riverside church, the cathedral of Saint John the divine, Union Theological seminary, the Jewish Theological seminary and Saint Paul's chapel right on campus, I never got plugged-in to study and know the God of the Bible. After graduating from Columbia University I married my high school sweet heart at Saint John's Episcopal Church in Cold Spring Harbor, Long Island, and I was a happy young man. My brother and I were taking over Dad's business downtown NYC, and things were pretty nice and good. My wife, Diane, and I traveled to China for our honeymoon, made other trips to Italy and Hawaii and were somehow spared the troubles and problems that seemed to plague much of the world.

Without going into detail, all that changed abruptly one day. A whole series of deaths hit my family like sledgehammer blows, one after another. My wife's father died of colon cancer, my uncle died of a heart attack, two of my aunts suddenly died, my brother's wife, Jane, suddenly died of a heart attack at age 26 (she had a heart problem, but it was still a terrible shock), then Diane and I lost our second child at birth (full term, but still born) and Diane received multiple blood transfusions in November 1984. Things seemed to quiet down for a little while, and we had our third child in June 1986, but she (Tamara) became very sick and was soon hospitalized. By December, at age 6 months she was diagnosed with Pneumocystis Carinii Pneumonia, and she died. Diane died just three weeks later. It turned out the blood transfusions were tainted with HIV. I was suddenly a widower and a single father with a three-year-old daughter. Unfortunately, my Columbia education offered very little to help me to cope with these sudden losses. I struggled searching in my heart and thoughts for years afterwards trying to make sense of what had happened. Finally, I believe it was my Christian education from my youth in the Episcopal church that gave me a notion of hope.

I can see this is getting way too long, so I will stop here. Some good news is that I was not infected with HIV. My daughter, Katie, is now 22 years old and happily married, well employed and attending graduate school studying English. I found out that God is not my "emergency kit" in the trunk, but rather He is everything, the engine, the wheels, the driver, the fuel, etc. I trust Christ, and I seek to know Him more and more deeply. At the age of fifty I enrolled in seminary and I am studying the Bible with great joy. My advice for present day Columbia students: Look up! In Lumine Tuo Videbimus Lumen "In Thy light shall we see light."
