---
title: 'My Columbia: Best Sporting Event at Columbia'
author: Eic Hirschhorn
tags:
- Barnard
- Sports
- Athletics
layout: memory
schools:
  LAW: 1968
primary_year: 1968
---
# Best Sporting Event at Columbia

Football--Cornell at Columbia--fall 1966.  My roommate was dating a Barnard student whose younger sister was attending Cornell and came down to NYC for the game.  I was fixed up with her younger sister, who turned out to be (my two wives excepted) the Most Beautiful Woman I'd ever gone out with.  I think Cornell won in the rain, but I wasn't exactly paying attention to what was transpiring on the gridiron.  Alas, it was my one & only date with her--so not one of those, "We've been together for 40 years..." tales, I'm afraid, but memorable nonetheless.
