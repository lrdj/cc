---
title: 'My Columbia: Boy Meets 616'
author: Andrew Arnold
tags:
- Barnard
- Campus
- Academics
- Library
- Study spots
- Food
- Dining
- Relationships
layout: memory
schools:
  CC: 2003
primary_year: 2003
---
# Boy Meets 616

One of the highlights of my Columbia housing experience was sophomore year when an acquaintance from a Barnard linguistics class asked if I would be interested in joining a Japanese special-interest house.  I had just started studying Japanese at Columbia and thought it would be a great idea to live with other students with a similar interest.  We could cook Japanese food, practice conversation, and watch obscure movies.  But what sealed the deal was when my friend told me that we would be eligible for a special suite in 616.  Since I had arrived on campus only a few months earlier, I had always wondered what it would be like to live across the divide of Broadway.  I'd be closer to Ollie's; I'd be closer to the subway; I'd be closer to the girls.  My sophomore year living in 616 turned out to be a great experience.  Although I met lots of people I would never have met, and my Japanese improved substantially, I didn't achieve my most significant goal:  Junior year, I still wound up living in Wien.
