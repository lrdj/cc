---
title: 'My Columbia: James Farmer and the Cable Guy'
author: Mark Ramee
tags:
- Spectator
- WKCR
- Hamilton Hall
- Dorm life
- Campus
- Academics
layout: memory
schools:
  CC: 1963
primary_year: 1963
---
# James Farmer and the Cable Guy

In senior year I arranged for James Farmer, head of the Congress of Racial Equality (CORE), to speak at Columbia.  I reserved a large corner room in Hamilton Hall, infomed "Spectator" and WKCR, and put up flyers.   WKCR requested permission to record the address for subsequent broadcast.  I checked with CORE, and told WKCR that would be fine.

Shortly before the address, a WKCR rep arrived with a mike and a cable.  He said that the cable would run to an outlet in another room, to transmit to the station for subsequent broadcast.

But the cable was too short.

As the cable guy stressed out, Farmer arrived, and I introduced him.

Farmer electrified the audience.  He described his escape from Plaquemine, Louisiana at night in a hearse.  He recalled how some conflicted law enforcement officers, not quite ready to say "Mister Farmer," but seeking a more respectful term than "Farmer," addressed him as "M' Farmer."  He was dynamic and optimistic.

Throughout the address, the cable guy's eyes were wide, but his face bizarrely contorted.  Later, he explained that he had been simultaneously enthralled by the address and anguished that WKCR was missing it.

That summer, James Farmer missed the March on Washington.  Having returned to Plaquemine for voter registration, he had an extended stay with the local authorities.  Looking around the Washington Mall, I wondered whether the cable guy was there also.  I didn't remember his name.  But I will never forget his expression.
