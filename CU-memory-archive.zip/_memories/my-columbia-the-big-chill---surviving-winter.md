---
title: 'My Columbia: The Big Chill - Surviving Winter'
author: kelly koch
layout: memory
schools:
  CC: 1996
primary_year: 1996
tags:
- Winter
- Weather
- Politics
- Activism
- Good trouble
---
# The Big Chill - Surviving Winter

I wrap a headband around my ears and put a hat on, along with gloves and a scarf and a really warm and waterproof coat.  Then hit the streets, slopes, or whatever!!
