---
title: 'My Columbia: The Future'
author: Vincent Liggio
layout: memory
schools:
  SEAS: 1992
primary_year: 1992
tags: []
---
# The Future

The one thing I would tell my college-aged self, knowing what I know today, is to follow every dream. One never knows what you may find at the end of a particular path, and you won't know what is there without trying each one. Follow your dreams and you will be happy.
