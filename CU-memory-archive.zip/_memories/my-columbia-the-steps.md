---
title: 'My Columbia: The Steps'
author: Diana Goldberg
tags:
- Alma Mater
layout: memory
schools:
  CC: 1989
primary_year: 1989
---
# The Steps

When I was a student at the College, the most amazing place to sit back and relax was in front of Alma Mater on "the Steps." On a spring or summer day, and even into early fall, enjoying lunch or just a brief break on those tiers, with the sun streaming down, watching countless people from all walks of life hurry this way and that, was the ideal respite.
