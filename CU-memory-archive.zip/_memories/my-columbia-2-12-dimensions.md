---
title: 'My Columbia: 2 1/2 Dimensions?'
author: Cynthia Norman
layout: memory
schools:
  SEAS: 1987
primary_year: 1987
tags:
- Academics
---
# 2 1/2 Dimensions?

I sat at my desk, arms hanging to the side, furrowed brow, mouth slightly agape. It was a computer vision class, and Dr. Kender was talking about how we humans live in more of a two-dimensional world, rather than a 3D world. We get 2 1/2D sometimes, but rarely 3D. Intuitively, I knew he was on to something but my mind couldn't grasp it yet. It took many years and a lot of time sitting on my deck, watching ravens barrel roll through the air, enjoying all 3 dimensions of their world.

After my understanding solidified, I spent a lot more time looking up into the air. If my arms couldn't take me into the higher dimensions, at least my eyes could.

Thanks Dr. Kender!
