---
title: 'My Columbia: Car Alarms Near East Campus'
author: scott benbow
tags:
- East Campus
- 1980s
- Campus
layout: memory
schools:
  LAW: 1989
primary_year: 1989
---
# Car Alarms Near East Campus

In the late 1980s, New York City seemed to have more car alarms than cars. By the time I arrived in Mornignside Heights in 1986, car alarms rang with such frequency that they rarely, if ever, had their intended effect: alerting a passerby to call the police to report a crime in progress.

In my first year at Columbia Law School, I was assigned a room in a suite in East Campus. It was the room on the bottom floor, facing west, right above street level. It did not benefit from the spectacular views of the city that a lot of East Campus rooms had.

Every night during my first year of law school, car alarms would ring incessantly. While it bothered me at first, I eventually became immune to the sound and managed to work the noise into my dreams.
