---
title: 'My Columbia: IT''S SNOWING'
author: Antonio Vinals
tags:
- John Jay
- Dorm life
- Campus
- Winter
- Weather
- Sports
- Athletics
layout: memory
schools:
  CC: 1989
primary_year: 1989
---
# IT'S SNOWING

I experienced snow "for the first time again" when, at my freshman dorm (John Jay), the whole floor went out to baptize my next door roommate (who was from India) with a good old fashioned snowball fight.  We all later played touch football and almost had frostbite.
