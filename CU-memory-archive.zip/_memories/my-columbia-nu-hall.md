---
title: 'My Columbia: Nu? Hall'
author: arthur bernstein
layout: memory
schools:
  CC: 1964
primary_year: 1964
tags:
- Dorm life
- Campus
- Relationships
---
# Nu? Hall

In those glorious days of yesteryear when New Hall was unfinanced and therefore unnamed, women were prohibited from the dorm.  Surprisingly, this even applied to Vassar women, as I discovered one rainy day when I smuggled such contraband into my room.  Bad smuggling when wet footprints lead to your closet, which is where our floor counselor discovered the body--quite alive and embarassed--when he flung back the door.  Fortunately, our floor counselor was in the School of Architecture, headed in those days by the father of a close friend and fellow student, on whom I prevailed to exert appropriate pressure to have the incident forgotten (perhaps I still have a career awaiting me in Mr. Cheney's administration).  This was but one of many occurrences which led to my occupancy, with friends, of a 2-bedroom apartment on 99th and West End Avenue---for the princely sum of 162 rent-controlled dollars per month...eat your yuppified West Side hearts out.....
