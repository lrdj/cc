---
title: 'My Columbia: Closing Broadway'
author: Kristen O'Brien
layout: memory
schools:
  BUS: 1998
  BC: 1991
primary_year: 1998
tags:
- Sports
- Athletics
- Arts
- Culture
---
# Closing Broadway

The Columbia football team was fighting a four-year losing streak.  The joke was they should play Macalaster (a college in my home town, St. Paul, MN), the other (much smaller) college with the four-year losing streak.

I missed the game that broke the streak, and I think it was again Princeton, but as word started coming down Broadway, students flooded to the streets.  At first we stuck to 114th street (Fraternity Row) but quickly the crows swelled and waves of students crossed over onto Broadway.  Traffic came to a standstill as we blocked the main artery.  Cameras in hand, we cheered the muddy porters of the goal post who brought the pole from 218th street.  We milled around, ignoring the police and giddy with power over traffic and our opponent.  It was about time, we said, and what a win!
