---
title: 'My Columbia: Community/Columbia'
author: Luis Rios
layout: memory
schools:
  GSAS: 2002
  SIPA: 2002
  TC: 2002
primary_year: 2002
tags:
- Academics
- Lectures
---
# Community/Columbia

Amidst graduate seminars at the Casa Hispanica, Teachers College, and SIPA, I worked at Community Impact's adult education program where I supervised Columbia volunteers in ESL classes in Washington Heights, taught ESL and Spanish GED Social Studies. It's really memorable to me that there I was teaching and working, representing Columbia and contributing valuable community service in the area.
