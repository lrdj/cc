---
title: 'My Columbia: GS Hangout'
author: Whitney (Kelting) Keen
tags:
- The West End
- Campus
- Academics
- Library
- Study spots
layout: memory
schools:
  GS: 1973
primary_year: 1973
---
# GS Hangout

During the late 60's and early 70's, a group of about 10 of us from GS, along with a few grad students, used to hang out regularly at the West End bar. There was a long banquette that curved around, with a table and a few chairs that we clalmed as "ours," and woe betide anyone who tried to sit there after 4 pm.  They would find 14 people standing in front of the table staring at them until they moved.  We occupied the "elbow" at the West End pretty much every day, with people coming and going as they came from and went to class, drinking pitchers of beer and, if hungry, getting dinner. The group tended to break up around 10, with people going either to the library or home at that time. Since we were all "day students," this was the center of our campus life.
