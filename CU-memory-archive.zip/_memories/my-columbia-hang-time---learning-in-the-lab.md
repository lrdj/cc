---
title: 'My Columbia: Hang Time - Learning in the Lab'
author: Stuart Locker
layout: memory
schools:
  SEAS: 1982
primary_year: 1982
tags:
- Campus
- Library
- Study spots
---
# Hang Time - Learning in the Lab

When I went to Columbia, my favorite place to study was the lounges in what was then the new science building attached to the Engineering building. The building was relatively new and no one knew about the lounges overlooking the campus. I could sit up there, totally relax, look at the crowds, and then study with no interruption. I studied for all my finals there and know it helped me succeed.
