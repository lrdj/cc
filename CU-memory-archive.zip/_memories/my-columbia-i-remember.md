---
title: 'My Columbia: I Remember'
author: Arthur  Santiago
tags:
- Hartley
- College Walk
- Dorm life
- Campus
- Music
layout: memory
schools:
  CC: 1979
primary_year: 1979
---
# I Remember

I remember blasting David Bowie and Aerosmith to get pumped up before a wrestling meet. I remember the sounds of James Taylor and Jorma Kokonen during those intimate moments at Hartley Hall, and the beat of NYC's own Ramones to release tension after midterms. I remember Bach's Brandenberg Concerti going well with a Foster's and a TAKOME hero (the sauce on every hot sandwich was the same} on a beautiful spring day on college walk. I also remember the day the music died for a short time after the Livingston Hall fire of '76-'77.
