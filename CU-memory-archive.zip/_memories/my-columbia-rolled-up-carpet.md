---
title: 'My Columbia: Rolled-up Carpet'
author: Gia Machlin
layout: memory
schools:
  SEAS: 1987
  BUS: 1991
primary_year: 1991
tags:
- Dorm life
- Campus
---
# Rolled-up Carpet

Freshman Year, Carmen Hall, 8th floor (1983)

Jon, John, & Steve find a rolled up carpet in a dumpster and say, "Hey, that would look great in our dorm room." They get in the elevator and try to fold the rolled up carpet, but it is heavy and stiff. Once they get to the 8th floor they drop the carpet on the floor in the hallway--and feet stick out of one end. They begin to unroll it and find a dead body in the carpet!

Now that's a dorm story!
