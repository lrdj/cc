---
title: 'My Columbia: Best Title'
author: Peter Herman
layout: memory
schools:
  GSAS: 1989
primary_year: 1989
tags: []
---
# Best Title

The best comment I heard was actually the title of an essay on Dante's "Inferno" for Literature Humanities: "To Hell with Dante"!
