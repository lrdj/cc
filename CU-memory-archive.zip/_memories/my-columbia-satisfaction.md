---
title: 'My Columbia: Satisfaction'
author: HENRY ALAN RAYMOND
layout: memory
schools:
  GS: 1972
primary_year: 1972
tags:
- Arts
- Culture
---
# Satisfaction

My most memorable day at Columbia was not marching with thousands down Seventh Avenue, "Grease under the Stars" with Sha Na Na, the penthouse Hollywood party I tended as a member of Columbia Student Bartenders, or even getting knocked out while playing rugby against Harvard. It was really an evening and a day, which started when I was walking down Central Park West with a load of books which I was returning to a girlfriend.

I remember earlier in the day wishing that I could meet a mugger before I graduated, so I could take out my frustrations of being legally ripped off for the past several years in NYC. Sure enough my wish was granted when the would-be mugger came up to me brandishing a knife and demanding money. I dropped the books and grabbed both his wrists, kneed him in the stomach, knocked him over a low fence and came down on top of him, yelling for the police. I soon wrestled the knife away from him and started to interrogate him, holding the knife on him, bashing him now and then to keep him quiet. Nevertheless, he began to yell "Brothers, help me!" to some black passers-by.

When they came up to us, I told them to get a cop, as this guy tried to rob me. This they did, but when the cops arrived they were not quite sure who the mugger was. They thought it was probably him because of the way he was dressed. They took us down to the station, him in the back and me in the front. When we got to the station they left us in the car, to listen in on the radio to confirm who was the mugger. I knew they were doing this so I started to yell at him repeatedly as to how he was a sinner and his only route to salvation was to CONFESS! to the judge, to me and to the police. He responded in his terrified state: "I CONFESS! I DID IT!" The police almost fell down the station steps laughing. The police asked to come to court at the Toombs the next day for the arraignment.

The next day, they picked me up at 8 a.m. in a "Paddywagon" filled with hookers who screamed everytime we hit a pothole on the way to lower Manhattan. When we got there, we found that the arraignment had been postponed until 3 p.m. This did not phase the two policemen, who were on overtime and suggested that we retire to the local police bar till 3 p.m., where they regaled me with police stories and beer.  "We need men like you on the force!," the large Irish policeman said. "We get two months paid vacation, and when I go home each year they think I am a millionaire," the small Greek policeman said.

Several beers later, we entered the courthouse, none of us too steady on our feet. I first observed the mugger repeatedly insisting "I did it!" like a parrot before the judge. The judge had a puzzled yet bemused look. A social worker popped up and said since he was a young fellow and confessing, she would like get him into the "Court Employment Project" if we would agree to a suspended sentence.

The policemen and I were then happy to agree to anything, but then the ADA said he could not agree to this as the offense was armed robbery. He looked more closely at us and decided he did not really want go to court with us. "OK," he said, "I guess we can make an exception since you took the knife away from him." The would-be mugger got ajob as a freight elevator operator and a two-year suspended sentence. I grduated from Columbia the following week and went on my way to the University D'Aix-Marseille, in Aix-en-Provence, to pursue a course in French Literature.
