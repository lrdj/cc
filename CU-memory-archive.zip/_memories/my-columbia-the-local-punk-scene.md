---
title: 'My Columbia: The Local Punk Scene'
author: Roger Keller
layout: memory
schools:
  CC: 1981
primary_year: 1981
tags:
- Music
---
# The Local Punk Scene

When I first arrived at Columbia, I was put on the fencing "jock" floor because I was going to be on the fencing team.  I was not a jock.  After first playing clarinet with the marching band, I finally found my freedom and my survival in music.  In the late 70's, the punk scene was exploding at Columbia.  The years at Columbia were rough, and I know I would not have survived if it hadn't been for rock 'n roll.  We were driving with my son years later and thanking Jesus for different things and my son must have caught an echo of my Columbia years becasue he said, "thank you, Jesus, for rock n' roll."

Anyway, we went down to CBGB's a lot then, and saw the Mumps and other bands, with our quart bottles of Colt 45 (I was a drinker then).  I put together a band with my brother (a Columbia alum) called Roger's Problem.  When we started it up at Columbia it was called Viscous Bulbi.  We played CBGB's.  It was cool.  Unfortunately, I was so drunk on stage I just felt like sitting down after the first song.  We debuted at Carmen Lounge and the audience responded well.  It was great to be singing these songs about our rage and depression and have people like it.  I remember other great bands at Columbia--The Power Tools ruled!

I still do music now, and some of it is still dark.  But I don't think I would've gotten into music so much if I hadn't been in NYC at Columbia, coming from a repressed background into musical freedom.  The guitar was more of a weapon of expression for me than an instrument.  I hope bands are still rockin'--although the Lion's Den and the other large performance area (I can't recall the name) are all gone. Rock on Columbia!  Don't let your studies interfere with raw expression!
