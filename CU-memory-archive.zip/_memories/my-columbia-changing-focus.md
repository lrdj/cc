---
title: 'My Columbia: Changing Focus'
author: Fidel Louis
layout: memory
schools:
  CC: 1986
primary_year: 1986
tags: []
---
# Changing Focus

My mentor, Everett Dennis of the Journalism School, once handed me a pen that had no ink and bristled: "What do you do now?"
