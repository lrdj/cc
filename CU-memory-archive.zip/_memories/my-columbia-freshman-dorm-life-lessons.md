---
title: 'My Columbia: Freshman Dorm Life Lessons'
author: Antonio Vinals
tags:
- John Jay
- Dorm life
- Campus
- Personal growth
- Reflection
layout: memory
schools:
  CC: 1989
primary_year: 1989
---
# Freshman Dorm Life Lessons

My religious experience at Columbia began from my first day moving in to John Jay hall as a Freshman, where I lived adjacent to an Orthodox Jewish student, a Muslim, a Buddhist and an atheist!  I grew up as a Roman Catholic.  Watching each student go through their religious requirements throughout the week, at each meal, and on certain days of the week was an interesting and new experience for me.  The ability to stay up late at night, have deep, meaningful discussions about world affairs, and see how their unique religious beliefs influenced their thoughts was a mind-opening experience that forever changed me.  While I did attend my own religious ceremonies on occasion, I felt that these colleagues that I mentioned were more connected and influenced by religious belief--and that it was not detached from their daily lives as it was for me.
