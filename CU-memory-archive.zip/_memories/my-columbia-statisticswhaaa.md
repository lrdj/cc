---
title: 'My Columbia: Statistics...Whaaa?'
author: Michele Moucatel
layout: memory
schools:
  SPH: 1997
primary_year: 1997
tags:
- Academics
- Politics
- Activism
- Good trouble
- Relationships
---
# Statistics...Whaaa?

It had been 11 years since I graduated from college with my bachelor of science in nursing, and I was very anxious about going back to school - papers, exams, etc., not to mention the fact that I worked full time and this was to be a part-time program for me.

Prior to registration, I had to take a statistics exam to determine in which level class I would be placed.  Never having had a fondness for math, I failed miserably and was told to take a remedial class prior to registration.  What a blow to my ego and confidence!

I met with my advisor, Dr. Bernard Challenor from the School of Public Health, and immediately found him to be one of the warmest professors I had ever met.  I explained my situation, and he reviewed my file with me.  I still remember his words: "Go and register for your classes; you don't need any remedial courses."  I'm not sure what it was about the way he said that, but he instilled such confidence in me that I did what he recommended.  Naturally, he was right, and I breezed through my statistics course that first semester.

Thereafter, I met with him quarterly and two years later took his course in health care.  My four years at Columbia were wonderful because of my initial experience with him.  When Dr. Challenor died I felt that I had lost a dear friend, and Columbia too suffered a great loss.
