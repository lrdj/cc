---
title: 'My Columbia: "Great Minds of My Generation"'
author: Peter Kenton
layout: memory
schools:
  LAW: 1952
primary_year: 1952
tags:
- Academics
---
# "Great Minds of My Generation"

The greatest mind of my generation, it was my privilege to know, belonged to my classmate, the late and much regretted Allan Farnsworth. 

All members of our class were proud of the first Columbia Law student in 25 years to receive an A++ in a first year course. Moreover, in the course of a 53-year (and continuing) career, I can count on the fingers of one hand those I knew who were highly successful and still had time to be sincerely nice to everyone. Allan was one of them.
