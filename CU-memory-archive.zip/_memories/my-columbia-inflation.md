---
title: 'My Columbia: Inflation'
author: Saul Ricklin
tags:
- Reunion
layout: memory
schools:
  CC: 1939
  SEAS: 1940
primary_year: 1940
---
# Inflation

As I remember it, my Columbia tuition in 1935 was $300. I appreciated what inflation meant when I paid $500 for my 50th reunion in 1985 at Harriman House!
