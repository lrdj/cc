---
title: 'My Columbia: Question for the next century'
author: Thomas Wm. Hamilton
layout: memory
schools:
  CC: 1960
primary_year: 1960
tags:
- Politics
- Activism
- Good trouble
---
# Question for the next century

Questions for the next century:

How can we bring government back under control after letting it oppress us more and more -- pretty much continuously since World War I -- in response to various perceived threats?

1968 was not "quaint."  It was, perhaps, a distant and weak harbinger of what will be necessary to regain America.
