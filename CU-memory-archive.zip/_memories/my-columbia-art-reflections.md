---
title: 'My Columbia: Art Reflections'
author: Sally Cantor
layout: memory
schools:
  SW: 1973
primary_year: 1973
tags:
- Academics
- Arts
- Culture
- Relationships
---
# Art Reflections

I planned my class schedule to have Fridays free to visit art gallleries with my friend Cecilia, who was in the MFA program.  Pieces that were affordable then are selling in the millions today.
