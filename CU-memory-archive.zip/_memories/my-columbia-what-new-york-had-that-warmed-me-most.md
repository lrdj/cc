---
title: 'My Columbia: What New York Had That Warmed Me Most'
author: Kathryn Pitrone
layout: memory
schools:
  GS: 2002
primary_year: 2002
tags:
- Campus
- Winter
- Weather
- Academics
- Arts
- Culture
- Politics
- Activism
- Good trouble
---
# What New York Had That Warmed Me Most

I live in Ohio's snowbelt, now.  In my memory, New York, with streets on which the snow seemed to melt like magic, was warmth itself.  All fall, I loved taking the bus, and rode around looking at all that New York is.  But in the winter, I dove into the subways, where it was wet and steaming with a sodden humanity in a relative warmth.  Emerging onto Broadway outside the campus was like a daily rebirth into winter's bright cold. Clutching my books to my chest for their warmth, I hurried off to my classrooms to blanket myself with intense thought and heated discussion.
