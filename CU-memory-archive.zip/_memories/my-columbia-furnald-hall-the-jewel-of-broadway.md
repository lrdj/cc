---
title: 'My Columbia: Furnald Hall: The Jewel of Broadway'
author: Wanda Holland Greene
tags:
- Furnald Hall
- Dorm life
- Campus
layout: memory
schools:
  TC: 1990
  CC: 1989
primary_year: 1990
---
# Furnald Hall: The Jewel of Broadway

Say what you will about the less-than-sanitary shared kitchen and co-ed bathrooms in Furnald Hall: it was still a jewel to me and a fabulous place to live during junior and senior years.  Finally, I had a single room of a decent size (by New York standards), and the proximity of the amazing FURNALD GROCERY was terrific.  Does anyone else remember the soft bagels and endless supply of Bazooka bubble gum?  Aaahh....I'm in a New York state of mind.
