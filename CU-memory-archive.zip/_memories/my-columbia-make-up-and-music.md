---
title: 'My Columbia: Make Up and Music'
author: Nancy Park
layout: memory
schools:
  CC: 1997
primary_year: 1997
tags:
- Music
---
# Make Up and Music

I remember lining the eyes of certain members of Jonathan Fire*Eater and Desfite with black coal before their shows at the Cooler or Acme Underground. Those times froth with excitement.
