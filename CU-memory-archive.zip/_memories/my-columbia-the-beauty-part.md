---
title: 'My Columbia: The Beauty Part'
author: Roy Russo
tags:
- Core Curriculum
- Reunion
- Campus
- Academics
layout: memory
schools:
  CC: 1956
primary_year: 1956
---
# The Beauty Part

For me, now celebrating the 50th reunion of the College's class of 1956, the most beautiful site on campus was and remains the Casa Italiana in general, and its Teatro in particular.  I was honored to serve as the President of the Italian Club in 1955-56, under the guidance of Professoressa Olga Ragusa and the inspiration of Asst. Prof. Peter Riccio.  The Teatro was the venue for our senior year production of the play "La Mandragola" by Nicola Macchiavelli (also known to students of  the Core Curriculum for his treatise "The Prince") and for our annual masquerade ball "Carnevale."  The Teatro now also serves as a favorite location for annual gatherings of the College Fund Leadership Conference, an aknowledgement of its ongoing attraction to alumni from all over the country who volunteer to serve Columbia in a special and important way.
