---
title: 'My Columbia: Joseph Bernard Stern'
author: Mary Jo Bach Burton Marks
layout: memory
schools:
  NRS: 1957
primary_year: 1957
tags:
- Academics
---
# Joseph Bernard Stern

I took some classes the summer of 1952 to make up deficiencies so that I could enter the School of Nursing that fall.  One of the courses was Sociology, taught by Joseph Bernard Stern.  He used to tell us about being investigated by Joseph McCarthy's committee.
