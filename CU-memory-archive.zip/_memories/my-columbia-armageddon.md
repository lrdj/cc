---
title: 'My Columbia: Armageddon'
author: Mike Pybas
tags:
- Hartley
- Dorm life
- Campus
- Politics
- Activism
- Good trouble
layout: memory
schools:
  CC: 1955
primary_year: 1955
---
# Armageddon

In early September, 1952, I arrived on campus as a sophomore, a transfer from the University of Oklahoma.  It was my first visit to New York.

It was the Saturday before the Monday that Orientation of New Students would be held.  I was virtually alone in Hartley Hall, and was not long out of bed that morning when sirens began wailing all over the city. Strange, I thought: tornado drills in New York?

Since it was a very warm morning, I had opened my 8th floor window for a cooling breeze.  I looked outside to see if there were actually any tornadic clouds gathering.  Not only were there no clouds, there was no traffic on Amsterday whatsoever!  The street was absolutely empty of moving vehicles or pedestrians. What could be happening?

Then I heard the drone of aircraft.  Great, I thought: my first day in New York and some Evil Empire is going to drop The Bomb.  I ran down the hall to the communal bathroom, which is where the Shelter signs directed, and sat on the throne, waiting to hear the blast and feel the heat wave.

Instead, the all-clear sirens began their welcome song, and I emerged without a scratch.  At breakfast I learned that my ordeal was a full-scale atomic attack drill the city had scheduled.

Welcome to Columbia!
