---
title: 'My Columbia: Almost Like Hercule Poirot!'
author: Wolfgang Gilbert
layout: memory
schools:
  GSAPP: 1990
primary_year: 1990
tags:
- Academics
- Lectures
---
# Almost Like Hercule Poirot!

My favorite teacher definitely was Sig Grava, a distinguished guy who reminded me of Peter Ustinov playing Hercule Poirot. He carried clippings from the New York Times into the classroom and thus connected theory with real life! He was different from the other teachers, and one had to respect his privacy. On the other hand, he showed real interest in the students, and I always felt comfortable at his lectures and even writing my thesis under his guidance. Take care Sig!
