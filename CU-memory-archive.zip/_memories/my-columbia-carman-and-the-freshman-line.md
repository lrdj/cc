---
title: 'My Columbia: Carman and the Freshman Line'
author: David Shofi
tags:
- Carman Hall
- Dorm life
- Campus
- Academics
layout: memory
schools:
  SEAS: 1988
primary_year: 1988
---
# Carman and the Freshman Line

The first memory that I have of Columbia is getting into a long, snakelike line on the sidewalk of 114th Street outside Carman Hall with my parents after grabbing a parking spot somewhere in the neighborhood.  It was a sunny day and students were in tee-shirts passing out drinks and offering assistance.  My mom had not gone to college and my dad had commuted to NYU, so they were also experiencing the stomach flutters of the college experience growing closer for me.  The fraternities on "fraternity row" of 114th Street were welcoming sites as students gathered on these brownstone steps to sun themselves, talk to new students and generally welcome the incoming Class of 1988!  We must have stood on that line for an hour or more, but everyone looked the same... wide-eyed and eager to begin an incredible next four years.  As I look at my diploma on my office wall, I am reminded of the feelings that stirred that morning and I smile recalling my entry into Carman and Columbia.
