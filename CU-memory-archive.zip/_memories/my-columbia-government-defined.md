---
title: 'My Columbia: Government Defined'
author: Leland Moglen
layout: memory
schools:
  CC: 1966
primary_year: 1966
tags:
- Campus
- Academics
- Lectures
---
# Government Defined

Professor Rothstein taught Government 101. His most brilliant lecture included a piercing analysis, the definition of government broken down to its lowest common denominator: "That group which has 'legitimate' access to violence." The lecture occurred in 1963, right around the time the Flugg et al took over the campus and occupied the office of the President of Columbia University.
