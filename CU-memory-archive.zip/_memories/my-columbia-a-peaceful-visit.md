---
title: 'My Columbia: A  Peaceful Visit'
author: A. Paul  Berte'
layout: memory
schools:
  BUS: 1968
  LAW: 1968
primary_year: 1968
tags:
- Campus
- Spirituality
- Religion
---
# A  Peaceful Visit

I was a student in the Combined Degree Law School - Business School Program and went to Columbia Law and Graduate Business Schools year round  for three years--from when I was discharged from the U.S. Army in September 1965 until I graduated from the Business School in October 1968. I was married and lived on East 78th Street all three years. I used to walk to the Law and Business schools from the bus stop at 110th Street and often walked up along Morningside Park. There was, and hopefully still is, a Roman Catholic Church there with a chapel I would regularly visit. I vaguely recall becoming aware of that church through some University communication about religious facilities available to students.  I do not recall the name of the church but can still see the sanctuary in my mind's eye, and I have very fond and thankful memories of the peace and strength I received from my visits. Those visits on the way to school and other regular visits while on the campus became an important part of my prayer and overall religious life during my years at Columbia.  As the years have gone by I have become more appreciative of the resources that I had available as a Columbia student and also the primary emphasis I believe the University always had in considering the needs of its students--whether those needs be directly related to their academic program or their personal needs as students in an urban university campus environment. I believe my religious life and growth as a person while a Columbia graduate student living off campus was enriched because of the sincere care and consideration  Columbia has for its students' needs and   overall well being.
