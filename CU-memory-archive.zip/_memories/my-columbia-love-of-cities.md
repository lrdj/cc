---
title: 'My Columbia: Love of Cities'
author: Susan Ryan
layout: memory
schools:
  GSAPP: 1995
primary_year: 1995
tags:
- Campus
- Library
- Study spots
---
# Love of Cities

Attending Columbia ignited my love of cities.  I grew up and attended architecture school in suburbia, with only periodic ventures into any nearby city.  Moving to 113th Street  and immersing myself in the preservation program was a trial by fire, certainly.  I learned to read cities through a preservationist's eye, which has forever colored my perspective -- whether I am working in Manhattan, Cleveland, Philadelphia, or visiting a new city.  My favorite spot on campus remains Avery Library, whether I was toiling through readings near tall windows or digging through the archives with the help of patient librarians.  My favorite spot near campus was Cafe Pertutti.  Both offered welcome respites in their own way.
