---
title: 'My Columbia: Snooze'
author: Kok-Yong Tan
layout: memory
schools:
  GS: 1990
primary_year: 1990
tags:
- Campus
- Academics
- Library
- Study spots
- Food
- Dining
---
# Snooze

I used to love the Architecture library as it had particularly comfortable easy chairs to take a snooze in between classes, since I had an early class on Tuesdays and a huge chunk of downtime until the next one.  As I lived off-campus, it was too short a time to go home, catch a nap and return again.  It also had this temporary non-Columbia Food Services deli that only served great food at lunchtime. I became familiar enough with the building that I instantly recognized it when it was featured in one of the Ghostbusters movies as the office building Venkman gets evicted from. I don't know whether it's still there, but there was a piece of graffiti in the men's restroom which I found particularly amusing, written at the lowest point of the door to a stall:  "Beware of midget limbo dancers."
