---
title: 'My Columbia: Columbia Just Keeps Getting Better'
author: Anne Carlson
layout: memory
schools:
  GS: 1982
primary_year: 1982
tags:
- Campus
---
# Columbia Just Keeps Getting Better

My children and I live so much closer to NYC than we have in quite some time.  We visit the city often and always visit Morningside Campus, where I point out various spots and narrate the memories that go with them. I am so proud of Columbia; even though as a student it changed my life in profound ways, it seems even more robust and lively now than when I attended. I work in the field of independent school education, and many extremely smart, talented, fabulous young people I have known in my school career now attend Columbia. As it is often said, I could never get in now, but am so proud of my association with Columbia and am proud of Columbia's reach and influence as a global institution.
