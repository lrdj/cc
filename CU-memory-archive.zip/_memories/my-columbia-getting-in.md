---
title: 'My Columbia: Getting In'
author: Naeha Dixit
layout: memory
schools:
  CC: 2002
primary_year: 2002
tags: []
---
# Getting In

3 months before graduation, I was stressed out and worried.  The only college I wanted to attend still hadn't gotten back to me.  Then early one Saturday morning, my 13 year old brother threw a gigantic UPS envelope onto me while I slept.  He looked at me expectantly, and I tore open the envelope!  I got in!  I got in!  I got in!  We were so excited; we jumped up and down on the bed for about 15 minutes while screaming at the top of our lungs.  I will never forget that day!

Only one day tops it.

Fast-forward 5 years, fall of 2002.  I had just graduated and moved back to Detroit to spend 2 years teaching in the city.  My now 17 year old brother had applied to Columbia.  We were waiting to hear back.  Opening the envelope, he screamed "I got in!"  And thus began yet another 15 minute round of jumping up and down on the bed screaming our heads off!

I love that I have such a clear memory of opening my envelope, but what I value more is that I will always be able to share this experience with my brother!
