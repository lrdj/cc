---
title: 'My Columbia: Gospel!'
author: Wanda Holland Greene
tags:
- Barnard
- Winter
- Weather
- Relationships
layout: memory
schools:
  TC: 1990
  CC: 1989
primary_year: 1990
---
# Gospel!

During the winter and spring, numerous students and parents packed Altschul Auditorium in SIPA to hear the joyous and triumphant sounds of the Barnard-Columbia Gospel Choir.  Some of my fondest memories of Columbia are of directing the choir with my best friend Traci Turner Wilkerson (Barnard '90).
