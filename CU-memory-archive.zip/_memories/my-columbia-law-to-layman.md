---
title: 'My Columbia: Law to Layman'
author: Don Wilson
layout: memory
schools:
  LAW: 1948
primary_year: 1948
tags:
- Winter
- Weather
- Academics
- Lectures
---
# Law to Layman

Karl Llewelen, jurisprudence prof, left class after his point was made. 30 mins, 20 mins or whatever time it took.

"Law to layman is a person walking down the street who looks up to see marble steps leading up to doric columns, the coldest of all materials for architects. Between the columns is a statue. The statue holds scales. The statue is blindfolded."

End lecture.
