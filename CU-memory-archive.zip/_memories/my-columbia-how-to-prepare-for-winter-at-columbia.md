---
title: 'My Columbia: How to Prepare for Winter at Columbia'
author: ED  GINGRAS
layout: memory
schools:
  BUS: 1968
primary_year: 1968
tags:
- Winter
- Weather
---
# How to Prepare for Winter at Columbia

My answer is short but true: spend four undergraduate years at Dartmouth College in Hanover, New Hampshire -- winter at Columbia, in balmy New York, seems almost tropic in comparison.  Everything in life is relative, and my answer to many questions always starts with "compared to what?".
