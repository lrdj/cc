---
title: 'My Columbia: Coping with Winter at Columbia'
author: Geoff Pietsch
layout: memory
schools:
  GSAS: 1960
primary_year: 1960
tags:
- Winter
- Weather
- Academics
- Library
- Study spots
- Politics
- Activism
- Good trouble
---
# Coping with Winter at Columbia

No problemo.*   I commuted from home on Long Island while getting my masters at Columbia.  Never outside for more than a minute - from house to car, from car to LIRR station - from subway to class or library - then the same going home.

Was it a shock to my system? Nope. Besides growing up in the NYC area, I'd gone to Union in Schenectady for undergrad. THAT was cold.

*One exception.  Chipping the damned ice off the windshield on frosty mornings then waiting for the heater to finally warm up the car.  And driving up icy hills to the LIRR station and praying for a green light near the top since if I stopped I'd never get going up hill on the ice when the light changed.
