---
title: 'My Columbia: Bookish'
author: Kenneth Ehrenberg
layout: memory
schools:
  CC: 1993
  GSAS: 2005
primary_year: 2005
tags:
- Arts
- Culture
---
# Bookish

The book that meant the most to me would probably be Boccaccio's Decameron.  It was the only book that I actually read from cover to cover in Lit-Hum (which was also the only time I read more than what was assigned).  Years later, a girlfriend and I would read to each other from the same dog-eared copy on a deserted beach in Costa Rica.  I suppose we imagined ourselves wating out a plague as well.

Next in line would be Kant's Groundwork.  It was the first time I've ever had a philosopher actually read my mind hundreds of years before I was even born, and put my intuitions in a more detailed form than I ever could.
