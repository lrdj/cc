---
title: 'My Columbia: How I Kept Warm (or Not)'
author: Erik Bergman
layout: memory
schools:
  CC: 1973
primary_year: 1973
tags:
- Winter
- Weather
- Politics
- Activism
- Good trouble
---
# How I Kept Warm (or Not)

Coming from mild, wet Portland, Oregon to the College in 1969, I was totally unprepared for an East Coast winter. My typical clothing consisted of cotton socks, blue jeans, flannel shirt, an Army surplus field jacket and light boots -- suitable for fall in the Pacific Northwest at best. I recall walking west down 116th St. and being hit by a blast of Arctic air when I turned the corner on Broadway. It felt like I was being dipped in liquid hydrogen. Back then I was unaware of the principles of wearing multiple layers or wool for warmth. All my memories from November through February are frost-rimmed.
