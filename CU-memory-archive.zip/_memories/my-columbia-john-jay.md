---
title: 'My Columbia: John Jay'
author: Jeffrey  Becker
tags:
- John Jay
layout: memory
schools:
  CC: 1978
primary_year: 1978
---
# John Jay

More Rooms than the Tombs

Roaches the Size of Rats

(& Rats the Size of Dogs)

Common Crapper Bathrooms

With sirens blaring near St. Luke's

And the Everpresent Aroma of Mold.

The FIT girls

Still thought us Good Catches.

(Where the H did they come from?)
