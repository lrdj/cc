---
title: 'My Columbia: Clean & Sober Graduation'
author: Cathleen Quigley-Soderman
tags:
- Alma Mater
- Arts
- Culture
layout: memory
schools:
  SOA: 1990
primary_year: 1990
---
# Clean & Sober Graduation

My graduation was an unforgettable moment: I sat amongst the thousands in a sea of light blue cap and gowns. I had completed my three-year M.F.A. degree in Directing at Columbia's School of the Arts. 

The miracle was that--as my fellow students popped champagne corks beneath their honorable graduation gowns,  and as I looked up to see them flying into the crystal clear May 12th sky--I thought, "I am 90 days sober by the grace of God." 

Without my sobriety I would have never graduated. 

I had spent 2 1/2 years partying, drinking, and drugging my brains out before I finally reached my bottom. Even the chairman of my department, Howard Stein, asked me to take a sabbatical and see a doctor. Instead, I found the twelve steps, and because of my Higher Power I got to sit amongst the smartest and the greatest people in the world on those great stone step of my Alma Mater, Columbia University. 

Today I am 15 years clean and sober, and I can honestly say: it works, it really does.

Cathie Q.S.
