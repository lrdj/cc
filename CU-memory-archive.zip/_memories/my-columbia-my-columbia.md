---
title: 'My Columbia: My Columbia'
author: Franklin Baez
tags:
- McBain
layout: memory
schools:
  SEAS: 1992
primary_year: 1992
---
# My Columbia

This is a reply to the question of whether I still keep in touch with fellow Columbia alumni.  I mainly keep in touch with:

Daniel Snyder (ENG 92)

Mudit Tyagi (ENG 93)

Will Marrero (CC 92)

Sue Lato (CC 92)

Erik Hillsdale (CC 92)

Victor Wyckoff (CC 92)

I met them when we ALL lived as freshman in McBain on the eighth floor; we've been in touch for 19 years since! Needless to say, Columbia made a good impression on me! : )
