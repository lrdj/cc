---
title: 'My Columbia: So What'
author: Matthew Susman
tags:
- The West End
- Campus
- Music
- Arts
- Culture
layout: memory
schools:
  CC: 1979
primary_year: 1979
---
# So What

I remember in '78 and '79 going regularly to hear the Columbia group "So What" playing at Carman.  I thought they were the coolest guys on campus -- cooler than the Count Basie guys at the West End.  It was a great introduction to jazz.  Oddly enough, a couple of years ago I was watching a show at the Shubert Theater in New Haven about the blues guitarist Robert Johnson, and I recognized the one musician on stage: the guitar player from "So What."  I talked to him after the show; he's the only one from that group still playing, and he sounded better than ever.
