---
title: 'My Columbia: Sophomore Sweetheart Dance'
author: Ronald Sommer
layout: memory
schools:
  CC: 1959
primary_year: 1959
tags:
- Academics
- Arts
- Culture
---
# Sophomore Sweetheart Dance

One of the dippiest things and one of the funniest things I ever heard at Columbia did not take place in a classroom.  It took place at the Sophomore Sweetheart Dance.  Our class had not one, but two sweethearts: Cornelia Otis Skinner, a brilliant classical actress then appearing in a revival of Major Barbara, and Tina Louise, a really sexy bombshell than appearing in L'il Abner.  In accepting her honor, Ms. Skinner related that she had told her son Bob, who had just joined the Navy, that she had been selected as sweetheart, and he had responded that next year Yale would use Grandma Moses. That was the funny one.  In accepting her honor, Ms. Louise breathed deeply enough to almost lose a breast from her low-cut gown and said, in a deep and phony southern drawl, "I was a college girl once.  I went to the University of Miami for one semester and then decided to get a real education. So I went into the theater."
