---
title: 'My Columbia: Advice to My Columbia-Bound Self'
author: Katherine Howe
tags:
- WKCR
- Winter
- Weather
- Relationships
- Personal growth
- Reflection
layout: memory
schools:
  CC: 1999
primary_year: 1999
---
# Advice to My Columbia-Bound Self

1. Reconsider the nose ring. You'll like it for a few years, but in the end your mother will be proven right.

2. Break up with him. He's a nice boy, but you two have practically nothing in common. You'll both have more fun that way.

3. Be sure to take "Dada and Surrealism" with Sylvere Lotringer, because you will love it even though your French isn't quite good enough.

4. Do not, under any circumstances, take symbolic logic.

5. Take those WKCR board meetings a little less seriously.

6. The winter of 1995 won't be typical, but you should invest in some decent boots anyway.

7. There will be a Valentine's Day party in your senior year that you won't want to miss. Someone important will be there.
