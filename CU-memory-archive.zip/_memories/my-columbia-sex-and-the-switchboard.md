---
title: 'My Columbia: Sex and the Switchboard'
author: Jerome Breslow
tags:
- John Jay
- Hartley
- Dorm life
- Campus
layout: memory
schools:
  CC: 1956
primary_year: 1956
---
# Sex and the Switchboard

I lived in John Jay and Hartley when I was attending Columbia. 

In those days, there were telephones in the hall on each floor of the dorms, and they were connected to the outside world through a manual switchboard in the dormitory office. To help support myself, I got a job operating the switchboard. Due to the limited number of lines, it often occurred that all of them would be connected, and I had nothing to do except wait for someone to hang up so I could connect the next caller. 

While waiting  one evening, I discovered that by inserting the plug halfway into the board I could eavesdrop on the conversations without the parties being aware of it. That is when I learned how sexually aggressive college women could be when setting up a date.
