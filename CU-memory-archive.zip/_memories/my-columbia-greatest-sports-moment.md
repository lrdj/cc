---
title: 'My Columbia: Greatest Sports Moment'
author: James Dellocono
layout: memory
schools:
  CC: 1994
primary_year: 1994
tags:
- Dorm life
- Campus
- Sports
- Athletics
---
# Greatest Sports Moment

The greatest sports moment that I witnessed on campus was last seasons Men's Basketball victory over Princeton at the buzzer on 2/18/06.  This came after beating Penn the night before and on the induction night for the Columbia Athletics Hall of Fame.
