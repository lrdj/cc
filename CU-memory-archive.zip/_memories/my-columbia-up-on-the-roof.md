---
title: 'My Columbia: Up on the Roof'
author: Henry Rosenberg
tags:
- Carman Hall
- Dorm life
- Campus
layout: memory
schools:
  CC: 1973
primary_year: 1973
---
# Up on the Roof

Carman Hall was horrible: a cinderblock high-rise. But its roof was one of the finest spots in New York City, with views of the Hudson, the midtown skyline, and--on a clear day--the Statue of Liberty.
