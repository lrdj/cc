---
title: 'My Columbia: Meeting the President''s Wife'
author: Taylor Thompson
layout: memory
schools:
  SEAS: 1957
  BUS: 1970
  CC: 1956
primary_year: 1970
tags:
- Dorm life
- Campus
- Relationships
---
# Meeting the President's Wife

I arrived on campus in the fall of 1952 as a scholarship student.  I waited on tables at Johnson Hall for meals and took extra jobs for income.  One of my first jobs was to wait on tables at Baker field on alumni weekend.

I was assigned to wait on the head table, which included General and Mrs. Eisenhower. After serving lunch Mrs. Mamie Eisenhower turned to me and said, "Get a program."  When I did, she turned to General Eisenhower and interrupted his conversation and "ordered" him to "sign the program for this young man."  He obeyed, and I got a signed program from the University President and the future President of the United States.  He also had something to do with WWII.

I thought at the time: "Wow!  If this can happen the first semester, what will happen the next four years?"  I went on to get a BA, BSEE, and an MBA.
