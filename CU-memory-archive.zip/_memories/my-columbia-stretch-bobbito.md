---
title: 'My Columbia: Stretch & Bobbito'
author: Kevin Glenz
tags:
- WKCR
- Low Library
- Butler Library
- Campus
- Library
- Study spots
- Arts
- Culture
- Music
layout: memory
schools:
  CC: 1998
primary_year: 1998
---
# Stretch & Bobbito

Moving from my hometown, Wheeling, West Virginia, to Manhattan to attend Columbia was an eye-opener in innumerable ways. But more than anything, it was the music that made me glad I had made the journey. During my four years at Columbia, I was fortunate enough to see Brooklyn MCs the Boot Camp Clik, hip hop legends Run-DMC, and Busta Rhymes without leaving campus. And among my many highlights as a campus DJ, I opened up for A Tribe Called Quest when they performed in front of Low Library. I also trekked downtown to see Common, the Beatnuts, and other seminal hip hop artists. And I took a train out to New Jersey to catch Prince's Jam of the Year tour. But one of my most treasured music-related memories is staying up every Thursday night with blank cassette tapes ready to record the DJ Stretch Armstrong and Bobbito show on WKCR. I would spend the following Friday stacking the shelves at Butler Library, feeling lucky that my job was so menial that I could concentrate on the absolute newest records I was hearing before anyone else in the world, and the exclusive live freestyles by Nas, Big L, Kool G Rap, and other rhyme slayers. Respect forever to Stretch & Bobbito.
