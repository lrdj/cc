---
title: 'My Columbia: Diamond''s E& M Class'
author: Shre Roy
layout: memory
schools:
  SEAS: 1989
primary_year: 1989
tags:
- Academics
---
# Diamond's E& M Class

It was 1987-1988 when Electrical Engineering was a still a popular major to pursue.

I still get shivers when I think of my E&M class with Professor Diamond.  That was the mother of all weeding out classes. If Circuits level 1 didn't do it then this one really sent all aspiring Electrical Engineers to reexamine their futures: "perhaps IE was not so bad after all."

Diamond passed out the midterm exam with a cocky grin and then I found out why. It was the most difficult exam I had ever seen, hands down. I flipped through the whole test to find something I could comprehend so I could use the set of equations I had in my brain.  I had done what Columbia Engineering students have done through the ages, I pulled an all nighter and crammed for this test.  Greens theorem, H transforms I was ready. (how bad could it get?) I would soon find out.

That nightmare that I used to get where I couldn't solve the questions on the exam was happening to me in real life.

After the first midterm exam was graded, Professor Diamond passed out the marked tests. A girl upon receiving her paper broke down, most people including myself had that deer in headlights look on their faces.

I fared badly and didn't think I could survive the finals. He had to move the grading curve to a new low just to be able to grade people. I decided not to give up and leave the class since I still did better then half the class.

I persevered and stuck it and passed the course.

The saying "what doesn't kill us makes us stronger" really applied to Professor Diamond's class that year.
