---
title: 'My Columbia: Watching X-Files With No Lights On'
author: Tera Childs
layout: memory
schools:
  GSAPP: 2001
  CC: 1998
primary_year: 2001
tags:
- Religion
- Spirituality
- Academics
---
# Watching X-Files With No Lights On

Ah, the memories of freshman year on Carman 10. We were an eclectic group of athletes and computer geeks. East coast sophisticates and west coast bunnies. There were econ majors and philosophy minors. Future lawyers and future scientists. Diverse students with one thing in common: The X-Files.

Every Friday night--because it WAS still on Friday nights back then--we would gather in the lounge for a TV fest. If you wanted to be guaranteed a seat you came down before The Simpsons to snag a chair. Next we had to watch Sliders--that horrific show about parallel universes--because one of our floormates knew the star. Then, long after the sun had set and at least half the floor had crowded into the tiny lounge, we watched X-Files.

It was like a religion. We might not have gone to every class. We might not have gone to services regularly. Some of us--and I'm not pointing any fingers, but I will say swimmers were the worst--didn't even bathe regularly. But we watched X-Files on Friday nights without fail. Even social plans had to wait until the credits rolled. And I think we were all a little heartbroken when Fox moved the show to Sundays--where's the sacrifice in that?
