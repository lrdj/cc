---
title: 'My Columbia: Oxford Days'
author: Antonio Vinals
layout: memory
schools:
  CC: 1989
primary_year: 1989
tags:
- Academics
- Library
- Study spots
---
# Oxford Days

I had a wonderful oportunity to take part in an Oxford summer study program while a junior at Columbia. Studying along with British and other American students in such a classic setting was memorable.  I rememebr with great fondness the impromtu barbecue and Independence Day party that a few of us had there, to the dismay of some of the more traditional Brits!
