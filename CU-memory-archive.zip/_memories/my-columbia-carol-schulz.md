---
title: 'My Columbia: Carol Schulz'
author: Douglas Lee
tags:
- Columbia College
- Campus
layout: memory
schools:
  LAW: 1992
  SIPA: 1992
  CC: 1987
primary_year: 1992
---
# Carol Schulz

Carol Schulz was my Korean language instructor for just two and a half years during my Columbia College days, but was my "mother away from home" for nine of the 10 years that I was on the Columbia campus. She taught me so much more than the Korean language (which I have used everyday for the past 11 years that I have been living in Korea), and my experience at Columbia would have been much less rewarding if she had not been there for me. I think one's experience and memories of Columbia can vary significantly depending upon just one faculty member and in my case, the difference was Carol Schulz. I wanted to use this opportunity to thank her for having been such an important person in my life.
