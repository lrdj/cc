---
title: 'My Columbia: "He Had a Moustache"'
author: Dorie Bulloff
tags:
- Alma Mater
- Academics
- Library
- Study spots
- Relationships
layout: memory
schools:
  SW: 1975
primary_year: 1975
---
# "He Had a Moustache"

The year before I saw him again--in the Columbia library--we had been students together in Dr. Schwartz's Social Work "Group" class. He sat next to me, told me jokes and helped me get through the class with Dr. Schwartz and the professor's ascerbic wit.  

He'd also told the class he was a child of Holocaust Survivors and very open about his traumatic life experiences.  I liked him...very much. A year later I saw him again, standing under the picture of President Dwight  Eisenhower in the library.  This time he had a moustache and  was so cute and alluring!  I went up to him and we started talking...and talking...and talking.  Time went by and as things happen, we were married in  August 1978.  Those were some of the funniest and most delightful years of my life!  But the marriage didn't work out, and we parted after being together for eight years.  However, he remarried, and I've just remarried--and the wonderful thing is that we have remained good friends to this day and talk and talk and talk.  Thanks to Ike and the library at my Columbia Alma Mater!
