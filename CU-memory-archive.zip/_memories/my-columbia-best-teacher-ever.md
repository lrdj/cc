---
title: 'My Columbia: Best Teacher Ever'
author: Jonathan Goldman
layout: memory
schools:
  CC: 1983
  GSAS: 1986
primary_year: 1986
tags:
- Academics
- Arts
- Culture
---
# Best Teacher Ever

As an impressionable young freshman in 1979, I had the distinct pleasure of attending Joseph Bauke's CC class.  It was more than a class.  It was a wake-up call to what higher thinking was all about.  We would discuss the texts in a way that was new and exciting.  People weren't "wrong," just unable to support their point.

Anyway, Bauke would invite all of us to his apt. for Fri. evening wine and cheese, where we were introduced to his extensive collection of "Sams."  Sam was an old man who sold candy bars and painting/bookmarks on the steps.  Prof. Bauke had an incredible collection.

This was the best of Columbia.  7 years in attendance in 2 divisions, but nothing hammered home the concept of university community like wine and cheese with Prof. Bauke and his Sams.
