---
title: 'My Columbia: Elevator Games'
author: John Gaguine
layout: memory
schools:
  CC: 1969
primary_year: 1969
tags: []
---
# Elevator Games

I lived in Carman for three years, from 1965-68.  I remember a favorite game was to tie a thread to the elevator stop switch, anchor the thread to something outside of the elevator, and then send the elevator up.  This resulted in the stop switch being triggered and the elevator getting stuck between floors, to the great inconvenience of all.
