---
title: 'My Columbia: John Jay Allegiance'
author: Christina Wright
tags:
- John Jay
- The West End
- Dorm life
- Campus
- Winter
- Weather
- Academics
- Music
- Food
- Dining
- Relationships
layout: memory
schools:
  CC: 2003
primary_year: 2003
---
# John Jay Allegiance

I began my Columbia tutelage on John Jay 11, room 1127, to be exact. I will always remember move-in day - maneuvering those bulky, orange moving bins from the elevator to my little slice of Columbia. My mother quickly got over the shock of my impending co-ed living quarters and helped me make the best of what some might consider a walk-in closet. But I loved my John Jay room. I quickly made a best friend out of my next door neighbor, Robert Rosen, CC '03. We remain very close friends today. I suppose there was something about those tight living quarters that created an indestructible bond. Whether we were reading Cervantes or watching Dawson's Creek; memorizing Mozart for Music Hum or preparing for a night at the West End; cramming 15 people into one John Jay elevator or spending hours in the dining hall - lasting friendships were made within those John Jay walls. And we had a solid allegiance to our dorm. Carmen was inferior - I mean, they had to trek through the snow to eat dinner while we could merely amble downstairs in our flip flops and sweat pants. Even now, two years post-graduation, I associate classmates with which John Jay floor they resided on, their Columbia origins. My closest friends were made in John Jay and I will always look back on those days with fondness.
