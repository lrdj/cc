---
title: 'My Columbia: Music I Listened To'
author: John  Gaguine
layout: memory
schools:
  CC: 1969
primary_year: 1969
tags:
- Music
---
# Music I Listened To

At first, being a young 17-year-old, I listened to WABC, Cousin Brucie and Dan Ingram.  Then, as I developed some taste, I went to WNEW-FM, the legendary station with Murray the K (most famous, not the best), Roscoe, and Alison Steele, the night bird.  When I got a record player, it was the greats of the late 60s - the Mamas and Papas, the Jefferson Airplane, the Doors, the Stones, Dylan, Joni Mitchell, etc.  And of course, like everyone back then, I had my copy of Judy Collins's Wildflowers.
