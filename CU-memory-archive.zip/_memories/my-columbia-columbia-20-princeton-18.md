---
title: 'My Columbia: Columbia 20, Princeton 18'
author: Bob Levine
tags:
- Homecoming
- Campus
- Sports
- Athletics
layout: memory
schools:
  CC: 1968
primary_year: 1968
---
# Columbia 20, Princeton 18

It is Homecoming Day, 1988.  Columbia's valiant eleven haven't been victorious over Princeton in years... twenty-five since I was a freshman.  Somehow, the year 1945 rings a bell. The Lions have tried all afternoon on a sloppy, muddy, rainy field to lose the game, so typical of Columbia's "snatch defeat from the jaws of victory" futility in years when we were actually competitive.  Somehow, Princeton also refused to win.  It is now the final play of the game.  A Princeton kicker has the opportunity to kick a field goal from approximately 20-25 yards to win the game.  It is an almost certainty that the kick will be true.  Yet, while straight and high, it falls short, by a foot.   The Lions triumph.  Pandemonium ensues.  Goalposts are torn down.  It is as if we had won the national championship.  A while later, back on campus, Broadway is filled with the continuing euphoria of thousands of cheering fans.   It is my most enduring Columbia sports moment, and I still have the t-shirt from that Homecoming Day.
