---
title: 'My Columbia: The DJ Stretch Armstrong Show Featuring Bobbito the Barber'
author: Marcel Agueros
layout: memory
schools:
  CC: 1996
primary_year: 1996
tags: []
---
# The DJ Stretch Armstrong Show Featuring Bobbito the Barber

Stretch was the DJ, Bob the hype-man/host--together they did the Stretch Armstrong Show on KCR from 1 to 5 AM Fridays. Starting in '92, I taped their show religiously. They played all the underground hiphop before it got big--and featured unknown guests who would soon be household names.

In the early days I would edit out the banter between the two of them--but today the tapes I have where sleep prevailed before I could "clean" the tapes are the ones I love most. Stretch and Bob didn't take themselves seriously, they didn't take their guests seriously, and they didn't take hiphop seriously--they just loved it.

Stretch eventually left the show, but Bob kept it going, and one of the highlights of my professional career has to be the day a few years ago when, at around 4 AM, Bob asked me--an accidental guest--to talk about the most exciting recent discoveries in astronomy. Needless to say, I have the tape.
