---
title: 'My Columbia: Openness'
author: Jody Rowell
layout: memory
schools:
  SW: 1999
primary_year: 1999
tags:
- Spirituality
- Religion
- Academics
---
# Openness

My spiritual experience at Columbia was exceptional.  I was born and raised Catholic and as an adult struggled to combine my personal values with the dogma of the church. During my final year at the School of Social Work, they created a class called "Spirituality in Social Work," the first social work school to deal with spirituality and the practice of social work.  It was there that our teachers allowed us to explore our own beliefs, those of my colleagues and the affect the same might have in the practice of social work.  It was sometimes hard for us to come together as a group and discuss some very different beliefs, but the work was powerful and I learned an incredible amount about myself, my fellow spiritualists and how my ability to be open to other's thoughts and spiritual beliefs could be a powerful part of my work with my clients.  It was incredible.
