---
title: 'My Columbia: History 10'
author: Neil  Cowan
layout: memory
schools:
  GS: 1960
primary_year: 1960
tags:
- Arts
- Culture
---
# History 10

Professor Bernhardt was teaching the second course in the basic American history course, which I loved with a passion.  He assigned the students to write book reviews, and mine was James McGregor Burns's (I hope I have this right?) Roosevelt: The Lion and the Fox.

It was a wonderful book to read and an even better experience to disucss with my teacher, who had an excellent feel for making wonderful suggestions that were critical and to the point. To this day I thank him for his insights. Neil M. Cowan
