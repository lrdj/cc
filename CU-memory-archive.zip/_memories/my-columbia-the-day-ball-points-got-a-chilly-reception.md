---
title: 'My Columbia: The Day Ball Points Got a Chilly Reception'
author: Nicole Campbell
layout: memory
schools:
  JRN: 1996
primary_year: 1996
tags:
- Winter
- Weather
- Politics
- Activism
- Good trouble
---
# The Day Ball Points Got a Chilly Reception

No, not now. Not here. Not in the middle of the street in the middle of the winter that had set a then-record in New York City for most snowfall.

As a journalism student at Columbia, I was given an MOS - man on the street  - piece. On what I can't now remember. But I won't ever forget the bone-chilling cold I had to endure as I ambushed pedestrians on Amsterdam Avenue in January.

It was 2:00 p.m. on a Sunday and "sunny" (us native Californians have a different take on the word, thank you very much) but getting anyone to stop for me proved nearly impossible. And I didn't blame them.

Finally, one woman took pity on me. I asked my question and started to write down her response. That's when it happened. My pen started running out. I couldn't believe it. It was fairly new so I was rather sure the ink wasn't low. I didn't know what was up but a mild panic took over. I really did wonders for the Columbia name as I spurted out apology after apology for making her stand out there even longer and, uh, having to ask if she had a pen that worked. She handed me one. The ink, more marker-like, flowed freely. Confusion eclipsed panic.

"Yeah, you have a ball point pen? Yeah, those don't work in cold weather. They freeze up," she told me.

It was like being told the miracle of birth. It all became clear. Working in Southern California, as I have my entire journalism career, one may have to deal with earthquakes, fires, floods, riots, Lindsay Lohan. Never equipment failure due to severe cold.

I kept warm at Columbia by investing in some non-ballpoint ink pens.
