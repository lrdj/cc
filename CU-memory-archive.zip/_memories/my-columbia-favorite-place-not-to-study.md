---
title: 'My Columbia: Favorite Place (Not) to Study'
author: Jefferson Svengsouk
layout: memory
schools:
  CC: 1990
primary_year: 1990
tags:
- Dorm life
- Campus
- Library
- Study spots
- Arts
- Culture
---
# Favorite Place (Not) to Study

My favorite place to relax was the gardens at the Cathedral of Saint John the Divine. I would bring my books along to seek some solace in the serene greenery of the gardens, the occasional peacock strolling around. While it was one of my favorite places to be, I also ended up not getting very much studying done there. The inner calm and contentment inspired by the peacefulness of the gardens and the proximity of the sacred would spill over to my more typical study environment, the dorm room.
