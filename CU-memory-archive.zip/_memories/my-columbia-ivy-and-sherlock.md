---
title: 'My Columbia: Ivy and Sherlock'
author: james quattlebaum
layout: memory
schools:
  GSAS: 1961
primary_year: 1961
tags:
- Arts
- Culture
---
# Ivy and Sherlock

Arriving at Columbia from the south, I was curious about what "Ivy" might mean to me day-to-day. One thing I noticed quickly was that searches for referenced papers and books were essentially always successful.

I considered it, among other things, in bad taste for a snooty institution to flaunt its power in a southern boy's face, so I took to requesting obscure and far-fetched articles to "defeat" the Columbia libraries.

Humiliated in my quest for an erudite "victory," I then tried a more frivolous challenge:  I asked for the Sherlock Holmes Society's "Baker Street Journal."

"V.1 to current" was the response.

I surrendered.
