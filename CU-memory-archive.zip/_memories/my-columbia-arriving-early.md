---
title: 'My Columbia: Arriving Early'
author: Harold G.  Sullivan
tags:
- Furnald Hall
- John Jay
- Dorm life
- Campus
- Abroad
- Travel
layout: memory
schools:
  SEAS: 1958
primary_year: 1958
---
# Arriving Early

In the fall of 1956, a fellow student and I arrived at Colubmai as the first two students to attend engineering school on the Combined Plan from Hendrix College in Conway, Arkansas.  Neither of us had been out of Arkansas for any extensive travel.  We arrived at columbia with an idea of what an Ivy League university should look, so we were totally confused when we got out of the subway at 116th and Broaway.  By chance, we exited the mid-block exit downtown from 116th.  We really must have looked lost, because someone stopped and asked if they could help us find something.  We said we were looking for Columbia University, and all we saw were tall buildings.  They pointed us to the 116th Street entrance.

We were assigned to 519 Furnald Hall.  When we found the dorm, there was a note on the door that said it would not be open until Monday--and this was Friday.  We finally found the student housing office in John Jay.  We talked to several people there and explained our plight.  We needed someplace to stay as we didn't have much money between us.  After much consternation, they gave us a key to the dorm door and let us stay there for the weekend.
