---
title: 'My Columbia: Encountering Lionel Trilling'
author: Ben Lipson
layout: memory
schools:
  GSAS: 1951
primary_year: 1951
tags:
- Arts
- Culture
- Politics
- Activism
- Good trouble
---
# Encountering Lionel Trilling

When I entered the Graduate School of Arts and Sciences, then known as the Faculty of Philosophy, I registered in Lionel Trilling's course in American Literature.  And I came to read The Liberal Imagination, which was published in 1950. The  possibilities for the life of the mind opened up to me in a way I could not have anticipated. Reading it and everything else of Professor Trilling's work changed not merely the way I approached literature but the connections between literature and politics, as he defined it. That influence is firmly fixed in me to this day.
