---
title: 'My Columbia: The Phone Call from Yogi'
author: William Bracciodieta MD
layout: memory
schools:
  CC: 1967
primary_year: 1967
tags:
- Arts
- Culture
---
# The Phone Call from Yogi

In April of 1964, I was a freshman baseball player at Columbia who, in February, had been named the receipient of the Yogi Berra scholarship. However, it took several phone calls from the New York Yankees front office and a call from Yogi Berra himself to convince me that these phone calls were legitimate and not a hoax perpetrated by my freshman baseball teammates.

As it turns out, the Yankees and Yogi Berra actually were asking if I would be willing to throw out the first ball on opening day of the Yankees 1964 season, which was Yogi's first season as a major league manager (see attached article from the New York Times, April 17, 1964). The Yankees lost to the Boston Red Sox. Another 19-year-old named Tony Conigliaro played the outfield for the Red Sox that day. The rest is history.
