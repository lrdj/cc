---
title: 'My Columbia: A Texan''s First Winter at Columbia'
author: Mayokia Walker
tags:
- Riverside Park
- Winter
- Weather
- Politics
- Activism
- Good trouble
- Relationships
layout: memory
schools:
  CC: 2004
primary_year: 2004
---
# A Texan's First Winter at Columbia

My first winter at Columbia was a big shock to my system.  I was a Freshman all the way from Texas, and had absolutely no idea what I was in for.  I was a member of the track & field team and remember thinking my coaches were crazy the first day the temperature dropped below 60 degrees and we were still expected to run outside in Riverside Park!  I wore thick running tights and a ski mask (yes, a ski mask!) on those runs and long underwear under my clothing throughout the day (top AND bottom!).  I will never forget how much my friends thought I was a dork and told me that NO ONE wears long underwear under their clothes.  I had no idea, but they sure kept me warm!  After the first winter, my body built up a tolerance for the winters to come, and I haven't moved back to Texas yet!
