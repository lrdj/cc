---
title: 'My Columbia: Opera in Hartley Hall'
author: Rod Parke
tags:
- Hartley
- Dorm life
- Campus
- Arts
- Culture
layout: memory
schools:
  CC: 1961
primary_year: 1961
---
# Opera in Hartley Hall

My sophomore Arts Humanities professor described van Gogh as "passion nearly out of control."  I took that line to bed with me in my Hartley dorm and had the following dream:

I'm on the stage of the Metropolitan Opera.  I'm hiding under the sheets of Desdemona's (Leonie Rysanek's) bed just as she is about to sing her 'Ave Maria' and 'Willow Song.'  I have large original paintings by van Gogh in bed with me!  Rudolph Bing (Gen. Dir. of the Met) is just off stage, motioning to me and whispering, "Psst, psst...GET OUT OF THERE!"  I answer back in my best stage whisper, "I WILL, just as soon as Leonie sings her aria!"

I had a chance many years later to tell Leonie this story when she came to Seattle to sing Sieglinde at Seattle Opera.  As I finished, I said, "See, even gay men can have crushes on sopranos!"  She seemed unimpressed.  Little did I know that she had already been diagnosed with her terminal cancer.  You'd never have known it from the red-hot performance she gave.
