---
title: 'My Columbia: Krum Elbow'
author: Arthur L. Thomas
layout: memory
schools:
  CC: 1950
primary_year: 1950
tags:
- Campus
- Arts
- Culture
- Politics
- Activism
- Good trouble
---
# Krum Elbow

The part of the Columbia campus that I most enjoy remembering was the Columbia boathouse at Krum Elbow. It was, it seems, inaccessible by land, sited in an isolated rural area across the Hudson river from Poughkeepsie. The boathouse was a grand structure that dominated the shoreline. Open only in June to the Columbia crew when the crew practiced for the Poughkeepsie regatta, it was a special place that looked out on nature (the river) and that was backed up by nature (the surrounding flora and fauna). After World War II the Poughkeepsie regatta was held only in 1947, 1948, and 1949 and was then discontinued. In 1947 Columbia hosted the University of California crew at the boathouse. I rowed in the Poughkeepsie regatta in 1947. In 1948 I went to the boathouse as a launch driver and general hand.  Arthur L. Thomas CC50
