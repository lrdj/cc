---
title: 'My Columbia: A Spiritual Tale from the Mansion'
author: Sara  Nordholm Brown
layout: memory
schools:
  SW: 1963
primary_year: 1963
tags:
- Spirituality
- Religion
- Academics
---
# A Spiritual Tale from the Mansion

I started Columbia School of Social Work as a newly married, college graduate from Minnesota.  The challenges of living in the city, starting graduate school, and married life were exciting and amazing.  Learning to work with the poor and hurting populatons in the Richmans House two days a week, and then going to State Island Department of Human Services three days a week for my practicum  was a spiritual experience for me.  The day that President Kennedy was killed our class was in shock.  My teacher wept with us, and when I saw him again 25 years later at a conference we remembered this experience together and wept again.

I met fellow students and teachers from all nationalities, age groups and experiences at Columbia. The clients I met at my practicum sites faced unbelievable challenges with dignity and resourcefulness. I grew to appreciate a very diverse group of people, knowledge and experiences that have served me well in my career in NYC, Zambia, Libya and Oklahoma.  Thank you.
