---
title: 'My Columbia: Hungarian Pastry Shop'
author: Bruce  Kurzius
tags:
- Hungarian Pastry Shop
- Library
- Study spots
- Food
- Dining
layout: memory
schools:
  TC: 1981
  CC: 1973
primary_year: 1981
---
# Hungarian Pastry Shop

The Hungarian Pastry Shop was my place to study and relax.  The comfort of exquisite pastries and refillable coffee mugs with a quality of coffee ahead of its time took you from ecstasy to a riveted concentration on the tasks at hand.
