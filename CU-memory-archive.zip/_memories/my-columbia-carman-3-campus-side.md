---
title: 'My Columbia: Carman 3 "Campus Side"'
author: Steven Stastny
tags:
- Ferris Booth
- Carman
- Dorm life
- Campus
layout: memory
schools:
  CC: 1988
primary_year: 1988
---
# Carman 3 "Campus Side"

Having visited campus twice before entering the College, I was quite ready to move into Carman for the complete co-ed experience.  When I got my room assignment for 304B Carman, I was disappointed with the low floor but was pleased that at least I would have the nice campus view. Upon arrival, I quickly realized that Ferris Booth Hall was five stories and I was greeted with a view of a brick wall and a rather attractive sliding burglar gate. My roomie, John Collins (we called him Jay then, and I still do because I'm much too big for him to effectively object), in his usual expressive manner, said "This really sucks!" We agreed that it was nice to meet each other as we had exchanged the obligatory letter. Jay and our Suite 306 neighbor Steve Yung E'87 have kept in touch and both of them were in my wedding party. Suitemates John Stamais and Oscar Olmedo provided constant comic relief and a steady stream of visitors (mostly female). This was important, because Carman 3, much to my dismay, was also all male.  Five of us pledged KDR, myself, Collins, Yung, Michael Fearm, and Andy Cowder, and we generally had a good time. When together, we always remember out time in Carman fondly and never fail to mention the wall and the burglar gate. Steven M. Stastny CC '88
