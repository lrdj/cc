---
title: 'My Columbia: The Pub'
author: Kevin Donnelly
tags:
- John Jay
- Campus
- Spirituality
- Religion
- Relationships
layout: memory
schools:
  BUS: 1978
primary_year: 1978
---
# The Pub

Relaxing in the basement of John Jay in the Pub was a frequent activity.  Of course, back then, the Pub was a real pub.  When another graduate and I recently visited campus, how things have evolved -- having to go off campus for a beer.

But, most significantly, the Pub is where I met my wife, and we were married in the Columbia Chapel over 26 years ago.
