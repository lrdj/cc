---
title: 'My Columbia: Wein Hall'
author: Kendra Crook
layout: memory
schools:
  CC: 1995
primary_year: 1995
tags:
- Dorm life
- Campus
- Relationships
---
# Wein Hall

As a member of the women's basketball team, I was required to stay on campus during Christmas Break.  During my sophomore year, I lived in Wein in a single with my best friend across the hall.  Campus was so empty during the holidays that I was lonely and complaining to my best friend, who was home with her family in Massachusetts.  One night on my way back from practice, as I approached Wein, I looked up to her window as I always did.  I was shocked to see for the first time in two weeks that her light was on! I ran the rest of the way to Wein, past security, up five flights of stairs and threw open her door to find her laying on her bed reading.  I have never been so happy to see a light on!  And to this day, whenever I approach the east side of campus, I look to see if Sarah is home.
