---
title: 'My Columbia: Club Law at Our Apartment'
author: Jay Ross
layout: memory
schools:
  JRN: 1994
primary_year: 1994
tags:
- Academics
- Library
- Study spots
---
# Club Law at Our Apartment

Lee Feldshon, my roomie in 1993-94, was in the Law School.  He had it all--smart, dashing, etc.

He had a great Law School party for the whole class, it seemed like, near the end of the year in our University apartment. He turned his bedroom into a clubby lounge that featured 10 hours of recorded tape from the "Beavis and Butthead" Moron-a-thon from MTV--a big hit!

In later years, I Googled Lee and saw that he worked at Madison Square Garden as counsel for a while.

Who said that all lawyers do is study!
