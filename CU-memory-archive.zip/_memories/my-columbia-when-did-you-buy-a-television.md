---
title: 'My Columbia: When Did You Buy a Television?'
author: Topher McGibbon
tags:
- McBain
layout: memory
schools:
  CC: 1996
primary_year: 1996
---
# When Did You Buy a Television?

The first night of freshman year (McBain on B'way and 113th St.), my mom called just as fire trucks were responding to an alarm.

Mom: (with a note of exasperation) Your roommate brought a television?

Me: No

Mom: Oh...
