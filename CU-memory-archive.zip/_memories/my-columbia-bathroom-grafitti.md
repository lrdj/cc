---
title: 'My Columbia: Bathroom Grafitti'
author: Walter Schmidt
layout: memory
schools:
  LAW: 1982
primary_year: 1982
tags: []
---
# Bathroom Grafitti

This in response to your solicitation: "What's the bestÃ¢â¬âdippiest, funniest, most brilliantÃ¢â¬âstudent comment you heard at Columbia?"

"More people died at Chapaquiddick than at Three Mile Island."  -Anonymous
