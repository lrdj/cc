---
title: 'My Columbia: Summers spent ... wisely?'
author: Lori Alvino
layout: memory
schools:
  CC: 1999
  LAW: 2003
primary_year: 2003
tags:
- Campus
- Academics
---
# Summers spent ... wisely?

I spent two summers taking classes on campus: the first time, between my 2nd and 3rd years, so that I could spend the following fall in Paris and still complete my two majors; the second time, between my 3rd and final years, so that I could lighten my load senior year.  That is not to say that I didn't catch up on other important things.  My fondest memories of summer at Columbia involve sunning myself on the Steps and taking long walks from Morningside Heights to elsewhere in the city, stopping for brunch, shopping, or just to sit for a moment and take in the city along the way.  In retrospect, I wouldn't have wanted to spend my summers any other way.
