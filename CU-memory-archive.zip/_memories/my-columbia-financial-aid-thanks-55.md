---
title: 'My Columbia: Financial Aid:  Thanks, `55'
author: Andrew Fisher
tags:
- Reunion
- Dorm life
- Campus
- Academics
- Sports
- Athletics
layout: memory
schools:
  CC: 1965
primary_year: 1965
---
# Financial Aid:  Thanks, `55

Without substantial financial aid, I would not have been able to attend college.  About a third of my education was underwritten by a most generous scholarship sponsored by the Class of 1955.  Whenever I meet a member of that class, I offer my thanks, because they made the difference.  Fortunately, it's not too hard to find members of the Class of 1955, because so many have gone on to illustrious, high-profile careers.    I remember running into (former Columbia freshman football coach) Jack Armstrong '55 on a commuter train in New Jersey.  I introduced myself to Tom Chrystie `55 at the opening of East Hall.   At the Class of 1955's 50th reunion two years ago, Gerry Sherwin '55 helped me thank a number of my benefactors.  My favorite encounter may have been with Rabbi Harold Kushner '55 in the green room at the Today Show, where I worked for many years.  I identified myself as the former Class of 1955 Alumni Scholar.  "Best decision we ever made!" he replied.  I know it wasn't true, but it was awfully nice to hear.
