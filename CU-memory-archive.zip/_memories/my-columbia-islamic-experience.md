---
title: 'My Columbia: ISLAMIC EXPERIENCE'
author: MUHAMMAD ISLAM
layout: memory
schools:
  GSAS: 1981
primary_year: 1981
tags:
- Dorm life
- Campus
---
# ISLAMIC EXPERIENCE

Earl Hall was the hub of Friday noon congregation (JUMMAH) for the small group of Muslim students, Faculty and staff. Muslim worship requires ablution (WUDU cleaning of body parts with water) before attendance. The small crimpy restroom was not adequate for the worshippers attending the weekly ritual (salat) and many of us would wait in line. It was also difficult to wash the feet in a regular restroom. We did our best under the circumstances. On the first day of my attendance, to my amazement, a fellow student rolled up a huge large carpet hiding inside a wooden box near a wall. This was the prayer rug for all of us. The carpet rolled back again in the box after we got done. We did have some attendance from surrounding businesses. The sermon was short by a humble Iranian Professor (it seemed) but was very direct, appealing and learning experience. This gathering and the opportunity to meet a host of fellow Muslims every Friday from other countries was interesting and relaxing. At times, I would come early and wait in the Lobby to read magazines and pamphlets. I wonder what has become of it now!
