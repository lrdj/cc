---
title: 'My Columbia: Sports Glory'
author: Mike Zegers
layout: memory
schools:
  SEAS: 1988
primary_year: 1988
tags:
- Sports
- Athletics
---
# Sports Glory

It had to be a tie: first, watching Frustration's End win the 1988 Intramural B-Ball championship, only because it made Brendan Murnan cry for joy and Rob Daniel (the fearless coach who put our rag-tag team together) the happiest guy on earth.  It tied, of course, with watching us beat Princeton and end the losing streak in football.
