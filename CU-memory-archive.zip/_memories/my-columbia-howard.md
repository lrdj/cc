---
title: 'My Columbia: Howard'
author: Jeff Fligelman
layout: memory
schools:
  SOA: 1990
primary_year: 1990
tags:
- Dorm life
- Campus
---
# Howard

I spent thirty minutes a week with Professor Howard Stein in his Dodge Hall office, where he taught me as much about life as about playwriting.

Thank you, Howard.
