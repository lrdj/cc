---
title: 'My Columbia: A New Life'
author: Leslie Kruegel
tags:
- Low Library
- Academics
- Library
- Study spots
- Relationships
layout: memory
schools:
  LS: 1978
primary_year: 1978
---
# A New Life

I was newly married and starting my studies at the graduate school of library service.  Every day I took the bus and the subway from NJ, and stopped at the old Chock Full o' Nuts coffee shop for juice or coffee.  Between classes, in good weather, I loved to sit on the steps of Low Library and read (not usually school work).  I made one really good friend at the school, and we spent hours wandering the neighborhood around Columbia and laughing about everything.  Going home to my husband in the late afternoon, life seemed so full of promise and new experiences.  I really treasure that year, although it went by so quickly.  Being a librarian is certainly not a lucrative career, but I've never been disappointed with my choice, even after almost 30 years.
