---
title: 'My Columbia: Playing Hooky Led to My Most Artsy Experience!'
author: Charles H Nadler
layout: memory
schools:
  CC: 1962
primary_year: 1962
tags:
- Academics
- Arts
- Culture
---
# Playing Hooky Led to My Most Artsy Experience!

During my graduate student days in philosphy, I took a course taught by Professors Ernest Nagel and Thomas Merton on the Sociology of Science. There I met someone who was older and took the occasional course. He urged one day that we skip class and go to this great gallery downtown to look at Indian Art. I decided to go.  When we got there I said that the art wasn't very interesting, whereupon he said that it was no wonder, given the way I was looking--or not looking, as the case may be.  He showed me a way of active looking, which I use to this day.

It is the viewing analogue of critical thinking!
