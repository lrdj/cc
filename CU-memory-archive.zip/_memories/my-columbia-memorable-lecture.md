---
title: 'My Columbia: Memorable Lecture'
author: Saul Ricklin
layout: memory
schools:
  SEAS: 1939
primary_year: 1939
tags:
- Academics
- Lectures
- Arts
- Culture
---
# Memorable Lecture

In my 1939 freshman chemistry class, Professor Urey came into the class to tell us about the discovery of the neutron, which was not yet in our chemistry book.
