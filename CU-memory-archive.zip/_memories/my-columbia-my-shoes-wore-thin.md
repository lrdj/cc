---
title: 'My Columbia: My Shoes Wore Thin!'
author: Eleanor Berry
layout: memory
schools:
  TC: 1960
primary_year: 1960
tags:
- Campus
- Academics
- Abroad
- Travel
---
# My Shoes Wore Thin!

In the Program in Occupational Therapy, we often traveled many miles per day:  from 186th St. on the  west side to TC campus on 116th St. and south to 23rd St. and First Ave., many days on foot because wallets were empty!  Getting to my first class at TC by subway, I got off at one 116th Street station only to find that Morningside Heights was in the far distance to the west.  Having limited funds, I walked the distance through Harlem and received an earlier education than anticipated!  At graduation some years later, I was not only to receive my masters but was on staff in the Program of Occupational Therapy, and thus qualified to march and sit with the faculty on stage.  By sheer luck, my seat was quite close to the speakers and honorees, quite exciting for a lowly instructor.  My favorite spot was the view of the city from the roof of the Institute for Crippled and Disabled, where we first learned crafts for the OT program and later to taught them.
