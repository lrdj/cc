---
title: 'My Columbia: JJ7 24/7 365 420'
author: Hamesh Mehta
tags:
- John Jay
- Dorm life
- Campus
- Academics
- Relationships
layout: memory
schools:
  CC: 2004
  SEAS: 2004
primary_year: 2004
---
# JJ7 24/7 365 420

Ask Class of 2004 residents of the seventh floor of John Jay Hall about JJ7 and a wry smile will quickly adorn their faces. JJ7, as we affectionately called it, was our introduction to Columbia--and what an introduction it turned out to be!

From the onset, JJ7 was never going to be about respecting each other's privacy or the quiet hours, rather, we thrived on breaking the rules, with or without the RA around (sorry Munira). As a result, cricket in the hallway at 4 a.m., drinking games in the lounge during finals, and suspicious smoke from various corners became the little nuances that comforted us.

Of course, there were also the collegiate virtues of diversity, open dialogue, and sincere friendships, but all of those were overwhelmed by the storymaking that continued incessantly throughout the year. JJ7 was indeed very special, and one can only hope that we try keep it that way--if not for our memories, at least for the stories that have yet to be made.
