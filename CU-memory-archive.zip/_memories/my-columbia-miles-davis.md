---
title: 'My Columbia: Miles Davis'
author: james hill
layout: memory
schools:
  CC: 1978
primary_year: 1978
tags:
- Music
---
# Miles Davis

I can still hear Miles's cool horn, still see his back.  I think it was the autumn of '75 or '76, and we trucked over to Central Park for a free outdoor concert.  Yeah, he mixed some early cool school tracks and some fusion. Left us all hangin'. Everybody wanted more, and  Miles liked it that way.
