---
title: 'My Columbia: Documents to the People'
author: RE CARSCH
layout: memory
schools:
  LS: 1968
primary_year: 1968
tags:
- Campus
- Academics
- Library
- Study spots
---
# Documents to the People

In April 1968, the turmoil on campus led the University to close Butler  Library.  The Library School was on the top floor of Butler.  With the library closed, we were unable to attend classes.

A group of us got ourselves on to the strike coordinating committee in order to moderate the strikers and get the University to open Butler so that we could resume classes.  We had a bunch of buttons made up proclaiming "Documents to the people."

When the library was closed, I realized how important the right to information is in an open society.  I've been working in the public sector for the most part, since then.  I currently teach information literacy in a local college and provide reference services at the Main Branch of the San Francisco Public Library.
