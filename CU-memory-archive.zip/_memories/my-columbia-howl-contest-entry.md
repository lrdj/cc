---
title: 'My Columbia: Howl Contest Entry'
author: Wayne Jebian
layout: memory
schools:
  CC: 1991
  GSAS: 1998
primary_year: 1998
tags:
- Politics
- Activism
- Good trouble
---
# Howl Contest Entry

Do you remember River Rat? Dancing in the dregs,

Do you recall Phi Epsilon? Do you remember kegs?

In Manhattan, at Columbia, there was a microcosm of

America,

And the word up there was the word everywhere:

Culture war no more.
