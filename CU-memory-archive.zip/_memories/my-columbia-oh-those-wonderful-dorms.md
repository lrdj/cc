---
title: 'My Columbia: Oh, those wonderful dorms'
author: Matt Yospin
tags:
- East Campus
- Dorm life
- Campus
layout: memory
schools:
  CC: 1999
primary_year: 1999
---
# Oh, those wonderful dorms

Gosh, how do I miss them? What do I miss most? One of the best things was the view from East Campus. I liked staying up late and socializing in Carman: playing spades and hearts, chess, and Dorm Olypmics.

What do I miss least? Cinderblock walls in Carman. The constant decay in River. No one was amused when my neighbor's ceiling fell all over her room: several hundred pounds of soggy plaster smashing everything. She's lucky she wasn't there at the time. So is CU.
