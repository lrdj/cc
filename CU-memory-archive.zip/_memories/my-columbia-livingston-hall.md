---
title: 'My Columbia: Livingston Hall'
author: James Boyce
tags:
- Hartley
- Dorm life
- Campus
- Music
- Relationships
layout: memory
schools:
  PS: 1973
  CC: 1969
primary_year: 1973
---
# Livingston Hall

Freshman year I opted for the cheapest room I could find, which as I recall was $190/semester.  It was a double with bunk beds in Livingston Hall.  At left is a picture of the room with my roommate.  I really liked it at the time, mostly because I was so jazzed to be at Columbia and in NYC.   Sophomore year I shared a larger double in Hartley and in Junior year I had a relatively spacious suite in Hartley.  I was one of the few people who really liked the grub room in Hartley.  There were always friends around and seeing them "grub out" encouraged me to do the same.   The second hand smoke in there probably shortened all our lives by a few years.
