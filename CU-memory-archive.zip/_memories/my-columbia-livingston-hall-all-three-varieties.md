---
title: 'My Columbia: Livingston Hall: All Three Varieties'
author: David Levin
layout: memory
schools:
  SEAS: 1968
  CC: 1964
primary_year: 1968
tags:
- Dorm life
- Campus
- Academics
- Relationships
---
# Livingston Hall: All Three Varieties

As a NYC freshman in the (in)famous Dudley's Follies class, my parents and I thought that living away from home made sense.  Rather than live in the almost brand new NEW HALL (nu?), for whatever reason, I was placed in Livingston (poor guy, he's been preempted).  Originally in a small two-man (double-decker bed) unit, I switched with someone and was placed in a large room (529?) with a sophomore.  This was back in the days of daily maid service, a concept almost inconceivable today.  I stayed in Livingston all four years, eventually convincing two of my friends to move from New to a triple as seniors.  Plenty of pranks but a great experience.
