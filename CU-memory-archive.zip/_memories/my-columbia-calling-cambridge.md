---
title: 'My Columbia: Calling Cambridge'
author: John Gaguine
tags:
- Carman Hall
- Dorm life
- Campus
- Arts
- Culture
layout: memory
schools:
  CC: 1969
primary_year: 1969
---
# Calling Cambridge

One day in the late 1960s the folks in Carman Hall, Suite 604--the suite right behind the open area in front of the elevators--got a private phone connected.  Later that day someone came to use the campus phone, which was attached to the wall (ah, those wonderful cinderblock walls!) shared with Suite 604.  The phone user picked up the phone, realized that the dial tone sounded different, and tried to make a long-distance call.  It worked!  Obviously the phone installers had screwed up, and hooked the campus phone into the private phone line.

All that evening and into the next day there was a long line of people waiting to use the campus phone.  (For you youngsters, long-distance calls were a lot more expensive back then.)  I heard about people calling Beijing--I don't know if they really knew anyone there, but they called anyway.  (Maybe they wanted to talk to Mao--the Little Red Book was very popular back then.)  I recall one conversation I heard about--a person waiting to make a call asked the caller who he was calling, and got the response "Cambridge."  The asker expressed disdain that someone would waste all this free phone time just to call someone at Harvard, and got the response "No, Cambridge, England!"
