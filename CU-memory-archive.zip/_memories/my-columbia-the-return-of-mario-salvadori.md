---
title: 'My Columbia: The Return of Mario Salvadori'
author: Roch  Baamonde
layout: memory
schools:
  SEAS: 1988
primary_year: 1988
tags:
- Academics
- Lectures
- Music
---
# The Return of Mario Salvadori

In 1978, all engineering freshmen were required to attend a once-a-week engineering overview lecture.  The professor was Mario Salvadori, who was prompted to "un-retire" for this class.

During our first class, Dr. Salvadori explained his rationale for coming back at age 71.  He said "a professor's year is 9 months, a professor's month is 4 weeks, a professor's week is 3 days, a professor's day is 3 hours, and a professor's hour is 50 minutes.  They're paying me for nothing.  How could I resist?"

It was a great start to a great class.  He kept us entertained every class mixing in with his lectures anecdotes about his distinguished engineering and architectural career, his mountain climbing adventures, his music, and his work teaching advanced concepts to young kids.

He was wrong about paying him for nothing.
