---
title: 'My Columbia: Psychological Religion'
author: edmund klemmer
layout: memory
schools:
  GSAS: 1952
primary_year: 1952
tags:
- Religion
- Spirituality
- Academics
- Lectures
---
# Psychological Religion

During my time as a graduate psycholgy student 1948-52 I took completely elective courses on the Old Testament the New Testament.  With another grad student I sat in on a course on Genesis given at Union Theological Seminary.   These courses did not help me to get my Ph.D. degree but were a seminal contribution to both my personal religious views and my understanding of the history of the Bible and the development of Christian theology.

I hope that Columbia continutes to provide such opportunities to all of its students.

P.S. My personal beliefs are now similar to those of Edward O. Wilson of Harvard and Daniel Dennett of Tufts.

Edmund T. Klemmer   Grad School '52
