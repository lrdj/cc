---
title: 'My Columbia: If I Could Find the Time to Hang Out...'
author: Yalman Onaran
tags:
- Low Library
- Library
- Study spots
layout: memory
schools:
  SIPA: 1993
  JRN: 1992
primary_year: 1993
---
# If I Could Find the Time to Hang Out...

I din't have much time to hang out when I was at CU. My studies were demanding (one year in journalism, followed by one year in SIPA, two master's degrees squeezed into two years), and I had to work 20 hours a week to earn a living. So there was little time to hang out and relax. But I do remember the few moments I could find to do so. My favorite spot was the steps in front of Low Library. You could see tons of people pass by, watch romantic couples frolic, others study. Unfortunately, I didn't have a laptop at the time (not many people did in the early 1990s), so I could only spend time in front of Low Library when I had reading assignments. After I graduated, started full-time employment and was able to afford my first laptop, I was so proud to take it there at the first chance and pretend to be a CU student doing his work. I sensed the stongest sense of community at CU right on those steps. To this day, when I visit the U.S. once every six months, I try to stop by at the school and sit at the steps for a bit to relive that feeling.
