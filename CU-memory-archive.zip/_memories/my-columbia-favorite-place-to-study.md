---
title: 'My Columbia: Favorite Place to Study'
author: Sheila Grant
layout: memory
schools:
  SDOS: 1961
primary_year: 1961
tags:
- Winter
- Weather
- Library
- Study spots
- Music
---
# Favorite Place to Study

My favorite place to study for second semester exams was in front of the library, on the grass.  There was beautiful music always playing over a loud speaker.  The weather was wonderful after the cold winter.
