---
title: 'My Columbia: Make It Good!'
author: Dan Ng
layout: memory
schools:
  CC: 1994
primary_year: 1994
tags: []
---
# Make It Good!

My strongest memories of Tom's Restaurant were always of Pete, who would add, "Make it good!" to kitchen orders, as if otherwise the cooks would "Make it bad!"

The other enduring image I have of Tom's was watching the waitstaff deal with the messiness of RealityFest.  One year I looked over at another table and I swear that someone was trying to eat a chocolate eclair through the forehead.  The staff at Tom's acted as if this were perfectly normal, wiped up the mess, and just continued slinging corned beef hash.
