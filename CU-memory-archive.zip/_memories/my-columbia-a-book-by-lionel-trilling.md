---
title: 'My Columbia: A Book by Lionel Trilling'
author: Edward Martin
layout: memory
schools:
  GSAS: 1962
primary_year: 1962
tags:
- Arts
- Culture
---
# A Book by Lionel Trilling

I was an MA then -- a PhD student in the 1950s. One book of special importance to me was The Liberal Imagination, as amplified in several of the courses Lionel Trilling taught during my residence at Columbia.
