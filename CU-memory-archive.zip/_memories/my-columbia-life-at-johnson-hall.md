---
title: 'My Columbia: Life at Johnson Hall'
author: Brian Brouse
layout: memory
schools:
  BUS: 1975
primary_year: 1975
tags:
- Dorm life
- Campus
- Academics
- Food
- Dining
- Relationships
---
# Life at Johnson Hall

I arrived at Columbia University and Johnson Hall in August/September of 1975.  This was the first academic year that Johnson Hall was coed. Previously it had been a women's graduate dorm.  I believe two or three floors housed men.  We had security and a "house mother."  Because it was coed and because of the house mother, cleanliness and orderliness were good.  And as far as dorm food was concerned, it was good.

I enjoyed the living situation for it gave me the opportunity to meet and be friends with others who were not in the same discipline as me, a student in the Graduate School of Business. Having grown up in Tulsa, Oklahoma and having attended college at Northwestern University, living in NYC was a wonderful experience for me.  I enjoyed grad school.  It was not as competitive as I thought it would be. In fact, several of our class projects were team-oriented.  The city as a whole became my textbook, and I fell in love with NYC, which I still love to this day.
