---
title: 'My Columbia: Sledding on the Lowe Steps'
author: Matthew Yospin
layout: memory
schools:
  CC: 1998
primary_year: 1998
tags:
- Winter
- Weather
- Politics
- Activism
- Good trouble
---
# Sledding on the Lowe Steps

How we kept warm in the winter: we would borrow lunch trays from the cafetorium when we got a good snow, and sled down the Steps.  It was  fun, and challenging.  Those trays don't offer much of a handhold.  That was the winter part -- the keeping warm came from charging back up the steps.  That, and snowball fighting and wrestling.

I also liked to go cross-country skiing, just after or during a storm.  In the city, that was always a treat -- especially because there would be almost no cars out, and all the other people who were outside were fans of winter and enjoying it.  I also skied along the Palisades when I was a student at Lamont-Doherty.  The views from those cliffs are stunning.
