---
title: 'My Columbia: Noise'
author: Robert Kovarcik
layout: memory
schools:
  SEAS: 1972
primary_year: 1972
tags:
- Arts
- Culture
---
# Noise

One of the courses I took for my Master's degree in Electrical Engineering (1972) was called Noise and Random Processes. The text was titled Noise. On my bookshelf in my office at work, this book always elicited questions from non-engineering types who saw it. No one could really understand why a book could or would be written on noise. Further, when they took the book from the shelf and looked over the pages, they immediately returned it to the shelf. The book is totally mathematical, with relatively complex algebraic equations.

It still gets the same reactions today after all these years.
