---
title: 'My Columbia: Warm Weather in Manhattan'
author: "Guy B\xE9lisle"
layout: memory
schools:
  BUS: 1981
primary_year: 1981
tags:
- Winter
- Weather
- Academics
- Library
- Study spots
- Politics
- Activism
- Good trouble
---
# Warm Weather in Manhattan

In Canada, where I'm from, September marks the end of summer, with days getting shorter and temperatures dropping. In November, snow starts, and it gets really dark outside. Then, in December, it gets very cold, and life seems to stop for a few months...

Some of my best memories of Columbia are the hot late summer days and warm autumn days; of sitting on the steps of Low Memorial Library and just enjoying the sun after class.

Of course, in New York, winter eventually comes, but in late February the  air gets milder and cherry trees near the Business School are in full bloom a few weeks later. And then, again, we are able to enjoy the sun sitting on the steps of Low Memorial Library...
