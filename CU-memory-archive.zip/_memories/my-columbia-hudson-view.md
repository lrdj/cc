---
title: 'My Columbia: Hudson View'
author: Catherine Mansell
layout: memory
schools:
  SPH: 1973
  TC: 1982
  NRS: 1972
primary_year: 1982
tags:
- Dorm life
- Campus
---
# Hudson View

After transferring from a school with cinderblock housing, metal bunk beds, and views of the nothingness of the middle of Indiana, I found myself in an end room of Maxwell Hall overlooking the Hudson. It was 1971. Not only did I have beautiful wooden moldings, a terrific view of the George Washington Bridge, but also maid service to clean my room and change my sheets.
