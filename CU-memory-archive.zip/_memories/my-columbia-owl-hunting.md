---
title: 'My Columbia: Owl Hunting'
author: Caitlin Schrein
tags:
- Spectator
- Politics
- Activism
- Good trouble
- Relationships
layout: memory
schools:
  CC: 1999
primary_year: 1999
---
# Owl Hunting

I have the fondest memory of orientation week, thanks to the Columbia Spectator. Some of my new friends (who after a week of pre-orientation in the Catskill Mountains felt like old friends) were enjoying a warm early autumn night on the steps, and we decided to search for the owl in Alma's cloak.  A reporter from the Spec snapped our photo as we scoured the statue, and I was pleased to find the pic in the paper soon after! I still have that photo of us all, so young and carefree - as I think back on it now - with no idea what adventures and challenges lie ahead of us.  I'll always be happy to have that photo as a reminder of those good times.
