---
title: 'My Columbia: My Most Memorable Cultural Experience at Columbia'
author: Russ Raman
layout: memory
schools:
  BUS: 1975
primary_year: 1975
tags:
- Academics
---
# My Most Memorable Cultural Experience at Columbia

My first (and most memorable) cultural experience at Columbia occurred during my first week as a new MBA candidate at the Graduate School of Business in the Fall of 1973, when one of my classmates suggested we venture south of 110th Street and explore our new neighborhood.  Much to our delight, at around 99th Street and Broadway, we discovered an X-rated adult movie theatre which we immediately entered and screened two stimulating (and highly appropriate) films that helped acclimate us to our new New York experience:  "Masters Degree" and "High Rise."
