---
title: 'My Columbia: Shooting Stars'
author: L Chou
tags:
- Alma Mater
- Avery Hall
- Dorm life
- Campus
layout: memory
schools:
  GSAPP: 2003
primary_year: 2003
---
# Shooting Stars

I still vividly remember the freezing November morning that I spent on the steps in front of Alma Mater.  It was around 4 a.m., and we were still working at Avery Hall, researching and designing.  By 5 a.m., one of our studio-mates informed us that there was a meteor shower coming up. Though already tired and exhausted from working, we decided not to miss this rare experience. Thus, many of us rushed to the steps and began waiting for the show from the sky.  The campus was dark and the sky was clear---perfect for star watching.  We lay on the steps talking excessively as a way to keep ourselves awake as we waited. Finally, the stars began to cross the sky one by one around 5:30am. We cheered and made many, many wishes.  Thinking back, we were like those shooting stars that carried so many hopes and wishes dashing through our times at Columbia.
