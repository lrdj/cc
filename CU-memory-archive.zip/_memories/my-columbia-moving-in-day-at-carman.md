---
title: 'My Columbia: Moving In Day at Carman'
author: Sydney Blattner
layout: memory
schools:
  CC: 1990
primary_year: 1990
tags:
- Dorm life
- Campus
---
# Moving In Day at Carman

My first year at Columbia, I lived in Carman, which was a brand new dorm.  Moving in went smoothly until the door to the room got stuck closed - with my mother inside.  We spent the next hour trying to open the door and the hour after that searching for someone else who could.  Fortunately, Mom didn't have to use the bathroom!

She still tells that story after all these years...
