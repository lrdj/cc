---
title: 'My Columbia: De-stressing'
author: Maria Wilkes (formerly Martinez)
layout: memory
schools:
  SW: 1977
  SPH: 1980
primary_year: 1980
tags:
- Library
- Study spots
---
# De-stressing

I remember many great times being at Columbia's schools of social work and public health.  The one memory that was "therapeutic" was the time when I just finished all of my exams from S.W. I had so much energy -- I guess from all the caffeine I had drunk during all the studying I did -- and didn't know how to just relax.  I was equally emotionally drained given the hours of sleepless nights and working two jobs to get through it all!  Columbia's recreational facilities were JUST the thing.  I ran in the indoor track (4 miles +), swam laps for about thirty minutes, went to the sauna and just relaxed.  I went home and slept like a baby.  Thanks Columbia, you were just what the Doctor ordered!!!  What a way to finish a year at school!

Maria
