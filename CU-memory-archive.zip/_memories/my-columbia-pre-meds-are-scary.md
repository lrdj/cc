---
title: 'My Columbia: Pre-Meds Are Scary'
author: Linda Gaines
layout: memory
schools:
  GSAS: 1977
primary_year: 1977
tags:
- Academics
---
# Pre-Meds Are Scary

I was teaching lab sections for Leon Lederman in the basic Physics class that pre-med students were required to take. One day there was a demonstration planned using lasers to show how light was refracted in different media. As the students came in, I told them there was a really cool demonstration. One young woman asked, "Do we have to know it? Are we going to be tested on it?" She had no curiosity at all and was just interested in her grades.  I hope she didn't become a doctor, don't you?
