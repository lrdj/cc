---
title: 'My Columbia: Porpoises and Philosophy'
author: Thomas Cockbill
layout: memory
schools:
  GSAS: 1976
primary_year: 1976
tags:
- Dorm life
- Campus
- Academics
- Lectures
---
# Porpoises and Philosophy

It was the first lecture in a graduate course on German philosophy between Kant and Hegel.  Dieter Henrich, a visiting professor from Germany, was giving the packed lecture hall an introduction to the subject, when a person in the last row of seats suddenly called out, "What is the purpose of philosophy?"  The questioner, who was not enrolled at the university, frequented philosophy classes on campus, in one classroom moving about from desk to desk throughout the period.

Because this person spoke with an accent (as did the professor), Henrich had difficulty understanding what was said.  After some back and forth, he seemed to grasp the question.  Henrich hesitated, then frowned.  He shot back, "I don't know what porpoises have to do have to do with philosophy."
