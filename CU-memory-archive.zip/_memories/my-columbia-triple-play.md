---
title: 'My Columbia: Triple Play'
author: Rick Blank
layout: memory
schools:
  CC: 1973
primary_year: 1973
tags:
- Sports
- Athletics
---
# Triple Play

I was playing second place for the Lions.  We were playing Yale at Coakley Field on a Friday afternoon in 1972.  The Elis had first and second and no outs, and the batter (who was also the Yale quarterback on their football team, though his name escapes me--it's only 36 years later), squared to bunt.  Our first baseman, Bill Ebner, headed towards the plate, I ran to cover first.  The bunt went up right down the first base line, and Ebner had a bead on it.  As a result, both baserunners headed back to second and first respectively.  The batter actually made contact with Bill, and the umpire called nothing, but the contact dislodged the ball.  Bill turned and threw to me at first to retire the batter.  I started to run down the runner who had returned to first and now had to get to second.  I chased him and tagged him out for out #2.  The runner on second had returned to second, but when he saw the runner from first approaching him, he headed for third.  After I tagged the runner on the way to second I headed towards third, flipped the ball to our third baseman, (name again eludes me), he applied the tag, and voila, triple  play.    Don't  know of any others in Lions' history (there may be some), but that is the most amazing thing I saw in all my years watching (and playing) Columbia athletics.

Rick Blank '73
