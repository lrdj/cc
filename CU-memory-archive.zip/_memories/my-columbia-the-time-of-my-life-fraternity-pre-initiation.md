---
title: 'My Columbia: The Time of My Life: Fraternity Pre-Initiation'
author: Jefferson Svengsouk
layout: memory
schools:
  CC: 1990
primary_year: 1990
tags: []
---
# The Time of My Life: Fraternity Pre-Initiation

The most memorable time of my life at Columbia was the pre-initiation night for me and my pledge brothers of Zeta Psi fraternity. As we went from one assigned mission to the next through the entire night until the wee hours of morning, I was electrified by the unified efforts of my pledge brothers in a shared experience, striving towards a common goal. We strove to participate in and entwine our existences with a fraternity community with generations of history, liberating ourselves from the restraints of common and decent society through directed, sophomoric, insane, yet non-malignant behavior to become one with something bigger than any one of us alone. 

There are few other times in my life I have felt so alive. I am confident that those girls we serenaded would not disagree.
