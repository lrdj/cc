---
title: 'My Columbia: "What''s a Nice Girl Like You Doing in a Place Like This?"'
author: Michael  Goldman
layout: memory
schools:
  CC: 1963
primary_year: 1963
tags:
- Dorm life
- Campus
- Religion
- Spirituality
---
# "What's a Nice Girl Like You Doing in a Place Like This?"

Among the endless forms required of first-time registrants in 1959 was one asking "Religious Preference."  I don't know if "none" was an option, but to leave no doubt I wrote "I do not believe in religion in any form," or something even more youthfully defiant, across the form (which had no space for comments).  The campus rabbi (is there still a campus rabbi?) was not fooled.  I was summoned (to Earl Hall, I think) and in 30 seconds he discovered the problem:  I did not believe in God.  "God?" he laughed.  "Don't be silly; I don't believe in God either!  Come to one of our socials; maybe you'll meet a nice girl."  So I did, and I did.
