---
title: 'My Columbia: Commencement Beer Run'
author: Matthew Yospin
tags:
- Commencement
- Relationships
layout: memory
schools:
  CC: 1998
primary_year: 1998
---
# Commencement Beer Run

One of my favorite memories of Columbia was Commencement Day, when friends and I brought several bottles of bubbly, both beer and wine, to the ceremonies.  It was a hot and sunny day, and, as Kofi Annan's speech ran long, we ran dry.  I got up and ran to the gate at 116th and Broadway, waving to my family sitting on South Lawn.  I told the guard that I had to go buy more champagne and that I'd be back soon.  He gave me a funny look.

In my cap and gown, I ran to the liquor store (on 108th I think), bought a couple of bottles, and ran back up.  The same guard gave me the same funny look, but the cap and gown convinced him, and he let me back in.  There was still plenty of time to enjoy the bubbly and the graduation!
