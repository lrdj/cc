---
title: 'My Columbia: Prominent Classmate from Israel'
author: Lou Greer
layout: memory
schools:
  BUS: 1961
primary_year: 1961
tags:
- Academics
- Relationships
---
# Prominent Classmate from Israel

I got married during my Columbia experience and helped found the University rugby team, so there wasn't a lot of time to be a part of the community.

However, there was one friend I was particularly fortunate to make, a low-key Israeli gentleman whom I immediately liked a lot. He was older than most of his classmates, and before we graduated, he gave me a business card that pronounced that he was a brigadier general in the Defense Forces. It wasn't until I read "The Odessa File," a historical novel about neo-Nazism, that I learned that this man was the head of ALL Israeli intelligence.

Since then, I have brought up his name to other Israelis I've met, and learned that he was among the five or six most important men in Israel in his time - interesting!
