---
title: 'My Columbia: Best Teacher'
author: Stephen Page
layout: memory
schools:
  GS: 1997
primary_year: 1997
tags: []
---
# Best Teacher

Colette Inez.

For her apt handling of subject matter, and concern for student learning.
