---
title: 'My Columbia: The Dungeon'
author: Shre Roy
tags:
- Barnard
- Academics
- Abroad
- Travel
layout: memory
schools:
  SEAS: 1989
primary_year: 1989
---
# The Dungeon

Walking in the crisp fall air at Columbia, I always wondered why my computer science lab was in this underground bunker type space next to the gym. It was 1985 and anyone who took a computer science course had the option of using this computer lab that was underground and pretty creepy.

I started calling it the Dungeon, which was fitting since "Dungeons and Dragons" was a popular game at the time.

I spent most of my freshman year stuck in the Dungeon contemplating inexplicably bizarre programming problems, like why I needed a flow diagram for creating an array. I had to write a program from scratch on queueing cars efficiently though traffic tolls, which to this day I think of everyday when I travel through the Turnpike tolls to and from New York and New Jersey.

While I languished daily in the Dungeon, my classmates at Barnard and the College felt pity for me and would come and visit me sometimes. There were very few women in this Dungeon besides me and when my gal pals would show up all the guys would try to come over and talk with us.

I wonder what became of the Dungeon. Thankfully, with laptops and PDAs students nowadays probably no longer go to such depressing places.
