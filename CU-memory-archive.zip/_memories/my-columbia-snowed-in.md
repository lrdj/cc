---
title: 'My Columbia: Snowed In'
author: georgia kernell
tags:
- Low Library
- Dorm life
- Campus
- Winter
- Weather
- Library
- Study spots
- Food
- Dining
layout: memory
schools:
  GSAS: 2007
primary_year: 2007
---
# Snowed In

If I could relive one day in my experience at Columbia it would be a day in February 2003 when school was cancelled because of a heavy snow storm.  I think the central campus was more active that day than any other.  The steps were so covered with snow that we couldn't identify where they started or stopped.  People were skiing, snowboarding, sledding and barreling down the slope in front of Low Library anyway they could.  I saw people do flips in the air - something I've never seen on a ski slope - right over the fountains at each end.  The most popular modus operandi were serving trays from the dining halls.  I used a trash can lid, until a little 5-year-old girl let me borrow her inner tube shaped like a dragon.  Then, my roommate, boyfriend and I went to Tom's Diner for hot chocolate.  It was the only time I think I ever enjoyed eating there!  That was my favorite day at Columbia and a day that a girl from San Diego would write home about.
