---
title: 'My Columbia: Winter in New York'
author: Julia Lyon
layout: memory
schools:
  CC: 1996
  JRN: 2001
primary_year: 2001
tags:
- Dorm life
- Campus
- Winter
- Weather
- Abroad
- Travel
---
# Winter in New York

What I remember most about my first Columbia winter was how it stopped me in my tracks. Spring break 1993 became "stay-in-the-dorm, give up on travel, and sleep" time. But it fulfilled all those magical idealized visions that the rest of the country has of NYC. Everything stopped, including many of the trains, and you could walk through the streets - literally - without checking for traffic. Sort of movie perfect, in a way. My only regret is that I didn't have any skis at the time ...

But, even more memorably, is how my Hawaiian floormate suffered through her first winter there. She wore long underwear almost every day. I've always wondered if she finally got used to the cold.
