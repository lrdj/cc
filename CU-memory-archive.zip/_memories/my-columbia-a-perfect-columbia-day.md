---
title: 'My Columbia: A Perfect Columbia Day'
author: David Raddock
layout: memory
schools:
  GSAS: 1974
primary_year: 1974
tags:
- Dorm life
- Campus
- Library
- Study spots
---
# A Perfect Columbia Day

Of all the days that linger in my memory, one from my graduate study at Columbia stands out in particular.  It was my doctoral defense with visiting professors from Michigan, Yale and Columbia P&S.  I could barely sleep the night before and was up at Kent Hall hours early.

I recall seeing a participating professor and asking him if I could now call him by his first name, "Marty."  "Let's see how you do," he smiled.  In a small room, I experienced what perhaps was the freest and most stimulating exchange with my professors in years of grind and bureaucratic hurdles.  And those who taught me now responded with applause. I floated from the room and thanked "Marty" and the others.
