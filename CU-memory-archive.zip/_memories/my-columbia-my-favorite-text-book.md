---
title: 'My Columbia: my favorite text book'
author: john mc gough
layout: memory
schools:
  GS: 1954
primary_year: 1954
tags:
- Arts
- Culture
---
# my favorite text book

While at Columbia we used Richard Courant's "Differential and Integral Calculus."

It's been my constant companion for forty years.

I taught mathematics for twenty years and never found a textbook comparable.

Unfortunately it went out of print around 1950.

It now costs $300 at Amazon.

John Mc Gough
