---
title: 'My Columbia: To Thine Own Self Pay Heed'
author: Lawrence Chung
layout: memory
schools:
  SEAS: 1978
primary_year: 1978
tags:
- Campus
- Academics
- Abroad
- Travel
- Relationships
- Personal growth
- Reflection
---
# To Thine Own Self Pay Heed

If I could travel back in time to 1974 and translate my regrets into good counsel to my freshman self,  I would say go ahead and be a "grub."

"Do all the problem sets the professor assigns.  Sit near the front of the class and not hang out in the back. Go to every recitation no matter how poor the T.A.'s command of English may be. Do every scrap of reading for C.C. and then some more. You will need it more than most other things you will be learning. Get at least 8 hours of sleep and that means leaving weekend campus mixers long before they are over. Although it's good to resist peer pressure to be lazy, be sure to make time for meaningful conversations with the good friends you made on campus.  Some of them could be yours for life."
