---
title: 'My Columbia: Proust on the Lawn'
author: Arvin Levine
tags:
- Furnald Hall
- Dorm life
- Campus
- Academics
- Politics
- Activism
- Good trouble
layout: memory
schools:
  CC: 1971
primary_year: 1971
---
# Proust on the Lawn

One of my favorite recollections from my freshman year is going out onto the (great) lawn in front of Furnald Hall in late spring (finally warm weather!) with my copy of Proust's "A la Recherche du Temps Perdu (Remembrance of Things Past)"  for my French literature class.  It's a lazy sort of memory.

The curious thing was that I had a slight rag fever, which was easily set off by the grass on the lawn.  Thus, between drowsing through a paragraph or two, and, with my eyes gently closing on the text in the mildly warm sun, I would start to sneeze and have a runny nose with watery eyes that would force a hasty retreat to the sterility of my dorm room.

Naturally, at that point, the Proust would be set aside for a later date with the lawn.  Now, years later, I believe completion of that reading assignment is still pending.  Does outgrowing my rag fever re-awaken the requirement?
