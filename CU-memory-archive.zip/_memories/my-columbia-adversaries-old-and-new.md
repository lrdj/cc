---
title: 'My Columbia: Adversaries, Old and New'
author: Andrew Fisher
tags:
- WKCR
- Ferris Booth
- Dorm life
- Campus
- Sports
- Athletics
layout: memory
schools:
  CC: 1965
primary_year: 1965
---
# Adversaries, Old and New

In 1964, I was a staff announcer at WKCR and was assigned to do the halftime newscast at the Columbia-Princeton basketball game.  For some reason, I could not do the newscast from the WKCR studios in Ferris Booth Hall and had to deliver the newscast from the sidelines of the game itself, in the old University Hall gym.

On the court, Columbia was struggling valiantly against Princeton immortal Bill Bradley.  Next to me on the bench was WKCR sports director Jeff Bell.  We almost beat Bradley and Princeton that night, hinting at the coming glory days of Columbia basketball.

Fourteen years later, Jeff Bell beat venerable Republican Clifford Case for the Republican nomination for the U.S. Senate from New Jersey.  His (victorious) opponent that fall?  Bill Bradley, who went on to serve three terms.

[I was still on the sidelines, covering the Senate race for WNEW.]
