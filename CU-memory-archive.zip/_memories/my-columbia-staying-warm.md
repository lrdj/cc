---
title: 'My Columbia: Staying Warm'
author: Amy Bryer Rojas
layout: memory
schools:
  SDOS: 2004
primary_year: 2004
tags:
- Winter
- Weather
- Academics
- Arts
- Culture
- Food
- Dining
- Politics
- Activism
- Good trouble
---
# Staying Warm

A daily endeavor in the New York winters. Layering...that was the key. Hopefully, the snow was new or maybe if I was lucky there would be no snow at all. Because if it was one of those days that the snow had already begun to melt... Oh. Watch out.

(I was always in a rush...in keeping with the rythm of New York, of course.)

Inevitably, as I rushed and took my first step to cross the street, I would get the dirty, slushy snow splashed halfway up my calves.  (The slush would gather on the frozen or clogged drains).

A quick stop at the food/coffee cart. Ahhh, to the Hospital at last.

But what was this? I entered the Black Building into sweltering heat!

Then, I carefully peeled off the top few layers...just enough so that I could carry that load plus my books, coffee (made with the water that was usurped by the "Roach Coach" from the spiggot emerging from the outside wall of the Black Building), and bagel.

However, beads of sweat welled up on my back and forehead anyway from the blast of heat felt upon stumbling through the revolving door. I reached my class, peeled off all the rest of my layers, and then I was fine.

As I emerged from the class I gathered up all my clothes: the huge jacket, 2 zipper sweaters, 1 pull-over, scarf, hat, gloves, ear muffs, outer pants and umbrella, because I did not have time to redress before the next class came in.

I had 2 hours until my next class.

Before exiting the building, I methodically layered once again. Upon leaving the building, I instantly felt a chill where all the beads of sweat had gathered.

And on and on it went...

I love winter in NY and my Columbia experience!

Now, I practice the art and science of dentistry in Virginia with the Navy on The Enterprise (no, the Captain is not Scotty)....but that is another story for another time and place!
