---
title: 'My Columbia: A Wonderful and Baffling Mix'
author: Steve Conway
tags:
- Columbia College
- Campus
- Academics
- Politics
- Activism
- Good trouble
- Relationships
layout: memory
schools:
  GSAS: 1971
  CC: 1969
primary_year: 1971
---
# A Wonderful and Baffling Mix

As one of seven kids in a Philadelphia working-class home, I never expected college, but a National Merit Scholarship made it feasible. My Princeton visit convinced me I'd be a misfit there (tall blonde guys in blazers). Then a train trip (no car) when I was 7 to see the Giants and Dodgers play and to see the subway and Central Park made me long for New York. The Columbia College of the mid-1960s was a wonderful and baffling mix: scions of the WASP-ocracy that once had been ubiquitous on campus (tall blonde guys in blazers); lots of eager middle-class sons; and a smattering of working-class boys. When I caught the anti-Vietnam War fire, my father said I was a fool and "all those middle-class radicals will be doctors and lawyers in ten years. It's not the same for people like us." It wasn't, and neither did all the middle-class radicals become doctors and lawyers (not that that's bad). A few became my lifelong friends.
