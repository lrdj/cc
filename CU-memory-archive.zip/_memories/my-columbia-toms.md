---
title: 'My Columbia: Tom''s'
author: carol chetrick
layout: memory
schools:
  SW: 1977
primary_year: 1977
tags:
- Food
- Dining
- Relationships
---
# Tom's

I was a graduate student from a much smaller city--and Morningside Heights was not then, 1971, what it is now! Tom's was not the facade for the fabulous Seinfeld episodes. It was rather disgusting--in terms of the ambience--and as I recall, the food was not great either. But we huddled there, in this barren stretch of Broadway, eating our eggs, and recovering from the horrors of field visits for our Social Work degrees. In my first year, I was in a respected child welfare agency and sent off to evaluate whether homes and families were fit to have their children returned from Foster Care. This was more than I could handle most of the time; however, other friends had similar or worse scenarios, and all needed coffee and eggs over or scrambled with toast. Potatoes were mandatory--no such thing as subbing tomatoes--and we smoked--endless ashtrays full--to try to cope with helping a world we knew something, yet little about.
