---
title: 'My Columbia: A Happy Baby at Columbia'
author: Vanessa Cox Nishikubo
layout: memory
schools:
  GSAS: 1991
primary_year: 1991
tags:
- Campus
- Library
- Study spots
- Arts
- Culture
- Food
- Dining
---
# A Happy Baby at Columbia

It's funny I've been asked this question as I was just thinking of it the other day. My favorite place to relax on campus, and I did it A LOT, was at the...(can't remember the actual library name but it's the huge, main one...) library with a book in hand, in one of those cushy chairs they had then. I would sit there for 2-3 hours in perfect bliss reading assigned or un-assiged literature. How did I sit still for so long you may wonder? Well, my first stop was always the gym where I got my ya-yas spent running, lifting weights, swimming until I was RELAXED. Then I'd go to the little health food store nearby (wonder if it's still there, as it was very popular with the crunchy-granola types) and buy a large smoothie. I'd sit in my comfy chair perfectly happy, sipping my shake, relaxed and reading my book like a happy baby. All my needs met.
