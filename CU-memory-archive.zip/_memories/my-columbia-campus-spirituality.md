---
title: 'My Columbia: Campus Spirituality?'
author: Sameena Khan
layout: memory
schools:
  CC: 1986
primary_year: 1986
tags:
- Campus
- Spirituality
- Religion
---
# Campus Spirituality?

To be honest, at that point in my life, spirituality was not on my agenda. I have examined it later on.  I would say though that learning about and therefore becoming comfortable with my family's cultural, and religious background (having been born and raised in the western hemisphere) was something that I pursued during college. This endeavor I acomplished directly through my choice of major studies and therefore Columbia directly really helped me with that.
