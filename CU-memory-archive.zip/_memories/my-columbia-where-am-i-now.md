---
title: 'My Columbia: Where Am I NOw?'
author: Jackson Sheats
tags:
- Columbia College
- Academics
- Relationships
layout: memory
schools:
  CC: 1948
primary_year: 1948
---
# Where Am I NOw?

Coming to New York City at the age of 17 from Memphis was a great challenge - one that my mother said ruined me for life - but in my opinion it made my life. I had many friends in NYC, and they basically didn't like the Southern boy, but it all ended up positively. My happiest memories are of being in the Glee Club and the classes with the renowned teachers at the College. I have not been able to keep in touch with my classmates, but am still very proud of having been able to attend Columbia College and what I learned there.
