---
title: 'My Columbia: Sunday mornings at Columbia Chapel'
author: Brietta Savoie (nee Giger)
layout: memory
schools:
  LS: 1957
primary_year: 1957
tags:
- Dorm life
- Campus
- Spirituality
- Religion
- Relationships
---
# Sunday mornings at Columbia Chapel

An Episcopalian friend of mine, whom I had already known as an undergraduate at Ohio State and who was getting her masters in English Lit at Columbia, sang in the choir of the Columbia Chapel.  We both lived at Johnson Hall (at that time the Graduate Women's dormitory).  She invited me to the services at the Chapel and I enjoyed hearing plain chant for the first time, as well as the contemplative atmosphere of the service.

My friend Pat also invited me to the weekly spaghetti suppers offered every Sunday night in the basement of the Cathedral of St. John the Divine, which I enjoyed also.  I had been raised as a Presbyterian, but at this time did not have an affiliation.  Today I am happily a Unitarian, for me a true spiritual home in accord with my deepest beliefs.          Brietta Giger Savoie
