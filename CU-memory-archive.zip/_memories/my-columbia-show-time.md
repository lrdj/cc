---
title: 'My Columbia: Show Time'
author: Jeffrey Mark
layout: memory
schools:
  CC: 2005
primary_year: 2005
tags:
- Winter
- Weather
- Library
- Study spots
- Music
- Relationships
---
# Show Time

My strangest and possibly my fondest memory in the Columbia library took place late one night during the cold month of February. I was studying in the large room in the back for my orgo test the following day. I was there with a friend, who was sitting in one of the carrals. She was a shy girl and was completely engrossed in her studies. All of a sudden, a group of 3 guys and 2 girls walk in dressed in 60s-style clothing and plugged in a boom box. Hip-hop music starts to play, and they strip down into I guess what one might call revealing bathing suits.

The entire room begins to dance to the music -- everyone, except for my friend that is. She refuses to take part in the festivities until all five of the "partiers" start dancing around her. They procedd to get up onto her desk and dance.  She was mortified.

Needless to say, my orgo studies were not the same.
