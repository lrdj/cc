---
title: 'My Columbia: A Perfect Match Made in the Dormitory'
author: Adam Bender
tags:
- Carman Hall
- Dorm life
- Campus
- Arts
- Culture
layout: memory
schools:
  CC: 1964
  PS: 1968
primary_year: 1968
---
# A Perfect Match Made in the Dormitory

Back in 1960, the Carman Hall dormitory had just opened and was still known as New Hall. The college and the dormitories were all male and the rules did not allow unchaperoned women in the rooms.

In 1961, a new rule took effect that was considered very progressive at the time. During certain daylight hours, women were actually allowed to come into our rooms unchaperoned, on one condtion: There had to be "a book in the door" to keep it open. The dean assumed that such a threat of exposure would prevent us gentlemen from taking too many liberties with our lady guests.

Being the clever and literate Men of Morningside that we were, we decided to interpret the definition of "book" very liberally. We opened a match book and pushed the cover between the doorpost and the closed door  - and the rest is history!!
