---
title: 'My Columbia: Adoption'
author: Maura Smith
layout: memory
schools:
  GSAS: 2002
primary_year: 2002
tags:
- Winter
- Weather
---
# Adoption

It was a cold, rainy day in Novemebr. I stood at the corner of 115th, heading to noon Mass at Notre Dame church. My cell phone rang. I answered it. A woman from DCFS was calling asking about a little girl I knew. She wanted to know if I was interested in adopting the girl. I said, yes. She then went on a tirade about how this little girl was too difficult, had had fourteen placements and that no one would keep her. She convinced me.

I went into church, saw the statue of Our Lady of Lourdes, went out in the rain and called the woman back. No. I want the child.

Elle was adopted by us two years ago. And, yes, she is tough. But, popping into that church near Columbia changed one little girl's life.
