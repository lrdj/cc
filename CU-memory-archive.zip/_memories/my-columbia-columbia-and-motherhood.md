---
title: 'My Columbia: Columbia and Motherhood'
author: Sadia Huq
layout: memory
schools:
  GS: 2004
primary_year: 2004
tags:
- Library
- Study spots
---
# Columbia and Motherhood

I am the only college-degree holder in my family. Having battled the odds at an early age, I broke away from traditions and customs and managed to get into one of the best institutions in the world. Columbia has greatly contributed to the person I am today. I gave birth to my two daughters when still studying here; amidst the gruelling exams and work load, I knew it was all worth it. Today I am both proud and humbled by my experience at Columbia. It was a privilege to be here.
