---
title: 'My Columbia: My Heart Remembers with a Great Fondness'
author: Neil  Cowan
tags:
- College Walk
- Campus
layout: memory
schools:
  GS: 1960
primary_year: 1960
---
# My Heart Remembers with a Great Fondness

It was in the spring 1959 after the semester had ended and the summer school semester had yet to begin when I had a surge of affection for C.U. I walked on to the campus, stood on College Walk, turned to Butler and said to myself with great pride, "This is my school. Perhaps it has always been my school?  But now there was something about being a student in G.S. that made it so wonderful."

Since I said this, that same feeling returns every time I walk on to the campus. Nothing in the world beats that sense of ownership--certainly exaggerated but heartfelt nevertheless.
