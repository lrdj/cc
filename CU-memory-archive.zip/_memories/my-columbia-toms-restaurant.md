---
title: 'My Columbia: Tom''s Restaurant'
author: John  Sesek
layout: memory
schools:
  CC: 1976
primary_year: 1976
tags: []
---
# Tom's Restaurant

Long before Tom's Restaurant became famous as the setting for Seinfeld, 114th Street and Broadway was my home away from home in my mid-70's college years at Columbia.  In particular, I remember Betty, the fast paced, maternal waitress, greeting students as "honey," shouting out orders "cup-a-creamo" and using her own shorthand (BWICS, the Black-and-White-Ice-Cream-Soda, was one of my favorites).  The menu was inexpensive and filling and the camaraderie fantastic.  But I especially appreciated those days (most of them) when I was low on cash and ordered only  lentil soup and bread for dinner (35 cents, even in 1976) when she would quietly pass me extra bread and butter.  Thank you, Betty, I'll never forget your kindness.
