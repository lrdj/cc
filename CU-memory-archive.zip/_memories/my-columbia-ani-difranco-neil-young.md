---
title: 'My Columbia: Ani DiFranco, Neil Young'
author: Daniel Ng
tags:
- John Jay
- Dorm life
- Campus
- Academics
- Music
- Politics
- Activism
- Good trouble
- Relationships
layout: memory
schools:
  CC: 1994
primary_year: 1994
---
# Ani DiFranco, Neil Young

1.  A high school buddy came from out of town for a few days and saw posters on campus for an Ani DiFranco concert in Wollman Auditorium (may it rest in asbestos-abated peace).  Needless to say, having grown up on testosterone-fueled classic rock, I wasn't about to be dragged into a "chick's concert" where a folkie was going to strum feeble folk songs on her acoustic guitar.  After three hours of screaming, hollering, and shredded fingers (and a Prince cover!) I was an Ani fan for life.  It was probably the best live concert I've ever seen, even if it happened to be in FBH.

2.  A friend had just lent me a tape of Neil Young tracks in 1991 and the war broke out.  I remember looking out over Van Am Quad from my John Jay window as a parade of candles made its way to a massive Times Square sit-in protesting the Gulf War.  And as people started crying down the hall in the 13th floor lounge, I pressed Play on the tape player, and "Cortez the Killer" came on.  It was like a piece of me died as the bombs fell on Baghdad.  President Bush was addressing the country.  Neil Young sang, "What a killer."
