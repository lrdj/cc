---
title: 'My Columbia: Auditing'
author: Jay Lefer
layout: memory
schools:
  CC: 1951
primary_year: 1951
tags:
- Academics
---
# Auditing

Taking more points a semester than was necessary, there was no time or room for Prof. Joseph Wood Krutch's course. The literature course covered modern novels and writers. Somehow, I managed to get to his class without registering and discovered that I wasn't the only one. The back of the room was filled with "auditors." Prof. Krutch did not seem to mind. When he asked: "Did Joyce reflect the chaos in the world or did he help create it?" I was dumbfounded. The impact of the writer. The chaos that Prof. Krutch discussed in 1950 haunts us today. I did make way for Prof. Krutch's "Milton and Dryden" course. When I wrote the term paper "imitating" Milton's and Dryden's style and verse, Krutch was delighted.

It is difficult to name only one influence. Moses Hadas and Cebra Q. Graves remain with me. Working as a psychoanalyst, I find that my patients today can become protagonists in the classical Greek plays they discussed. The past enters the present.
