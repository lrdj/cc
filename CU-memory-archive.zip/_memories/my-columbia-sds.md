---
title: 'My Columbia: SDS'
author: Susan Levinkind
layout: memory
schools:
  LS: 1963
primary_year: 1963
tags:
- Politics
- Activism
- Good trouble
---
# SDS

It was during the Vietnam War, and I had been to marches against the War, but nothing was said at school. Then, one day, there was a table in the quad.  It was SDS (Students for a Democratic Society) with petitions, buttons and rants against the war. It was so exciting to see my politics reflected at school!

This was written about in "The Strawberry Statement," but their presence day after day was so inspiring that it gave me, a young married mother, the courage to increase my anti-war activism (despite my husband's ridicule) and to start on the path to where I am now, an "out" and political 65-year-old dyke.

Susan (Ritter) Levinkind
