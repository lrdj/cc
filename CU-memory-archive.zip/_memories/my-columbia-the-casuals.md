---
title: 'My Columbia: The Casuals'
author: Ross Bender
tags:
- Furnald Hall
- East Campus
- Columbia College
- Dorm life
- Campus
- Sports
- Athletics
- Music
layout: memory
schools:
  GSAS: 1980
primary_year: 1980
---
# The Casuals

The Casuals were a New Wave band c. 1980 who often performed in the crowded front room of that wacked-out fraternity on 114th St that kept having spectacular drug busts. Band members were all Columbia College undergraduates, though after all these years and through this cocaine haze I'm having a hard time remembering their names.

The lead singer and songwriter was a guy from Texas named Dave something who worked part-time with me in the Columbia Residence Halls office. There was a guy named Jesse who played synthesizer riffs that never seemed to have anything to do with the songs, if you could call them songs. After the Casuals disintegrated I believe he went out to Brooklyn to make space jazz or something with Bill Laswell.

Two of their hits which I recall distinctly were "Who Stole the Family Jewels?" and "Tokens of Love."

Oh, and there was a guy named Kevin Trainor who played guitar. I sort of distinctly remember him playing dobro with another band called "The Doobers" in the Furnald Hall lounge. Maybe it wasn't a dobro, but it may well have been. He had a sister known as "Sis" who worked with Under-Assistant Dean for Undergraduate Residence Roberta Spagnola, the glamorous one who wound up marrying the football coach. She was famous for announcing to the New York Times that the new East Campus had "rats as big as cats."

East Campus was the high rise dorm that went up in a hurry on Morningside Drive when the big housing crunch hit. No sooner had it been occupied than some dudes on the 20th floor tossed a sofa out onto the street. Columbia had a certain je-ne-sais-quoi kind of flair back in the day.
