---
title: 'My Columbia: Getting Snowed in at Columbia'
author: Joshua  Lennon
layout: memory
schools:
  SEAS: 2004
primary_year: 2004
tags:
- Winter
- Weather
- Academics
---
# Getting Snowed in at Columbia

Coming from Chicago, I was pleasantly surprised at the mildish winters in NY. It got cold, but not the bitter icy winds of the midwest. The best part was that when it actually snowed, the city was entirely unprepared to handle even a few inches. In Chicago, we wouldn't miss class unless there was a good foot of snow and the trucks couldn't plow. In NY, class was cancelled after the first big (4 in) snow of the year.
