---
title: 'My Columbia: Dozed Off'
author: Ralph Scott
tags:
- Butler Library
- Academics
- Library
- Study spots
layout: memory
schools:
  GS: 1968
  LS: 1970
primary_year: 1970
---
# Dozed Off

In the 1960s I worked in Special Collections in Butler Library. We had a room called the Papyrology and Epigraphy collection where we stored the ancient texts. One afternoon, we let in and locked inside the room a distinguished classics professor to do research. The plan was when he was ready to leave he would press a buzzer to summon the staff member to let him out of the locked room. When we locked up at 6PM we were supposed to check the room to see if it was clear. My colleague who was responsible for locking up that day forgot and went home at 6. The professor had dozed off only to awaken around midnight. He heard the night watchman making his rounds about 1 a.m. and pounded on the door to be let out to use the bathroom! The guard, for security reasons, DID NOT have a key to the room. The Head of Special Collections who lived in Northern New Jersey was summonded by the police to come to Butler Library to let the professor out to use the facilities. By this time it was around 3/4 a.m. The Department Head was not a happy camper when we arrived for work the next morning, having spent most of the rest of the early morning in the Chock Full O' Nuts waiting for the staff to show up for work!
