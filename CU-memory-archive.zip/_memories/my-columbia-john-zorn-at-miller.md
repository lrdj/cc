---
title: 'My Columbia: John Zorn at Miller'
author: George D Tsouris
tags:
- Miller Theatre
- Arts
- Culture
- Music
layout: memory
schools:
  GSAS: 2002
primary_year: 2002
---
# John Zorn at Miller

One of the coolest art experiences that I had while at Columbia was seeing John Zorn at Miller Theatre. I had heard some CDs of his, so I was ready to hear some far-out music, even though I wasn't familiar with any of the pieces that were being performed. The high point of the night was hearing his Masada quartet play live, which I had never heard before. After the show I went next door to Kim's and picked up three new cds.

This was my first experience at Miller Theatre, which I have to say is one of the most exciting and important theatres in New York City because of its focus on contemporary performing arts (which you can barely find at Lincoln Center).
