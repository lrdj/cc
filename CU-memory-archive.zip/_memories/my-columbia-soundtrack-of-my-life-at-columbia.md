---
title: 'My Columbia: Soundtrack of My Life at Columbia'
author: Daniel Kraft
layout: memory
schools:
  CC: 2004
primary_year: 2004
tags:
- Music
---
# Soundtrack of My Life at Columbia

The soundtrack of my Columbia experience was definitely country music, which is strange considering NYC doesn't have a single 24-hour country music radio station.  As an intern and then host of the 40s and 50s country music broadcast Honky-Tonkin', I listened to Hank every Tuesday night.
