---
title: 'My Columbia: Mario Salvadore'
author: keith plymale
layout: memory
schools:
  GSAPP: 1989
primary_year: 1989
tags:
- Academics
- Lectures
---
# Mario Salvadore

Mario Salvadore taught me to see the world differently: a transparent reality emerged, which is invisible to most. Salvadore taught a seminar called "Tower of Babel, or Why Buildings Stand Up."  It was a philosophical history course, in which we studied the theory as well as the physics of engineering.

The Tower of Babel problem resulted in an equation he invented, with which you can calculate the maximum height any material can be stacked vertically: concrete, glass, wood paper, steel, plastic, dirt....

Salvadore was also an avid mountain climber.  Altitude was always the goal: Making architecture fly.
