---
title: 'My Columbia: Stakes Is High to the Red Headed Stranger'
author: Karl Ward
tags:
- Carman Hall
- East Campus
- Miller Theatre
- Dorm life
- Campus
- Music
- Politics
- Activism
- Good trouble
layout: memory
schools:
  CC: 2001
primary_year: 2001
---
# Stakes Is High to the Red Headed Stranger

The first thing I heard when I stepped into my suite at Carman Hall was the album Stakes Is High by De La Soul.  The last thing I heard at Columbia, leaving my suite in East Campus, was the album Chopper City in the Ghetto by BG.  Somewhere in between, I went to see:

- Wyclef Jean at Hammerstein, with my whole Carman suite

- The Cure on Halloween 1997 at Irving Plaza

- Morrissey at Roseland

- The Beastie Boys in 1998 at Madison Square Garden (MCA got booed for protesting that day's bombing campaign in Iraq)

- live drum and bass at CBGB at 3AM on a weeknight

- live samba music at Sounds of Brazil

- the Freight Elevator Quartet, everywhere they played

- Outkast, before they went pop, on the Steps and at S.O.B.

- Sonic Youth on the Steps in the rain

- The Rite of Spring and Symphonie Fantastique at Carnegie Hall

- Cibo Matto, Sean Lennon, and Petra Haden at Bowery Ballroom

- Stereolab at Battery Park (rest in peace, Mary Hansen)

- Sebadoh at Irving Plaza

- De La Soul and Mos Def at Miller Theatre

- The Willie Nelson Fourth Of July Picnic in Luckenbach, Texas

I guess that last one might not really count.  I think it does though.
