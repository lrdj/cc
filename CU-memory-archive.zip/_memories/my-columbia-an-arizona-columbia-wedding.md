---
title: 'My Columbia: An Arizona Columbia Wedding'
author: Aylin Tashman
tags:
- John Jay
- Academics
- Relationships
layout: memory
schools:
  BUS: 2007
  SEAS: 2003
primary_year: 2007
---
# An Arizona Columbia Wedding

Several of my undergraduate friends, including people I lived with Freshman year in John Jay 15, will be attending my Phoenix wedding.  Guests include Veru Narula, Dimitri Christopolous and Rasheq Zarif.  I am currently a student at the business school, and two of my current classmates will also be there to celebrate my special day!  The greatest part is that my soon-to-be husband (our wedding is March 10th), is also a Columbia alum (P&S '99)!!  We will now have another great memory to add to our collection from our days as 18 year olds!
