---
title: 'My Columbia: Pediatric Dentistry Rules!!!'
author: Scott Bialik
layout: memory
schools:
  SDOS: 1994
primary_year: 1994
tags: []
---
# Pediatric Dentistry Rules!!!

Pediatric dentistry rules!!!
