---
title: 'My Columbia: Acorns and Tai Chi'
author: Noreen (Flanigan) Whysel
layout: memory
schools:
  CC: 1990
primary_year: 1990
tags:
- Campus
- Winter
- Weather
- Arts
- Culture
---
# Acorns and Tai Chi

I have a few Furnald stories.

I remember once making my bed late one morning and finding an acorn in the sheets.  Thinking nothing more than, "That's weird," I threw it out the window and shut the pane.  Later that winter, I woke to a light scratching noise.  I looked out the window and saw a squirrel scamper away.  Maybe he put the acorn there.

I also remember there was an elderly Chinese couple who did their morning exercises outside my window in the path in front of Journalism.  I rarely got up early enough, but when I did it was very peaceful to watch.  Not that it inspired me to do exercise of any kind.

How did I get a Furnald room my sophomore year?  Well, that year I had a really bad lottery number, and I was worried not just about getting a bad room, but getting no room at all.  By my Fall return to campus, I still had not received an assignment, and was beginning to wonder how a daily commute from Indiana would go, so I was thrilled to finally land a third floor, corner, campus-facing room in Furnald.  Imagine my dismay, as I opened the door to my new room and found it occupied.  Clothes in the closet.  Books lining the bookshelves.  An unmade bed.  Its resident absent.  My father and I went back to the housing dept to complain and within an hour, the room was cleared out.  I kept that room until Senior year.
