---
title: 'My Columbia: Oh, Do I Remember!'
author: joseph dorinson
tags:
- Columbia College
- Columbia College Fund
- Academics
- Politics
- Activism
- Good trouble
- Relationships
layout: memory
schools:
  CC: 1958
  GSAS: 1976
primary_year: 1976
---
# Oh, Do I Remember!

In 1968, Bernard W. Nussbaum - my distinguished classmate and dedicated donor to the Columbia College Fund - decided to run for political office. So, he mustered the shock troops, Ernie Brod and this correspondent to the cause, among other Class of '58 grads. He must have spent countless hours campaigning and at least $16,000 in a losing battle. There was only one winner: me. I met my wife, Eileen Levine, my Sea gate Queen, in the campaign. Now, almost 39 blissful years later, Bernie bemoans this losing effort - money, time, energy - just to marry off his old bachelor buddy from Stuyvesant High School, Unity House, and best of all: Columbia College. Inspired by "the mystic chords of memory," how can I forget?

- Joe Dorinson, '58
