---
title: 'My Columbia: Professor Rice'
author: Ann Kansfield
layout: memory
schools:
  CC: 1998
primary_year: 1998
tags:
- Academics
- Lectures
---
# Professor Rice

My Columbia education was a gift, especially having the opportunity to learn from Gene Rice.  Each class with Professor Rice expanded my world and demonstrated the power of his unique first-person research.  His lectures were perfectly crafted, totally original and followed the most beautiful arc.  At the end, he tied them up neatly and sent us on our way.  It was amazing.

Best of all, though, was seeing an emaritus professor who looked so good in a pair of Levis 501s.
