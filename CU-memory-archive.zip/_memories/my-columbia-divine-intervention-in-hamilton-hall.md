---
title: 'My Columbia: Divine Intervention in Hamilton Hall'
author: Leonard Levine
tags:
- Hamilton Hall
- Dorm life
- Campus
- Academics
layout: memory
schools:
  GSAS: 1976
  CC: 1970
primary_year: 1976
---
# Divine Intervention in Hamilton Hall

The construction of the International Affairs Building involved heavy blasting, which was supposed to be scheduled to coincide with intervals between classes. Frequently, the blasts came early. Given the religious and philosophical themes in CC and HUM, many a serious class discussion was ended with a blast from the sky and a chorus of tittering.
