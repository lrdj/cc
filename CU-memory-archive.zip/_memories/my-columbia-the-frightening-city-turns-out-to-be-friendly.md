---
title: 'My Columbia: The Frightening City Turns Out to Be Friendly'
author: Kristin Bell
layout: memory
schools:
  BC: 1995
primary_year: 1995
tags:
- Relationships
---
# The Frightening City Turns Out to Be Friendly

I will never forget the first day I arrived at Columbia. I had just flown in from the West Coast and had managed to traverse the airport and shove all of my stuff into a cab. I had never been to Columbia or New York before; I was alone and didn't know a single soul. I was arriving early for the Columbia Urban Experience group that I was lucky to be a part of. I had some kind of map, but didn't know where to get out of the cab!

I finally said to the cab driver "um, just stop here I guess." The cabbie dropped me off with all of my stuff, and I have to admit I began to sweat a little. There were no signs of the C.U.E. people...all I saw were two people playing tennis in the tennis court. I had way too much stuff to move it all by myself, so even though I was scared to death of the city and heard all sorts of horror stories, I left all of my belongings with the people playing tennis. "Can you watch this for me?" I asked. They gave me a puzzled look, but agreed. I walked around and finally found the other people with C.U.E. and one of the women there rushed back with me to get my stuff at the tennis court.

And YES, you should have no doubt that ALL of my stuff was fine, intact and well-cared for when I got back. Nobody stole my stuff. Even I was kind of surprised. Who goes to NYC for the first time and leaves all of their worldly possessions with strangers? Me. After that I was still scared to walk on the streets alone. I thought people always had to be in pairs or they would get mugged. I quickly realized that millions of people walked around the city alone and that I would be okay.

Anyway, even if you are some young, clueless, 18-year-old country bumpkin the city won't eat you up in one big gulp. Sometimes the world just isn't as scary as we make it out to be in our minds. All I can say is: Thank you New York for loving me!
