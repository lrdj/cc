---
title: 'My Columbia: My Roommate?  What Roommate?'
author: Joe Okon
tags:
- WKCR
- Dorm life
- Campus
layout: memory
schools:
  CC: 1969
primary_year: 1969
---
# My Roommate?  What Roommate?

My first semster living in a Columbia dorm was also the first time I'd ever had to share a room (other than bunking with my older brother at home as a kid). Naturally, before arriving on campus, I was a bit apprehensive about having to spend so much time with someone I'd never met before. No problem.  Andy was a nice guy, but I never really got to know him well. He seemed to spend nearly all his time at WKCR!
