---
title: 'My Columbia: The Chopped Liver Malted'
author: Harvey Leifert
tags:
- WKCR
- Hamilton Hall
- Dorm life
- Campus
layout: memory
schools:
  CC: 1959
  GSAS: 1961
primary_year: 1961
---
# The Chopped Liver Malted

When WKCR was located in Hamilton Hall Annex in the 1950s, there was a coffee shop across Amsterdam Avenue called Columbia Chemists. Every afternoon, the WKCR regulars would repair there for a cup of coffee and a cruller. We always ordered the same thing, but Dottie, the seen-it-all and unimpressed waitress, insisted that we actually state what we wanted each time.

One day, Hugo Birnmaum, '57CC (I think), asked Dottie for "the usual." "What do you want," she insisted, pencil poised. They went back and forth a few times until in exasperation, Hugo blurted out, "A chopped liver malted!" Dottie wrote it down and soon returned with our coffees and crullers, plus one chopped liver malted. It looked awful, but Hugo manfully downed every drop, or bite, of it. But from then on, he ordered "coffee and a cruller" without fuss, like the rest of us.
