---
title: 'My Columbia: Extended Winter Parking in NYC'
author: Robert Pitulej
layout: memory
schools:
  SIPA: 1996
primary_year: 1996
tags:
- Winter
- Weather
- Academics
---
# Extended Winter Parking in NYC

Every permanent and temporary New Yorker knows about the difficulty of finding parking in NYC - SIPA graduate students are no exception.  Having grown up in nearby New Jersey, I enjoyed the advantage of having my car parked outside my comfortable and quaint Columbia apartment on Amsterdam Avenue and 124th - overlooking the gargoyles of Teacher's College from my living room.  Walking to nearby classes was a joy, but moving my darn car to comply with NYC parking ordinances was a regular pain.  As luck would have it, the winter of 1995-1996 blanketed NYC with a wonderful snow cover. This wonderful and plentiful snow resulted in a suspension of alternate parking ordinances for almost two weeks - thereby increasing my quantity and quality of class preparation (a.k.a. morning sleep)...let it snow...let it snow...let it snow.
