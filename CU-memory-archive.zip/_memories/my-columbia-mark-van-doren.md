---
title: 'My Columbia: Mark Van Doren'
author: Stephen Sobel
layout: memory
schools:
  CC: 1954
primary_year: 1954
tags:
- Academics
- Lectures
---
# Mark Van Doren

Mark Van Doren was my humanities teacher.  One day in class, he asked a question and called on me.  I wasn't paying attention and asked him to repeat the question.  He then apologized to me for not making the class interesing enough for me to pay attention to his lecture.

Imagine a teacher apologizing to a student who was not paying attention to the class?  What a lesson this great teacher taught me, one that I still remember over 50 years later.
