---
title: 'My Columbia: What''s the Half-life of Knowledge?'
author: Robert Sheiman
tags:
- SEAS
layout: memory
schools:
  SEAS: 1980
  PS: 1985
primary_year: 1985
---
# What's the Half-life of Knowledge?

As a freshman I was told by one of my professors at SEAS: "You should only know as much as I've forgotten."  Here it is 25-plus years later, and I often say to myself: "I should only know as much as I've forgotten."
