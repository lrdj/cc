---
title: 'My Columbia: Hunan Heat in NYC'
author: Karen Anspach
layout: memory
schools:
  LS: 1971
primary_year: 1971
tags:
- Dorm life
- Campus
---
# Hunan Heat in NYC

Ah, the powers of the Dumplings in Red Hot Oil at the small, dark, rather dingy Hunan restaurant at the corner of 96th Street and Broadway! They'd call to my roommate and me late at night as we studied. The restaurant's hours met the needs of locals and students, and usually it was still open when we'd walk down from the dorm at 116th. Whatever the weather - freezing or sultry - my roommate would stop for an ice cream cone on the way if her ulcers were acting up. The intense pleasure of those dumplings was worth it; the sweat would bead on our foreheads as our chopsticks retrieved them from their small bowls. I never found them the same at any other restaurant. On a visit a few years later I learned it burnt down. Perhaps the dumplings...
