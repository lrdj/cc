---
title: 'My Columbia: DAVID WON''T READ HOWL'
author: Joseph Dobkin
layout: memory
schools:
  GS: 2007
primary_year: 2007
tags: []
---
# DAVID WON'T READ HOWL

David won't read Howl

But what does he know

He never piled up papers and spun

His head the way I do

He says he's gone this long without

Reading Howl, he's not just gonna

Pick it up

Don't worry girls

Don't sing about David till he

Wakes up and listens

The best minds of his generation

Have read Howl

The best minds of his generation

Are deep freezing in colleges and little towns and

Jumping off cliffs into water for

Why not

The best minds are out growing like flowers

If you want the truth

They're shedding their clothes in fountains

And riding their bikes in ferocious little circles

They're passing out full of painkillers and wine

They're passing out full of moonlight and

If you wake them they look at you gently

And add the final couplet to your day

Hurricanes

Explosions

The best minds of my generation

Are hurricanes and explosions

Are hiking in Tibet and actually

Been frozen there for years

They are teaching first grade

And ninth grade

And grades that have not yet been invented

The best minds will not read Howl the

Best souls have been Howling the whole time

But you can't hear them it's so damn noisy in this town
