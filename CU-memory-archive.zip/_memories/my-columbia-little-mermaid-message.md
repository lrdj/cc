---
title: 'My Columbia: "Little Mermaid Message"'
author: Frederic Schultz
layout: memory
schools:
  CC: 1990
primary_year: 1990
tags:
- Arts
- Culture
- Music
---
# "Little Mermaid Message"

Sorry to quote myself, but I did like my short simple introduction to my mom's message, which i sent to Jeff Rake, who sent it to ten people, who sent it to ten people, and so on and so on and so on...

My quote was, "Thought you'd get a kick out of this message from my mother..."

And you all did!!   And then the listeners on NPR's "This American Life" did, after Jonathan Goldstein's piece came out (to find it, look to thislife.org, then to 1/11/2002, "messages for someone"),  I hear that the NPR piece has gotten many students to apply to and go to Columbia, because they want to go to any school that is soo cool that it made the "Little Mermaid message" famous!!  So, I'm very happy to have helped admissions out!  And I'm sure my mother is too!  I'd ask her, but I can't find her.. She must be in La Jolla!!  G'BYE!!!!!  :P

Freddy

ps: u can c my blog, music, paintings, etc. at fantasyfreddy.com! L8   F

pps: the real beauty of that message was all of your responses to it!  So, mazel tov!!  u did a better job mimicking her than i ever could!!!  f
