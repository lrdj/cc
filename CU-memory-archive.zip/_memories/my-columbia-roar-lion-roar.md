---
title: 'My Columbia: Roar Lion Roar'
author: Mike  Griffin
tags:
- Hartley
- Dorm life
- Campus
- Academics
- Sports
- Athletics
layout: memory
schools:
  CC: 1965
primary_year: 1965
---
# Roar Lion Roar

Beyond question, my favorite day/night at Columbia was Saturday January 18, 1964.  I was a member of legendary coach Jack Rohan's first recruiting class and after playing freshmen basketball I moved up to the varsity as a sophomore and had a front row seat for all of the games as I played very little.  When graduation opened up a spot, I was able to secure a starting position as a junior as a power forward.  We were a guard-oriented team with talented scorers such as Neil Farber '65, Ken McCulloch '65, Stanley Felsinger '66 and Neil Farber '66.  Also playing basketball that year was perhaps the finest athlete ever to wear a Columbia uniform: Hall of Famer Archie Roberts '65, who was a great addition to our team (although his deserved fame came on the football and baseball fields). We got off to a good start and were 4-0 at one point, but any Columbia athlete knows that teams are measured by their success in Ivy competition.

Ivy League basketball begins in January, and on the 18th the Lions hosted Princeton and the best player in Ivy League hoop history, Bill Bradley.  At the end of the season Columbia was in the middle of the Ivy standings and Princeton was representing the League in the NCAA tournament, but on that frigid Saturday evening in front of a standing room only crowd in University Hall, the Lions prevailed 69-66.  My roommate, Ken McCulloch, sealed the win with six clutch-free throws in the last minute of the game. At the power forward position, Bradley tallied 36 points, and the poor stiff who had to guard him managed 3.

That could not have mattered less.

After the game, three of us took the train downtown, got off at 50th Street near the Old Madison Square Garden, entered a nondescript bar, and I drank the first two beers of my life. Really.

The best part of the story is that after taking the uptown train and making my way back to 223 Hartley Hall, I was up the rest of the night re-reading "A Doll's House" and other Ibsen works in preparation for my final exam on Monday morning, right there in University Hall. Roar Lion Roar.
