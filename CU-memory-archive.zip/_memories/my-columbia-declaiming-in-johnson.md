---
title: 'My Columbia: Declaiming in Johnson'
author: Lydia Fazio Theys
layout: memory
schools:
  GSAS: 1977
primary_year: 1977
tags:
- Dorm life
- Campus
- Academics
---
# Declaiming in Johnson

I remember well the day I moved into Johnson Hall (now Wien). It was a Sunday morning, one of those blue-sky days you just about never see in the city, and everything about the campus looked magnificent. My room was quite a surprise, a large single--I don't recall the floor--long and somewhat narrow, a tiny sink in one corner and a view of the park out my huge-for-a-dorm window.

As I recall, Johnson housed grad students and law students. Aside from the fuses blowing anytime anyone used a forbidden hairdryer or hotplate, one of my overwhelming memories of the dorm was of hearing my law neighbors practice speaking aloud in their rooms at night. I was a grad student in astronomy, and the notion of preparing for class on such a rigid schedule--and out loud!--flummoxed me, until I finally had to ask, "What on earth are you doing?"
