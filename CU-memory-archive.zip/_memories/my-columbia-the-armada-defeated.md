---
title: 'My Columbia: The Armada Defeated'
author: Donna Gilboa
layout: memory
schools:
  GSAS: 1956
primary_year: 1956
tags:
- Academics
- Lectures
---
# The Armada Defeated

Garrett Mattingly was a spell-binder who could keep history graduate students on the edge of their chairs while describing a story for which we all knew the ending.  When he finished the lecture, there was breathless silence and then - spontaneous applause.
