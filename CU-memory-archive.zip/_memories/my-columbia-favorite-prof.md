---
title: 'My Columbia: Favorite Prof'
author: Laura Adams
layout: memory
schools:
  CC: 1987
primary_year: 1987
tags:
- Academics
---
# Favorite Prof

This was a tough call (as I had many great profs), but my favorite professor was Edward Mendelson... who apparently is still in Columbia's Department of English and Comparative Literature.  Prof. Mendelson was sharp, funny, and taught me everything I know about Thomas Hardy, James Joyce, and Oscar Wilde.  I have gone on to become a professor, myself -- not in English, but in psychology.  I hope one day to develop a course concerning "Psychology & Literature," which will draw on my days as an English major in Prof Mendelson's "Modern British Literature" class!
