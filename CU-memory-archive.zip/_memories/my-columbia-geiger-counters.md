---
title: 'My Columbia: Geiger Counters'
author: Ian Tattenbaum
tags:
- Carman Hall
- Dorm life
- Campus
layout: memory
schools:
  CC: 1990
primary_year: 1990
---
# Geiger Counters

One moment from my four years in the Columbia dormitories that I will never forget was during my freshman year (1986-1987 academic year). Campus security, who had discovered that radioactive material had been stolen from the physics department, showed up with geiger counter-carrying FBI agents to search Carman Hall for the stolen contraband just as I was returning to the dorm after dinner. Apparently, the agents found the radioactive material (a dorm mate had been hiding it in his dorm room (which was thankfully number of floors above where I was living)) and the dorm mate was promptly expelled, never to be heard from (at least by me) to this day.
