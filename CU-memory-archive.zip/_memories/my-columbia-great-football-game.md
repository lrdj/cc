---
title: 'My Columbia: Great Football Game'
author: Joseph Kennedy
layout: memory
schools:
  CC: 1948
primary_year: 1948
tags:
- Sports
- Athletics
- Relationships
---
# Great Football Game

My father and family went to every football game for years and years. A very good friend of Lou Little, my dad was swimming coach at Columbia. Dad never sat in his seats on the 50-yard line but preferred the far end of the stadium, so, the year in question, my new wife and I sat in the seats on the 50 and right in front of us was one of my favorite professors, Dwight Minor, who taught C.C.

Gene Rossides was the quarterback, Lou Kusserow the fullback, and the great Bill  Swiacki played end. Well, Army (our opponent) possessed a 47-game winning streak at that time and were prohibitive favorites, but in the 4th quarter with little time left, Gene cut one loose and Swiacki made a sensational grab in a horizontal position in the endzone for the winner.

Dr. Minor and I started slapping and hugging each other as though we were both of equal stature...it was just great!!!!!!

Joe Kennedy(48C)
