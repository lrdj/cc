---
title: 'My Columbia: Slow Is Smooth. Smooth Is Fast.'
author: Christopher  Sheridan
layout: memory
schools:
  GS: 1990
primary_year: 1990
tags: []
---
# Slow Is Smooth. Smooth Is Fast.

Seventeen years ago, I wish I could have told myself:  "Slow is Smooth. Smooth is Fast." I have had the the Big, High-Profile jobs in New York; I commanded Special Forces Soldiers in combat in Afghanistan; and I am now a father of a little girl.  It was under the tutelage of a very experienced Special Forces Soldier that I learned the above and how it applies to everything in my life. I am thankful that I can now pass this on to my daughter Isabelle.
