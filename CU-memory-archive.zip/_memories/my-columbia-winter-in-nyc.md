---
title: 'My Columbia: Winter in NYC'
author: Howard Miller
layout: memory
schools:
  JRN: 1981
primary_year: 1981
tags:
- Winter
- Weather
- Arts
- Culture
---
# Winter in NYC

My home city, Louisville, while being in the state of Kentucky, is not a part of the "sunny south."  However, I was somewhat concerned about spending the winter of 1980-81 in New York City.  I had visions of six-foot snowdrifts and artic winds freezing me to the bone during my stay in persuit of my master's degree.  Much to my suprise, that winter was even milder than what I was used to in Louisville.  It only snowed once, and that was just flurries, while the temperatures were quite manageable for me.  I'm pretty sure that was an unusually mild winter for NYC, but I was certainly glad it happened while I was at Columbia.

Howard Miller, J, '81
