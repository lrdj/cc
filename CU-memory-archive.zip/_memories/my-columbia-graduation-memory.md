---
title: 'My Columbia: Graduation Memory'
author: Franklin Mirer
layout: memory
schools:
  CC: 1966
primary_year: 1966
tags:
- Library
- Study spots
- Arts
- Culture
---
# Graduation Memory

After my ceremony, we went somewhere to get the envelope with our diplomas.  When I opened mine, there was no diploma, only a bill for a library fine.  For a book I had returned and for which I had paid the fine!  My parents paid the fine again so we could go home with a diploma.
