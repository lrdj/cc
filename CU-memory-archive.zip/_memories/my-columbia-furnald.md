---
title: 'My Columbia: Furnald'
author: James  Minter
layout: memory
schools:
  GSAS: 1974
  CC: 1973
primary_year: 1974
tags:
- Campus
- Religion
- Spirituality
---
# Furnald

Lots of events and people made my three years in Furnald so memorable, but to many of us who lived there it beat anywhere else on campus because of a grand old Columbia figure named Ben Jerman. Ben spent the last several decades of his long tenure at Columbia working in the Furnald mail room, but to us he was a welcoming and avuncular neighbor. In Roman religion there was something called a "genius loci," the guardian spirit of a place, and for us in Furnald that was Ben.
