---
title: 'My Columbia: full circle'
author: lawrence mumm
layout: memory
schools:
  CC: 1976
primary_year: 1976
tags:
- Academics
- Lectures
- Politics
- Activism
- Good trouble
- Relationships
---
# full circle

on a warm, sunny day, classes over, would sit on the sun dial and wait.  and friends would walk by and sit and accumulate.  and in the pre-cell phone/answering machine days, it was the best way to line up the players for the thursday night poker game.

fast forward, sunday night, april 1984, eating a momma joys sandwich on the sun dial.  my wife's water had broken, she wasn't yet in labor, and time to kill before i went back to st. lukes and waited for the delivery of who turned out to be andy.

fast forward, it's august 2002, parent's orientation lectures/busy time is over, sitting on the sun dial, drinking an iced latte from starbucks.  waiting for andy to free up and say goodbye to a new columbia freshman.

soon forward, it will be may 2006, and i expect i won't be sitting too far from the sun dial, watching andy graduate.

and the funny thing is when i sit there, i still half expect to see my friends sauntering over.
