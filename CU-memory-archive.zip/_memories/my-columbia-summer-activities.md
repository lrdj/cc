---
title: 'My Columbia: Summer Activities'
author: Paul Frommer
layout: memory
schools:
  CC: 1957
primary_year: 1957
tags:
- Food
- Dining
---
# Summer Activities

Each of my three college summers were primarily spent on "cruise" as a Regular NROTC midshipman. When the "cruise" was over I joined my brothers (Herbert, '54C and Alan, '57C) at a hotel in the Berkshire Mountains of Massachusetts to work as a waiter to earn money for the next school year's expenses (like food). Not an intellectual pursuit but necessary work.
