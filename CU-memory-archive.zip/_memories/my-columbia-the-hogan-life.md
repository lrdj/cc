---
title: 'My Columbia: The Hogan Life'
author: Marcos Rohena-Madrazo
layout: memory
schools:
  CC: 2002
primary_year: 2002
tags:
- Dorm life
- Campus
- Library
- Study spots
- Relationships
---
# The Hogan Life

I was studying in Russia when I got the news that I and my friends had managed to snatch a suite in Hogan Hall.  Ah Hogan, the King of Dorms and lucky Seniors' pride!  My own room in a suite, a tub, a full kitchen, and even a dishwasher to feed our senioritis sloth -- it was great!  It was the noble home to us and to our multiple parties.  The Three Suite Blowout was by far the most well-attended campus festivity I had ever been witness to.  The front desk was so crowded with people signing in that the subsequent partygoers could just walk through without even waving at the guard only to find a serpentine queue leading to the elevator.  When people finally reached the 6th floor all three suites (not to mention the hallway between them) were full to the brim with Columbians.  Hey, where else could they partake of the pleasures of the Mixed Drink Suite, the Sangria Suite, and let's not forget the powerful Jell-o Shot Suite!  That was no doubt the best celebration I had ever attended in my four years with Alma.  Ah, Hogan, long live the King!
