---
title: 'My Columbia: My Spiritual Pilgrimage at Columbia'
author: Ellis Deibler
layout: memory
schools:
  SEAS: 1951
primary_year: 1951
tags:
- Spirituality
- Religion
- Academics
- Lectures
- Relationships
---
# My Spiritual Pilgrimage at Columbia

I was a fairly nominal Christian when I entered Columbia. During my second year, another engineering student, having heard via the grapevine that I was supposedly a Christian, invited me to his room each night at 10:30 for time of prayer. I joined them, and then started attending the Columbia Christian Fellowship meetings each week. My spiritual commitment and involvement grew by leaps and bounds. But I still planned to be a chemical engineer after graduation - until, in my third year, I failed thermodynamics. I made up the course, got an 'A', but concluded God was telling me something. So after graduation, feeling I was still pretty weak spiritually, I attended seminary. Eventually I got into Bible translation, and have had a fabulous life since then, doing translation, checking translation, and/or teaching translation principles, in nineteen countries.
