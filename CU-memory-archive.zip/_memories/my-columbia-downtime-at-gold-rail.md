---
title: 'My Columbia: Downtime at Gold Rail'
author: Paul Becker
layout: memory
schools:
  SEAS: 1970
primary_year: 1970
tags:
- Food
- Dining
- Politics
- Activism
- Good trouble
---
# Downtime at Gold Rail

Much of my downtime was spent at the Gold Rail bar on the east side of Broadway at about 112th St. They were famous for inexpensive (much less than the more famous West End on the west side of Broadway) food and drink, especially huge burgers and pitchers of beer. I remember the celebration there in 1969 when Marty Domres was drafted as quarterback by the Baltimore Colts.
