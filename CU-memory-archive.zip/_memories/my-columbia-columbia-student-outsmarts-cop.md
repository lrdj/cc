---
title: 'My Columbia: Columbia Student Outsmarts Cop'
author: David Molko
layout: memory
schools:
  CC: 2004
primary_year: 2004
tags: []
---
# Columbia Student Outsmarts Cop

Conversation on late October night outside Alpha Delta Phi brownstone on 114th St., between fraternity member and NYPD officer:

Cop: We've been getting noise complaints from neighbors about the band playing upstairs. It's time for you guys to shut the party down.

Member: OK. We're keeping the volume turned down as much as we can. The party's officially registered with the University. Security says we can go until 2AM.

Cop: You're out of luck. It's 2:06 AM. Go pull the plug.

Member: Nuh-uh..(smiles). It's daylight savings! It's only 1:06!

Cop wrinkles his brow, obviously frustrated, climbs into his squad unit with his partner, and drives away.

Member returns to house and turns up the amp volume.
