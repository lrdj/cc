---
title: 'My Columbia: We Did Have Music!'
author: John T Herbert
tags:
- Ferris Booth
- Dorm life
- Campus
- Music
layout: memory
schools:
  PS: 1973
  CC: 1969
primary_year: 1973
---
# We Did Have Music!

When I started Columbia in 1965, there was an abundance of local musical talent, both on and off campus.  Folk stuff had been popular and "The Walkers" were the hottest rock band in Ferris Booth Hall.  The Lenox Lounge, the Apollo, and other places had great jazz and R&B, but it was not until the advent of "The Soul Syndicate" that the African American musical presence was really felt on campus.

I am proud to have played guitar in that 15 piece group for the "Dean's Drag" and other events on the Columbia campus and elsewhere.  Real music, real people, and really good times were all the rage 1967-1969!!  Thanks to all those who supported us back then, and a very special thank you to Omega Psi Phi Fraternity, Inc. for blazing the trails.

John T. Herbert
