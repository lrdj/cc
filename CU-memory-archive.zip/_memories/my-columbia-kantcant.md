---
title: 'My Columbia: Kant/Can''t'
author: Diana  Jividen
layout: memory
schools:
  GS: 1975
primary_year: 1975
tags:
- Academics
---
# Kant/Can't

This is not a student comment, but a funny professor comment.

I was in philosophy class, and we were discussing Kant.  The professor said, "Kant says you can't."  Then he stopped a moment and added, "Or Can't says you Kant." This caused an uproar of laughter, and I have never forgotten Kant (or can't).
