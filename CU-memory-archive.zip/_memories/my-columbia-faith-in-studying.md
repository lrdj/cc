---
title: 'My Columbia: Faith in studying'
author: Kara Shackett
layout: memory
schools:
  SW: 2002
primary_year: 2002
tags:
- Spirituality
- Religion
- Library
- Study spots
- Politics
- Activism
- Good trouble
- Relationships
---
# Faith in studying

I identify as Protestant and was very happy to find an event entitled GradPraise during my first week at Columbia.  GradPraise turned out to be a meeting that occurred each semester and involved students from all of the graduate schools.  It was a very important social event for me; I met someone at the first event who is a close friend to this day!  I got involved in helping to plan it during the following year and asked my close friend to speak.  She gave a brilliant speech on completing an Ivy league degree without God (undergraduate) and the difference it made to have God in her life for graduate school.  It was truly inspiring for all of us to hear how we could let anxiety go and use our newfound peace to get through the hectic pace that is graduate school.  Years later, my friend is a pastor and I recall that first sermon she ever gave at Columbia as an indication of her future success as a spiritual advisor and speaker.
