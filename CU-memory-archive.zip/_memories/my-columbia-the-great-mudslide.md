---
title: 'My Columbia: The Great Mudslide'
author: joseph graif
tags:
- Hartley
- Wallach
- Sports
- Athletics
layout: memory
schools:
  BUS: 1978
  CC: 1976
primary_year: 1978
---
# The Great Mudslide

One late night during the spring of 1975, right in the middle of final exams, a substantial spring shower turned a section of the quad used for touch football and frisbee into a field of mud. Such is the stuff that gives birth to inspired events.

As the first undergrad, clad only in briefs, went running at full speed toward the mud, screaming at the top of his lungs, culminating this demonstration with a slide of nearly 50 feet, the rest of us looked out of our windows in Wallach, Hartley, and Jay and thought, "Oh, yeah!"

Within five minutes, no less than fifty people were lined up, ready to take a running start and slide their way into columbiana. Some chose to remain indoors, sitting in the elevator lobby of their floor watching the doors open periodically to reveal two or three "sliders" covered from head to toe in coffee-colored mud.

The next morning, we were all tired, but our skin was suprisingly smooth and supple.
