---
title: 'My Columbia: Anybody Wanna Work in Europe?'
author: Thomas W. Lippman
tags:
- Spectator
layout: memory
schools:
  CC: 1961
primary_year: 1961
---
# Anybody Wanna Work in Europe?

I was sitting in the Daily Spectator office when a student I didn't know stuck his head in and asked,"Anybody here wanna work in Europe next summer?"  The idea hadn't occurred to me -- no one in my family had ever been out of the country except to Montreal -- but why not? I raised my hand, and I was in. the next summer, The Association Internationale des Etudiants in sciences  Economique et Commerciales sent me to Brussels as an intern. I worked for a cement company, of all things, but what I really learned was how to speak colloquial French (important for a French major, which I was) and how to drink white wine at lunch.  That was the opening for a journalistic career in which I reported from more than 50 countries!

Tom Lippman '61 cc
