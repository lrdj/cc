---
title: 'My Columbia: Commuting at High Speed'
author: Lawrence  [Larry] Ross
tags:
- Varsity Show
- Hamilton Hall
- Dorm life
- Campus
- Academics
- Lectures
layout: memory
schools:
  CC: 1945
primary_year: 1945
---
# Commuting at High Speed

The dorms were full of midshipmen and v-12ers, and I  lived in Hempstead, whence I commuted every day, running for the 7:20 train on the LIRR, then fighting my way into the B'way train that took me to the 116th St. station at Columbia.  This required a change at 96th St.  Carrying 18-19 credits during that accelerated program and being involved with the Columbian, Jester, the debating society and Varsity show  (to prove that I was "well rounded" for medical school applications),  I was running on about 4-5 hrs of sleep in bed...with involuntary naps on the trains.

Due for a 9 o'clock class in solid geometry on the 5th floor of Hamilton (elevators verboten!) I awoke at 116th St. in time to jump out of the train...but when I came out of  the station, I discovered that I was in Harlem at the foot of Morningside Heights with about 5 minutes to get to class.

After an exhausting run to the cliff and up the steps, and a 3 block run to Hamilton Hall, I had to climb the 4 flights to class where I arrived somewhat late and disoriented regarding the lecture.

That was the last time I slept through the change of subway trains!
