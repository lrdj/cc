---
title: 'My Columbia: West End Bar & Grill'
author: Arthur Delmhorst
tags:
- The West End
layout: memory
schools:
  CC: 1960
  JRN: 1964
primary_year: 1964
---
# West End Bar & Grill

There have been many memories in the New York Times this week [April 2006] about the West End Bar & Grill.

There was an annual rite that deserves note. At the end of each Lightweight Crew season in the 1950's and 1960's, the crew would have an annual "break training dinner." Since the heavyweights still had one more race after final exams, they could not celebrate with the lightweights. The need was to get all sixty or so varsity, JV, and freshman to arrive on time. So, the plan was to meet first at the West End. The first oarsman there would buy himself a beer. The second oarsman to arrive would buy himself a beer PLUS one for the person who got there first. The third to arrive would buy himself a beer plus TWO for those who arrived before him. And so on.

This accomplished two goals: 1) no one was late and 2} everyone was well lubricated for the dinner that followed!

In fact, few team members ever had to buy more than three beers, because everyone arrived almost simultaneously and that made for a sufficient supply.

With the drinking age now at 21 (it was 18 back then) and the redesigned West End, I wonder if this tradition has disappeared.
