---
title: 'My Columbia: Columbia Graffiti, 1966'
author: Jim Parker
layout: memory
schools:
  SEAS: 1969
primary_year: 1969
tags:
- Library
- Study spots
---
# Columbia Graffiti, 1966

Graffiti found on Columbia study desks (circa 1966):

Liszt was a beast but Nietzsche was peachy.

Immanuel Kant but Genghis Khan.

Time flies like an arrow but fruit flies like a banana.
