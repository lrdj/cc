---
title: 'My Columbia: A Civilian Freshman in Hartley Hall (June 1944)'
author: Robert Knapp
tags:
- Hartley
- Columbia College
- Dorm life
- Campus
- Academics
- Lectures
layout: memory
schools:
  CC: 1949
primary_year: 1949
---
# A Civilian Freshman in Hartley Hall (June 1944)

Graduating high school in early June 1944, I entered Columbia College to begin my freshman year the 2nd week of June. 

We freshman were on the fourth floor of the dorm, and the navy ROTC had the first three floors. Every morning at 6:30 a.m., these 90-day wonders would march in the quad in front of Hamilton singing, "It was sad when the great ship went down." 

Columbia graduated more Ensigns than Annapolis. 

In July, the Navy took over the whole dorm and we moved to the top floor of the dorm for the Union Theological Seminary. In August of 1944, I joined the army and left Columbia, to return in 1946.
