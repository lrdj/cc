---
title: 'My Columbia: Bad Poetry Contest'
author: Pooja Agarwal
layout: memory
schools:
  CC: 2002
primary_year: 2002
tags: []
---
# Bad Poetry Contest

I don't remember who wrote it, but it always made me laugh when I saw the posters for the Bad Poetry Contest with the previous year's winning poem. I can't remember the title, but it was probably something like "Ballad of Electra":

Clytemnestra, you killed my dad

Bad bad bad bad bad bad bad.
