---
title: 'My Columbia: How I Kept Warm'
author: David Kenner
tags:
- Ruggles
- Dorm life
- Campus
- Winter
- Weather
- Politics
- Activism
- Good trouble
layout: memory
schools:
  LAW: 1983
primary_year: 1983
---
# How I Kept Warm

During my first year at Columbia I lived in Ruggles Hall.  The main steam pipe went right through my room.  It was so warm that I had to keep the window cracked open all winter long.  When the steam started up each time during the night it sounded like a jackhammer was in my room.  I left Ruggles after my first year for Watt Hall--it was a pleasant improvement.

David Kenner
