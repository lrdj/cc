---
title: 'My Columbia: Starving Artist'
author: Linda Setlech
layout: memory
schools:
  GS: 1977
primary_year: 1977
tags:
- Arts
- Culture
---
# Starving Artist

I expected to graduate in December 1976, but was called into the Assistant Dean's office. "The Regents are not going to change the rules for you, do you understand?" "What is he talking about," I thought, sitting quietly across from his desk. I had been attending Columbia since 1969 and often wondered what a nice girl (like me) from Peoria, IL was doing in a place like this. "You need 124 hours to graduate; you only have 123 and have to attend one more semester." The Assistant Dean tossed the catalogue to me. "Take any course you want, because you have satisfied all the requirements. What's it going to be?" I tossed the catalogue back to the Assistant Dean. "I'm not looking in that catalogue one more time." The Assistant Dean bent his head over the catalogue, flipped through the pages, and suddenly looked up. "What about oil painting?" I thought for a second and said yes - I'd sign up for that. I graduated in May 1977 and have been painting ever since.  Maybe in 2007 I will make my first sale.
