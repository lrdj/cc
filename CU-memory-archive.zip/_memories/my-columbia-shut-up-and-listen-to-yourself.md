---
title: 'My Columbia: Shut Up and Listen to Yourself'
author: josua estrin
layout: memory
schools:
  SW: 2000
primary_year: 2000
tags:
- Academics
- Arts
- Culture
---
# Shut Up and Listen to Yourself

With an MS in Clinical Therapy, many might think I have strayed from the path.  With a series of Anti-Self help books (Shut Up! And Listen To Yourself, Vinnings Press), I have been called the Anti-Dr. Phil, Anti-Expert and also a pop culture guru.

All great for the ego. But the core values of the School of Social Work and the Columbia reputation have offered me the chance to take what I learened and do what CU has always encouraged. Make success stick by being a leader rather than a follower.

Thank you for the springboard, and watch for me on The Today Show and Ellen. I am taking on the world with my message of hope and hope to encourage others to "tread LOUDLY and leave the stick at home."
