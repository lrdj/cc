---
title: 'My Columbia: Great Mind'
author: Richard Trotter
layout: memory
schools:
  GS: 1965
primary_year: 1965
tags:
- Arts
- Culture
---
# Great Mind

In your My Columbia section, you asked what book, read while I was at Columbia, had the most influence on me. When I read Plato's Republic (the dicourse on Justice), I realised I was in contact with one of the great minds of all time. That is what a liberal arts education is all about.
