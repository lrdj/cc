---
title: 'My Columbia: Freshman Year 1968'
author: Arthur Mehmel
tags:
- Hartley
- Dorm life
- Campus
- Relationships
layout: memory
schools:
  CC: 1972
  BUS: 1976
primary_year: 1976
---
# Freshman Year 1968

We formed a terrific group of friends in Hartley Hall in 1968, a time when we slept on bunk beds, doors had to be open when a girl was in the room, and the hallway floors were uncarpeted tiles.

One night, we got the bright idea to wet down the long hallway with soapy water.  We ran and slid, like surfing, as far as we could.  The winner slid so far that his lead arm went through the glass door at the end of the hallway.  We spent the rest of that night at St Luke's Hospital getting stitches.
