---
title: 'My Columbia: Beautiful Site'
author: janet averill
tags:
- Low Library
- Commencement
- Campus
- Library
- Study spots
layout: memory
schools:
  GSAPP: 1990
primary_year: 1990
---
# Beautiful Site

Although many of the gardens on campus are lovely throughout the year, my family and I especially appreciate the beds of Columbia Blue iris that bloom just once each year around the base of Low Library.

A long forgotten gift to us, unnoticed and unassuming  for three seasons, the irises chose the perfect time to show off and  bloom  profusely: each Spring precisely at Columbia Commencement Day!
