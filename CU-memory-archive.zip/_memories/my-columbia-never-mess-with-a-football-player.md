---
title: 'My Columbia: Never Mess with a Football Player'
author: Richard J. Roth
tags:
- Ferris Booth
- Dorm life
- Campus
- Sports
- Athletics
layout: memory
schools:
  CC: 1962
primary_year: 1962
---
# Never Mess with a Football Player

In my Sophomore year, I was assigned to Ferris Booth Hall. My next door neighbor was a member of the football team and quite large. Ferris Booth was still being renovated, and there were holes in the walls between rooms. At one point, someone in my room decided to call my next door neighbor various names such as "dumb jock," which got him quite upset, and he proceeded to bang on my door. Luckily, cooler heads prevailed or I would not be alive to tell this tale.
