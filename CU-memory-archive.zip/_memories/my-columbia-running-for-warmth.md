---
title: 'My Columbia: Running for Warmth'
author: Marc McCann
layout: memory
schools:
  CC: 1988
primary_year: 1988
tags:
- Dorm life
- Campus
- Winter
- Weather
- Politics
- Activism
- Good trouble
---
# Running for Warmth

Coming to Columbia from Cleveland in 1984, I was pleasantly surprised to find the temperature relatively balmy in New York, with the buildings trapping heat and generally knocking down the wind.  So after growing up on the shores of Lake Eerie, with its icy winds and lake-effect snows, I enjoyed the higher New York City temperatures, and enjoyed a sense of being pretty warm.

And when the temperature really was cold, our heavyweight crew coach, Joe "Okie" O'Connor, stepped in to help with his brilliant workouts:  run to the boathouse from campus (5 miles, up the Henry Hudson Parkway during construction to 218th Street), run the track in the gym; run the stairs in Altschul Hall (up one flight, then down; up two flights, then down....all the way to the 13th floor).  And those were just the workouts prior to and after getting on the water.  Thanks Okie!
