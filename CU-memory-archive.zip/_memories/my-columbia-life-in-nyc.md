---
title: 'My Columbia: Life in NYC'
author: Harold  Rosenholtz
tags:
- Butler Library
- Library
- Study spots
layout: memory
schools:
  GSAS: 1969
primary_year: 1969
---
# Life in NYC

Sometime in the fall of 1969 during my graduate school attendance at GSAS, I came across graffiti scrawled in the men's room of Butler Library pleading "Free the New York 8 million." As a lifelong resident of the city  contending with all sorts of difficulties, the sentiments expressed have resonated for years, reinforcing the author's appeal.
