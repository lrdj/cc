---
title: 'My Columbia: A Season in Ruggles'
author: Ross Bender
tags:
- John Jay
- Ruggles
- Butler Library
- Dorm life
- Campus
- Library
- Study spots
- Arts
- Culture
layout: memory
schools:
  GSAS: 1980
primary_year: 1980
---
# A Season in Ruggles

I arrived at Columbia in September of 1971. My room was in Ruggles Hall, behind John Jay Hall, across 114th St. from Butler Library. I had contracted for the cheapest room available. It was 9 feet long and 6 feet wide. To the right as I entered was the bed, which took up the right side of the room. There was a narrow passage of about two feet, and on the left a desk, dresser and sink. It was a perfect cell for a medieval monk.

Across the hall was a fellow Canadian and raving lunatic named Allan Megill. He would periodically emerge from his sanctum ranting "I love my thesis! I love my thesis!" He was studying the origins of language under Jacques Barzun and volubly worshipped the ground his advisor walked upon.

Once he fell ill from the flu and I took in a copy of "The Code of the Woosters" by P.G. Wodehouse to cheer him up. Ten minutes later he came raging out of his sickbed, threw the book at me and announced, "I don't need this frivolous crap!"
