---
title: 'My Columbia: Relaxing on Sunday Mornings'
author: Bob Schaffer-Neitz
layout: memory
schools:
  CC: 1993
primary_year: 1993
tags:
- Campus
- Politics
- Activism
- Good trouble
- Relationships
---
# Relaxing on Sunday Mornings

My favorite place to relax at Columbia was on Low steps.  My wife (she is now anyway), Rebecca ('93) and I would go to Columbia Bagels on Sunday mornings and ask "What's hot?"  The employees would put their hands over each basket in turn and call out the varieties that were warm.  We'd pick warm bagels with lox spread and get coffee, then head back to campus, where most of the students weren't out and about yet.  We'd find a spot on Low steps and eat our breakfast together while watching graduate students' children playing around the fountains and (usually) an elderly man doing tai chi.  During those times the campus seemed so serene and bucolic that we could almost forget that we were at 116th and Broadway.
