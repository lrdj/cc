---
title: 'My Columbia: Experimental Art at Prentis Hall'
author: Jesse Sanford
layout: memory
schools:
  CC: 1995
primary_year: 1995
tags:
- Dorm life
- Campus
- Academics
- Arts
- Culture
- Music
---
# Experimental Art at Prentis Hall

One memory sticks out beyond others in my Columbia experience: a series of crazed, semi-unofficial parties in Prentis Hall on 125th St.  Home to Columbia's world-class computer music center as well as the industrial sculpture studios, these parties were filled with bizarre installations.  Each artist would take a different room, fill it with goo, create a maze or install actors.  An experimental music troupe even performed in the freight elevator!  The partial autonomy of certain marginal spaces in university environments is a precious resource.  After all, we don't want everything too sanitized!
