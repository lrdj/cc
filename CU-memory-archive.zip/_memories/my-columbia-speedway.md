---
title: 'My Columbia: Speedway'
author: Carl David Birman
layout: memory
schools:
  CC: 1983
primary_year: 1983
tags:
- Campus
---
# Speedway

During my junior and senior years, I resided at the College Residence Hotel on West 110th Street with several other College men. The apartment was close enough to campus to enable us to enjoy Columbia life, but we also felt very lucky to be living off-campus with so much privacy and freedom.

My roommates and I rescued a cat from the streets. He was extremely wild and hard to tame. He ran from one end of the apartment to the other like a bolt of light, so we named him "Speedway."

One time Speedway escaped from the apartment and disappeared for almost a week. I discovered him in the building basement, trembling and hiding behind some pillars, covered in soot and dirt. I cleaned him up and brought him back upstairs. Eventually, however, I believe that Speedway escaped for good, and I never saw or heard about him again.

Since that time, I have known and lived with many cats, but none was so wild, and I never got scratched as much as I did from poor crazy Speedway.
