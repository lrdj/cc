---
title: 'My Columbia: Support in the Big City'
author: Mary Sue Hunia
layout: memory
schools:
  NRS: 1970
primary_year: 1970
tags:
- Winter
- Weather
- Relationships
---
# Support in the Big City

When I arrived at Columbia I was a 20 year old from a dairy farm in Western Pennsylvania.  The Lutheran student organization provided me with friends with interests apart from the medical center.  It also afforded me the opportunity to get out of the city and experience unique events like a winter weekend near Sing Sing in Ossining.  For a young woman with little money or time this student service provided much valuable support.
