---
title: 'My Columbia: A Student''s Story'
author: John Handley
layout: memory
schools:
  CC: 1951
primary_year: 1951
tags:
- Spirituality
- Religion
- Academics
---
# A Student's Story

My first year in a CC class upset my applecart. Catechism instruction did not prepare me for the daily debates. Occasionally I made a point. The one I remember is "omission  can be as much  an offense against virtue and honesty as commission!" But I had my doubts about Catholicism and Christianity. I explored alternatives. There were misadventures. My best results came when adhering to virtue and honesty guidelines.

Mortality risks confirmed my experience.  First a tour in Korea, then flying for the Navy confirmed my need for a spiritual beacon. Then searching for alternatives to Christian principles led me back to Catholicism. I became ecumenical about what beacons others chose. Chatolicism became a best choice way to follow my spiritual beacon. I hope to share this faith with others.
