---
title: 'My Columbia: Post World War ll Years'
author: Stan Edelman
tags:
- Columbia College
- Academics
- Politics
- Activism
- Good trouble
layout: memory
schools:
  CC: 1949
  PS: 1953
primary_year: 1953
---
# Post World War ll Years

Dear Editor,

I entered Columbia College in February 1946 as one of many World War ll combat veterans. The G. I. Bill of Rights paid for most of my tuition, thank goodness. I also earned some extra money working as a waiter in the Catskill Mountains resorts (such as Kutchers Country Club).

I also worked on the holidays at the Post Office Building in Brooklyn, on weekends at Gimbels Dept. Store, and sold Encyclopedia Brittanica.

At the Columbia College of P & S, I worked in the kitchen, worked as a night technician at Presbyterian Hospital, received the Joseph Collins Foundation Scholarship, the William Rappeleye Columbia P & S Scholarship, and the N. Y. State War Veterans Scholarship.

I am very grateful for the above assistance, which literally changed  my life. Because of these gifts, I have set up my own scholarship at the College via the Henry Nias Foundation.  My medical school class has donated scholarships to the Columbia College of P & S, and I have set up a teaching professorship at the Medical School.
