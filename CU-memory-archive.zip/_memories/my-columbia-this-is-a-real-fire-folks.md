---
title: 'My Columbia: This Is a Real Fire, Folks'
author: Nat Heiner
tags:
- Furnald Hall
- Dorm life
- Campus
layout: memory
schools:
  CC: 1972
  GSAS: 1974
primary_year: 1974
---
# This Is a Real Fire, Folks

I was head resident of Furnald Hall when I heard this one. In addition to fire drills, in which counselors would herd grumpy Furnald folk out of the building, we would occasionally have real fires, complete with flames and smoke, usually due to hot plates gone wild. On one such occasion, a counselor used his pass-key to enter the room of a resident who he knew was dead asleep. Smoke was already on most of the floors, and virtually everyone was out of the building. After much shaking of shoulders, the resident awakened enough to understand what was happening: that a real fire was having its way. He looked up at the counselor, rolled back over facing the wall, head on pillow, and said: "I'll burn."
