---
title: 'My Columbia: Paul Tillich:  The Ameba'
author: John (Jack) Kauderer
layout: memory
schools:
  PS: 1964
  CC: 1959
primary_year: 1964
tags:
- Dorm life
- Campus
---
# Paul Tillich:  The Ameba

While an undergraduate, I lived off campus with my parents, but I came to many of the Earl Hall events. I was very excited to attend an informal gathering with Dr. Tillich. I really don't rememember the specifics of what he or the other students said but I was amazed at Dr. Tillich's ability to surround and embrace the ideas being shared and envelop them in his theology. It was an amazing tour de force. Being a zoology major, I envision the whole process as identical to phagocytosis by the ameba.
