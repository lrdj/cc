---
title: 'My Columbia: Freshman Arrival'
author: Antonio Vinals
tags:
- John Jay
- Academics
layout: memory
schools:
  CC: 1989
primary_year: 1989
---
# Freshman Arrival

After having attended a rather conservative and traditional high school, I was immediately excited and electrified by the freedom of my first semester at Columbia...the variety of intelligent classmates from all over the world made my first year experience living in John Jay (7th floor) a wonderul experience!
