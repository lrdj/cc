---
title: 'My Columbia: Albums Enjoyed at Columbia'
author: Arthur Feldman
layout: memory
schools:
  SEAS: 2004
primary_year: 2004
tags: []
---
# Albums Enjoyed at Columbia

Strokes - Is This It

Blackstar - This Is Blackstar

Steinski - Nothing to Fear

Blackalicious - Blazing Arrow

Black Eyed Peas - Empire

The Band - Last Waltz

Bob Dylan - Highway 61

Spoon - Girls Can Tell

Dr. Octagon - Octagonacologist

Handsome Boy Modeling School - How's Your Girl?

And there were probably more, lots more. But I honestly couldn't sit here and name them all.  That would take, like, all night, and I'm tired and want a free CD. Is that so wrong?

Editor's Note: No.
