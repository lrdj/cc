---
title: 'My Columbia: The Gate'
author: Marcel Agueros
tags:
- Hartley
- McBain
- Dorm life
- Campus
layout: memory
schools:
  CC: 1996
primary_year: 1996
---
# The Gate

During the spring of my sophomore year I moved into a room on the 2nd floor of Hartley, a forced exile from my beloved McBain that I did not take too well. I took it even less well when I discovered that for security reasons the window in my new room was guarded by an ugly, massive metal gate to which I formed an instant dislike. Who was going to climb up to my room from Amsterdam Avenue? I therefore took it down, put it in a closet in the hallway of the suite, and forgot all about it--until the end of the semester, when our RA came around to inspect our rooms. In a panic, I managed to sneak the gate into the room, locked myself in, and desperately started remounting it. Naturally it weighed three times what I remembered; sweating, cursing, and frantic, I took a good chunk out of my right hand while fighting with a screwdriver--the last thing I needed was more housing troubles...

I ran out of time before I was done: I'd turned the RA away a couple of times and so reluctantly opened up when he knocked again--and he took a quick look around, nodded his approval, and left--and I realized that the gate was mounted backwards. I'm pretty sure I took it back down and put it in correctly, but I can't swear to it...
