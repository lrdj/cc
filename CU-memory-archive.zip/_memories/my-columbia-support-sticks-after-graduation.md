---
title: 'My Columbia: Support Sticks After Graduation'
author: Cristina Pippa
layout: memory
schools:
  CC: 2002
primary_year: 2002
tags:
- Relationships
---
# Support Sticks After Graduation

When my play (which was actually my writing/directing thesis at Columbia in 2002) was being produced in the Upper West Side, Liz Gill Neilson, my college roommate in Watt, invited me to be her roommate once more. Liz and her husband, Duncan, made space for me in their one-bedroom apartment in Washington Heights for an entire month and were supportive throughout the rehearsal and performance process. Another close friend, Alaleh Akhavan, also came to the play along with her entire family. Ambarish Manepalli and Nik Johnson were there as well. Nik and I had reconnected at a Columbia Entertainment Industry night, after which he put me in touch with Courtney Martin, who was starting a stellar writers' group. I feel quite fortunate to have been in the group, which also boasts member Kate Torgovnik, since its inception in 2005.

In another feat of great support, Nicole Civita accompanied me to Bosnia and Herzegovina last spring for a new play commission I'm working on!
