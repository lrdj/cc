---
title: 'My Columbia: Flashy New Dorms'
author: Bruce Robertson
tags:
- East Campus
- Dorm life
- Campus
layout: memory
schools:
  CC: 1983
primary_year: 1983
---
# Flashy New Dorms

The new East Campus facility was a great living experience with suites and a nice kitchen and communal area.  We had great parties (who didn't?) and romantic adventures (who said college wasn't a learning experience?).  But most fun was the rewiring one of my roomates did to the phones so that they blinked rather than rang (this was the old days when phones were just ... phones, no digital or wireless).  This had the advantage of not waking suitemates sleeping in late (no one went to bed early -- what college did YOU go to?) and impressing visitors.  Also, since we made so much noise with stereos and electric guitars and drums for bands we were all in, this was the only way to see if you were getting a phone call.

I have other stories, but I'm not sure the statute of limitations has run out on them yet.
